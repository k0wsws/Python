import pandas as pd

# data2.pkl 파일 읽기
file_path = "data/data2.pkl"

try:
    df = pd.read_pickle(file_path)
    print(df)  # 데이터 확인
except Exception as e:
    print(f"파일을 읽는 중 오류 발생: {e}")