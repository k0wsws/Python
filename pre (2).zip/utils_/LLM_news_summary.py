# -*- coding: utf-8 -*-
"""
Created on Sat Sep 28 22:04:23 2024

@author: k0wsw
"""
import pandas as pd

import os
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.prompts.chat import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)
from langchain.chat_models import ChatOpenAI #openai
from datetime import datetime
import time
import openai
from openai.error import RateLimitError
import api_keys as key
import path_set as ps

root=ps.path()

# 1. Set up your OpenAI API key

os.environ['OPENAI_API_KEY']=key.openai_api_key()
os.environ['ANTHROPIC_API_KEY']=key.Anthropic_api_key()

today_date = datetime.now().strftime("%Y%m%d")

# 6. Function to format headlines
def format_headlines(headlines):
    return "\n".join([f"{i+1}. {headline}" for i, headline in enumerate(headlines)])

# 7. Iterate over the DataFrame and generate summaries

def call_openai_api(prompt, retries=5, wait_time=10):
    for attempt in range(retries):
        try:
            # API 호출
            response = openai.Completion.create(
                engine="gpt-3.5-turbo",
                prompt=prompt,
                max_tokens=50
            )
            return response
        
        except RateLimitError:
            if attempt < retries - 1:
                print(f"Rate limit reached. Retrying in {wait_time} seconds... (Attempt {attempt + 1}/{retries})")
                time.sleep(wait_time)  # 지정된 시간 동안 대기 후 재시도
            else:
                print("Max retries reached. Could not complete the request.")
                return None
            
            
def news_maker(grouped_df):
    
    # 4. Create a prompt template
    template = """
    You are an AI assistant specializing in financial analysis for {stock_name}.

    Here are the latest news headlines with links related to {stock_name}:

    {headlines}

    Please provide a concise summary of the key points from these headlines, focusing on how they impact {stock_name}.


    단. 한글로 대답해주는데 300 글자 내로 요약해서 대답해
    
    추가로 요약한 종목과 가장 연관도가 높은 뉴스 링크도 같이첨부해주는데 최대 2개까지만 첨부해. 양식은 아래의 예처럼 해줘.
    
    예)
    
    
    관련 뉴스 링크:
        
    - (https://n.news.naver.com/mnews/article/016/0002372855)
    - (https://n.news.naver.com/mnews/article/022/0003975667)

    """

    chat_prompt = PromptTemplate(
        input_variables=["stock_name", "headlines"],
        template=template
    )

    # 6. Create the LLMChain
    chain = LLMChain(
        llm=ChatOpenAI(model="gpt-4o"), #ChatOllama(model="llama3.1"),
        prompt=chat_prompt
    )

    results=[]
    for index, row in grouped_df.iterrows():
        for attempt in range(5):
            try: 
                Ticker = row['JM_NM']
                headlines = row['Titles']
                
                # Ensure headlines are in list format
                if isinstance(headlines, str):
                    # If headlines are a single string separated by a delimiter, split them
                    headlines = headlines.split('. ')  # Adjust the delimiter as needed
                    headlines = [headline.strip() for headline in headlines if headline.strip()]
                
                # Format the headlines
                formatted_headlines = format_headlines(headlines)
                
                # Run the LLMChain
                
                summary = chain.run(stock_name=Ticker, headlines=formatted_headlines)
                print(f"\nSummary for {Ticker}:")
                print(summary)
                results.append({"ticker": Ticker,"summary": summary})
                
                break;
                
            except RateLimitError:
                time.sleep(10)
            

    # =======================
    # 6. Create a New DataFrame with Summaries
    # =======================
    
    # Create the summary DataFrame
    summary_df = pd.DataFrame(results)
    summary_df.to_csv(root+f"summary_news_{today_date}.csv", encoding='utf-8-sig')
    
    return summary_df


def news_maker2(grouped_df):
    
    # 4. Create a prompt template
    template = """
    You are an AI assistant specializing in ETF analysis for {ETF_NM}.

    I will give you information about 2 best and 2 worst stock that affected ETF's 1 day performance and also the ETF's 1 day performance
    
    Here are the information(ETF_RT: ETF's 1day performance ','JM_NM': Stock name,'RT': Stock return,'CT_RT': contribution return to ETF,'SUMMARY': Summary of recent news) related to {ETF_NM}:

    {information}
    
    Using the information, please provide ETF Short brief including the reason of daily performance.
    And also give 2 or 3 keywords of the summary(not the stock name)

    단. 한글로 대답해주는데 200 글자 내로 요약해서 대답해.
    그리고 키워드는 주가상승,외국인 투자 등 이런 말들의 요약 말고 싱세한 내용요약으로 키워드를 뽑아줘(종목이름도 같이 넣어서 대답해줘)
    예시로는 엔비디아 신고가근접, 폭스콘의 AI서버수요발표 이렇게
    
    키워드: 1, 2, 3

    """

    chat_prompt = PromptTemplate(
        input_variables=["ETF_NM", "information"],
        template=template
    )

    # 6. Create the LLMChain
    chain = LLMChain(
        llm=ChatOpenAI(model="gpt-4o"), #ChatOllama(model="llama3.1"),
        prompt=chat_prompt
    )

    results=[]
    
    for index, row in grouped_df.iterrows():
        for attempt in range(5):
            try: 
                ETF_NM = row['ETF_NM']
                information = row['information']
                
                # Ensure headlines are in list format
                if isinstance(information, str):
                    # If headlines are a single string separated by a delimiter, split them
                    information = information.split('. ')  # Adjust the delimiter as needed
                    information = [headline.strip() for headline in information if headline.strip()]
                
                # Format the headlines
                formatted_headlines = format_headlines(information)
                
                # Run the LLMChain
                
                summary = chain.run(ETF_NM=ETF_NM, information=formatted_headlines)
                print(f"\nSummary for {ETF_NM}:")
                print(summary)
                results.append({"ETF_NM": ETF_NM,"summary": summary})
                
                break;
                
            except RateLimitError:
                time.sleep(10)
                
    # =======================
    # 6. Create a New DataFrame with Summaries
    # =======================
    
    # Create the summary DataFrame
    summary_df = pd.DataFrame(results)
    summary_df.to_csv(root+f"summary_news_etf_{today_date}.csv", encoding='utf-8-sig')
    
    return summary_df

def news_maker_m(grouped_df):
    
    # 4. Create a prompt template
    template = """
    You are an AI assistant specializing in financial analysis for {stock_name}.

    Here are the monthly news headlines with links related to {stock_name}:

    {headlines}

    Please provide a concise summary of the key points from these headlines, focusing on how they impact {stock_name}.


    단. 한글로 대답해주는데 500 ~ 1000 글자로 요약해서 대답해
    
    추가로 요약한 종목과 가장 연관도가 높은 뉴스 링크도 같이첨부해주는데 최대 5개까지만 첨부해. 양식은 아래의 예처럼 해줘.
    
    예)
    
    
    
    
    관련 뉴스 링크:
        
    - (https://n.news.naver.com/mnews/article/016/0002372855)
    - (https://n.news.naver.com/mnews/article/022/0003975667)

    """

    chat_prompt = PromptTemplate(
        input_variables=["stock_name", "headlines"],
        template=template
    )

    # 6. Create the LLMChain
    chain = LLMChain(
        llm=ChatOpenAI(model="gpt-4o"), #ChatOllama(model="llama3.1"),
        prompt=chat_prompt
    )

    results=[]
    for index, row in grouped_df.iterrows():
        for attempt in range(5):
            try: 
                Ticker = row['JM_NM']
                headlines = row['Titles']
                
                # Ensure headlines are in list format
                if isinstance(headlines, str):
                    # If headlines are a single string separated by a delimiter, split them
                    headlines = headlines.split('. ')  # Adjust the delimiter as needed
                    headlines = [headline.strip() for headline in headlines if headline.strip()]
                
                # Format the headlines
                formatted_headlines = format_headlines(headlines)
                
                # Run the LLMChain
                
                summary = chain.run(stock_name=Ticker, headlines=formatted_headlines)
                print(f"\nSummary for {Ticker}:")
                print(summary)
                results.append({"ticker": Ticker,"summary": summary})
                
                break;
                
            except RateLimitError:
                time.sleep(10)
            

    # =======================
    # 6. Create a New DataFrame with Summaries
    # =======================
    
    # Create the summary DataFrame
    summary_df = pd.DataFrame(results)
    summary_df.to_csv(root+f"summary_news_M_{today_date}.csv", encoding='utf-8-sig')
    
    return summary_df