# -*- coding: utf-8 -*-
"""
Created on Sun Oct 13 14:09:46 2024

@author: USER
"""

import LLM_news_summary as llm_news
import pre.crawl_list as cl
import pandas as pd
from datetime import datetime, timedelta
import stock_news_crawling as crawler
import daily_reporter as rpt
import pre.DB_ETF as DB
import path_set as ps

root=ps.path()
today_date = datetime.now().strftime("%Y%m%d")
input_date = (datetime.now() - timedelta(1)).strftime('%Y%m%d')
yesterday = (datetime.now() - timedelta(2)).strftime('%Y%m%d')

conn=DB.conn()
cursor = conn.cursor()

#####해외 news 크롤링 and 요약후 디비적재###
crawler.process_global_news(today_date, cursor)


df_gl = f"""
    SELECT A.TICKER,C.JM_NM,A.TITLE, A.LINK fROM STOCK_NEWS_GLOBAL A,(select DISTINCT LEFT(TICKER_ID, CHARINDEX(' ', TICKER_ID) ) as TICKER_ID, JM_KSD_CD,B.JM_NM from (SELECT DISTINCT ISIN_ID, TICKER_ID FROM BFXA1000) A, QUANT1.DBO.FDTWB_ETFPDF B where A.ISIN_ID=B.JM_KSD_CD AND TR_YMD='20241010') B, JM_MAST C 
    WHERE A.TICKER=B.TICKER_ID AND TRD_DT>='{yesterday}'  AND C.JM_KSD_CD=B.JM_KSD_CD
"""

#news 불러오기
df_gl = pd.read_sql(df_gl, conn)
# 'Title'과 'Link'를 결합하여 새로운 컬럼 생성
df_gl['Title_with_Link'] = df_gl.apply(lambda row: f"{row['TITLE']} ({row['LINK']})", axis=1)
# Ticker별로 Title_with_Link를 리스트로 그룹화
grouped_df_gl = df_gl.groupby(['TICKER','JM_NM'])['Title_with_Link'].apply(list).reset_index()
grouped_df_gl.rename(columns={'Title_with_Link': 'Titles'}, inplace=True)

news_gl=llm_news.news_maker(grouped_df_gl)
news_gl.rename(columns={'ticker': 'JM_NM'}, inplace=True)

df_final=pd.merge(news_gl,grouped_df_gl,on='JM_NM',how='inner')

for index, row in df_final.iterrows():
    cursor.execute("INSERT INTO STOCK_NEWS_SUMMARY values(?,?,?,?)",input_date, row.TICKER, row.JM_NM, row.summary)

cursor.commit()


#####국내 news 크롤링 and 요약후 디비적재###

crawler.process_kr_news(today_date, cursor)

df_kr = f"""
   SELECT * FROM STOCK_NEWS_KR WHERE TRD_DT>='{yesterday}'
"""

#news 불러오기
df_kr = pd.read_sql(df_kr, conn)
# 'Title'과 'Link'를 결합하여 새로운 컬럼 생성
df_kr['Title_with_Link'] = df_kr.apply(lambda row: f"{row['TITLE']} ({row['LINK']})", axis=1)
# Ticker별로 Title_with_Link를 리스트로 그룹화
grouped_df_kr = df_kr.groupby(['TICKER','JM_NM'])['Title_with_Link'].apply(list).reset_index()
grouped_df_kr.rename(columns={'Title_with_Link': 'Titles'}, inplace=True)

news_kr=llm_news.news_maker(grouped_df_kr)
news_kr.rename(columns={'ticker': 'JM_NM'}, inplace=True)

df_final=pd.merge(news_kr,grouped_df_kr,on='JM_NM',how='inner')

for index, row in df_final.iterrows():
    cursor.execute("INSERT INTO STOCK_NEWS_SUMMARY values(?,?,?,?)",input_date, row.TICKER, row.JM_NM, row.summary)

cursor.commit()

### ETF뉴스 요약후 디비적재


df=cl.crawl_list(today_date)[2]
grouped_data = df.groupby('FUND_NM').apply(
    lambda x: [
        [f"ETF_RT: {row['ETF_RT']}",f"JM_NM: {row['JM_NM']}", f"RT: {row['RT']}", f"CT_RT: {row['CT_RT']}", f"SUMMARY: {row['SUMMARY']}"]
        for _, row in x.iterrows()
    ]
)
final_df = pd.DataFrame({'ETF_NM': grouped_data.index, 'information': grouped_data.values})
llm_news.news_maker2(final_df)

df1 =pd.read_csv(root+f"summary_news_etf_{today_date}.csv")
df1 = df1.drop(columns=['Unnamed: 0'])

for index, row in df1.iterrows():
    cursor.execute("INSERT INTO ETF_NEWS_SUMMARY values(?,?,?)",input_date, row.ETF_NM, row.summary)

cursor.commit()

##시황뉴스
rpt.update()

# ln.update()
# ln.update2()


# df_gl_m = """
#     SELECT DISTINCT TRD_DT,A.TICKER,C.JM_NM,A.TITLE, A.LINK fROM STOCK_NEWS_GLOBAL A,(select DISTINCT LEFT(TICKER_ID, CHARINDEX(' ', TICKER_ID) ) as TICKER_ID, JM_KSD_CD,B.JM_NM from (SELECT DISTINCT ISIN_ID, TICKER_ID FROM BFXA1000) A, QUANT1.DBO.FDTWB_ETFPDF B where A.ISIN_ID=B.JM_KSD_CD AND TR_YMD='20241010') B, JM_MAST C 
#     WHERE A.TICKER=B.TICKER_ID AND TRD_DT like '202411%'  AND C.JM_KSD_CD=B.JM_KSD_CD
# """

# #news 불러오기
# df_gl_m = pd.read_sql(df_gl_m, conn)
# # 'Title'과 'Link'를 결합하여 새로운 컬럼 생성
# df_gl_m['Title_with_Link'] = df_gl_m.apply(lambda row: f"{row['TITLE']} ({row['LINK']})", axis=1)
# # Ticker별로 Title_with_Link를 리스트로 그룹화
# grouped_df_gl_m = df_gl_m.groupby(['TICKER','JM_NM'])['Title_with_Link'].apply(list).reset_index()
# grouped_df_gl_m.rename(columns={'Title_with_Link': 'Titles'}, inplace=True)

# news_gl_m=llm_news.news_maker_m(grouped_df_gl_m)
# news_gl_m.rename(columns={'ticker': 'JM_NM'}, inplace=True)

# df_final_m=pd.merge(news_gl_m,grouped_df_gl_m,on='JM_NM',how='inner')

# for index, row in df_final_m.iterrows():
#     cursor.execute("INSERT INTO STOCK_NEWS_SUMMARY_M values(?,?,?,?)",'202411', row.TICKER, row.JM_NM, row.summary)

# cursor.commit()


# df_kr = """
#    SELECT DISTINCT TRD_DT,TICKER,JM_NM,TITLE,LINK FROM STOCK_NEWS_KR WHERE TRD_DT>='202411'
# """

# #news 불러오기
# df_kr = pd.read_sql(df_kr, conn)
# # 'Title'과 'Link'를 결합하여 새로운 컬럼 생성
# df_kr['Title_with_Link'] = df_kr.apply(lambda row: f"{row['TITLE']} ({row['LINK']})", axis=1)
# # Ticker별로 Title_with_Link를 리스트로 그룹화
# grouped_df_kr = df_kr.groupby(['TICKER','JM_NM'])['Title_with_Link'].apply(list).reset_index()
# grouped_df_kr.rename(columns={'Title_with_Link': 'Titles'}, inplace=True)

# news_kr=llm_news.news_maker_m(grouped_df_kr)
# news_kr.rename(columns={'ticker': 'JM_NM'}, inplace=True)

# df_final=pd.merge(news_kr,grouped_df_kr,on='JM_NM',how='inner')

# for index, row in df_final.iterrows():
#     cursor.execute("INSERT INTO STOCK_NEWS_SUMMARY_M values(?,?,?,?)",'202411', row.TICKER, row.JM_NM, row.summary)

# cursor.commit()
