# -*- coding: utf-8 -*-
"""
Created on Sat Oct 12 12:13:20 2024

@author: USER
"""

from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.chat_models import ChatOpenAI #openai
import PyPDF2
import requests
from bs4 import BeautifulSoup
import pickle
import os
import re
import path_set as ps
import api_keys as key

root=ps.path()

def crawl_pdf_link(): 
    
    url = "https://finance.naver.com/research/market_info_list.naver?searchType=keyword&keyword=%B8%B6%B0%A8%C4%DA%B8%E0%C6%AE&brokerCode=&writeFromDate=&writeToDate=&x=23&y=19"
    
    # 웹 페이지 요청
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
    }
    response = requests.get(url, headers=headers,verify=False)
    
    # HTML 파싱
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # 'li' 태그 안의 'a' 태그에서 'title' 속성을 추출
    li_tags = soup.find_all('td',class_='file')  # 모든 li 태그 찾기
    
    pdf_link = []
    
    for li in li_tags:
        a_tag = li.find('a', href=True)  # 'a' 태그에서 'title' 속성이 있는 태그만 찾기
        if a_tag:
            pdf_link.append(a_tag['href'])  # 'title' 속성 값 저장
    
      
    return pdf_link

def crawl_pdf_link2():
    
    url = "https://finance.naver.com/research/market_info_list.naver?searchType=keyword&keyword=%B8%F0%B4%D7%C4%DA%B8%E0%C6%AE&brokerCode=&writeFromDate=&writeToDate=&x=0&y=0&page=1"
    
    # 웹 페이지 요청
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
    }
    response = requests.get(url, headers=headers,verify=False)
    
    # HTML 파싱
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # 'li' 태그 안의 'a' 태그에서 'title' 속성을 추출
    li_tags = soup.find_all('td',class_='file')  # 모든 li 태그 찾기
    
    pdf_link = []
    
    for li in li_tags:
        a_tag = li.find('a', href=True)  # 'a' 태그에서 'title' 속성이 있는 태그만 찾기
        if a_tag:
            pdf_link.append(a_tag['href'])  # 'title' 속성 값 저장
    
    return pdf_link
    


# PDF 파일 읽기 함수
def extract_text_from_pdf(pdf_path):
    with open(pdf_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
    return text
    

def update():
    # PDF 파일을 다운로드할 URL
    url = crawl_pdf_link()[0]
    url2 =crawl_pdf_link2()[0]
    
    # 요청을 통해 PDF 파일 다운로드
    response = requests.get(url,verify=False)
    response2 = requests.get(url2,verify=False)
    
    # URL에서 날짜 추출 (정규 표현식 사용)
    date_match = re.search(r"(\d{8})", url)
    
    file_date = date_match.group(1)  # '20241011' 형식의 날짜 추출
    file_name = root+f"dailyreport_kr_{file_date}.pdf"
    file_name2 =root+ f"dailyreport_gl_{file_date}.pdf"
    
    with open(file_name, "wb") as file:
        file.write(response.content)
    
    with open(file_name2, "wb") as file:
        file.write(response2.content)
    
    
    # 1. Set up your OpenAI API key
    
    
    os.environ['OPENAI_API_KEY']=key.openai_api_key()
    os.environ['ANTHROPIC_API_KEY']=key.Anthropic_api_key()

    llm = ChatOpenAI(model="gpt-4o")
    
    # PDF 파일 로드
    pdf_text1 = extract_text_from_pdf(file_name)
    pdf_text2 = extract_text_from_pdf(file_name2)
    
    # 사용자 정의 요약 템플릿 설정
    summary_template_kr = """
    다음은 국내 주식 마감 시황에 관한 PDF 문서의 일부입니다:
    
    {content}
    
    위 내용을 간결하게 요약해 주는데 아래와 같은 형태로 해줘. 국내시황부터 300자 내로 써줘(출처는 밝히지 말아,리포트 날짜로 기준일적어주고)
        [2024.10.18 종가 기준]
        
        국내 주요지수: 
        - KOSPI:2,405.12(+0.5%)
        - KOSDAQ:815.23(+0.3%)
        
        국내 시황:
            
            
    """
    
    summary_template_gl = """
    다음은 글로벌 주식 마감 시황에 관한 PDF 문서의 일부입니다:
    
    {content}
    
    위 내용을 간결하게 요약해 주는데 아래와 같은 형태로 해줘. 글로벌 시황부터 300자 내로 써줘(출처는 밝히지 말아,리포트 날짜로 기준일적어주는데 글로벌 지수이니까 리포트발간날짜에서 하루전날로 해줘)
        [2024.10.18 종가 기준]
        
        글로벌 주요지수: 
        - 다우존스:2,405.12(+0.5%)
        - 나스닥:815.23(+0.3%)
        - S&P500:4549.78(+0.8%)
        
        FICC시장동향:
        - 미국10년(국채수익률):
        - 달러 인덱스:
        -유가(WTI)
        
        글로벌 시황:
            
    """
    
    
    
    prompt_template1 = PromptTemplate(input_variables=["content"], template=summary_template_kr)
    prompt_template2 = PromptTemplate(input_variables=["content"], template=summary_template_gl)
    

    # 템플릿을 이용한 요약 체인 생성
    chain1 = LLMChain(llm=llm, prompt=prompt_template1)
    chain2 = LLMChain(llm=llm, prompt=prompt_template2)
    
    # 각 문서의 내용을 요약
    summary1 = chain1.run({"content": pdf_text1})
    summary2 = chain2.run({"content": pdf_text2})
    print(f"요약 결과: {summary1} {summary2}")
    
    
    
    with open(root+"news_kr.pkl", "wb") as file:
        pickle.dump(summary1, file)
    
    with open(root+"news_gl.pkl", "wb") as file:
        pickle.dump(summary2, file) 
        
