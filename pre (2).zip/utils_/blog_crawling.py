# -*- coding: utf-8 -*-
"""
Created on Wed Jan 22 10:29:17 2025

@author: USER
"""
from bs4 import BeautifulSoup
import requests
import datetime

#필요한 라이브러리 
import pandas as pd 
import re
from datetime import date,timedelta,datetime
import pre.DB_ETF as DB
import numpy as np
import random
import time
import path_set as ps
import ssl
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import chromedriver_autoinstaller

from sqlalchemy.exc import IntegrityError
import pyodbc

#chromedriver_autoinstaller.install()

root=ps.main_path()[0]
conn=DB.conn()
cursor = conn.cursor()

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/98.0.4758.102',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) Chrome/98.0.4758.102'
]



def read_by_keyword(etf_cd, etf_nm, set_dt, query):
    
    # start crawling
    headers = {'User-Agent': random.choice(USER_AGENTS)}
    
    ssl.SSLContext.verify_mode = ssl.VerifyMode.CERT_OPTIONAL
    ssl._create_default_https_context = ssl._create_unverified_context
    
    # start ~ end까지 기간 지정하여 데이터 수집
    end = datetime.now()
    endDate = str(end.year)+"-"+str(end.month).zfill(2)+"-"+str(end.day).zfill(2)    
    
    # 상장일로부터 7일 전부터 오늘날짜까지!
    set_dt = datetime.strptime(set_dt, '%Y%m%d')
    start_dt = set_dt - timedelta(days=7)
    startDate = start_dt.strftime('%Y-%m-%d')
    
    
    # 페이지 넘기기
    pg=1
    cnt=0
    new_dict = {}
    
    # 페이지별, 상품별 블로그 가져오기
    while pg < 20:
         
        url = f'https://section.blog.naver.com/Search/Post.naver?pageNo={pg}&rangeType=PERIOD&orderBy=sim&startDate={startDate}&endDate={endDate}&keyword={query}'
        driver = webdriver.Edge()
        driver.maximize_window()
        driver.get(url)
        driver.implicitly_wait(2)
        
        posts = driver.find_elements(By.CSS_SELECTOR, ".info_post")
        
        update_dt =  datetime.now()
        
        # 한 페이지
        for post in posts:
            
            #dictionary에 추가
            title = post.find_element(By.CSS_SELECTOR, ".title_post").text
            # print('title:', title)
            
            url = post.find_element(By.CSS_SELECTOR, ".desc_inner").get_property("href")
            # print('url:', url)
            
            writer = post.find_elements(By.CSS_SELECTOR, ".writer_info > a.author > em.name_author")[0].text
            # print('writer:', writer)
            
            date = post.find_elements(By.CSS_SELECTOR, ".writer_info > span.date")[0].text
            # print('date:', date)
            ## 2025. 1. 21. 이런 형식이거나 N시간 전
            ## 날짜 전처리
            if ' 전' in date:
                if date[-3:]=='분 전':
                    date=str(update_dt)[0:10].replace('-','')
                elif date[-3:]=='간 전':
                    date=str(update_dt-timedelta(hours=int(date[-6:-4])))[0:10].replace('-','')
            else:
                date = date.replace('.', '')
                year, month, day = date.split(" ")
                
                date = year+month.zfill(2)+day.zfill(2)   
            # print(date)
            
            new_dict[cnt] = {'etf_cd': etf_cd, 'etf_nm': etf_nm, 'title': title, 'url': url,'writer': writer, 'date':date}
            cnt += 1
        
        pg += 1
            
    
    return pd.DataFrame(new_dict).T



def etf_db():
    query = """
        DECLARE @TRD_DT VARCHAR(8)
        	SET @TRD_DT = (select max(TR_YMD) from FN_ETFINFO where ETF_CD = 'A105190')
        SELECT ETF_CD, ETF_NM, SET_DT
        FROM FN_ETFINFO
        WHERE TR_YMD=@TRD_DT AND (ETF_NM like 'ACE%' or ETF_NM like 'RISE%' or ETF_NM like 'KODEX%' or ETF_NM like 'TIGER%' or ETF_NM like 'SOL%')
        ORDER BY ETF_NM ASC
    """
    df=DB.read(query,conn)
    df['ETF_NM_chg'] = df['ETF_NM'].str.replace(' ', '%20', regex=False)
    df['ETF_NM_chg'] = df['ETF_NM_chg'].str.replace('+', '%2B', regex=False)
    df['ETF_NM_chg'] = df['ETF_NM_chg'].str.replace('~', '~~', regex=False)
    
    return df


def main():
    # 상품명, 코드, 상장일
    df = etf_db()
    
    blog_df = pd.DataFrame()
    
    # 코드 하나씩 돌면서 블로그 크롤링
    for index, row in df.iterrows():
        
        # read_by_keyword(etf_cd, etf_nm, set_dt, query):
        blog_data = read_by_keyword(row['ETF_CD'], row['ETF_NM'], row['SET_DT'], row['ETF_NM_chg'])
        
        # print(blog_data)
        df_all = pd.concat([blog_df, blog_data], ignore_index=True)
        
        df_all.to_csv(root+"etf_naver_blog.csv", encoding="utf-8-sig")
    
        
    df_all.to_csv(root+"etf_naver_blog.csv", encoding="utf-8-sig")

    
if __name__ == "__main__":
        main()