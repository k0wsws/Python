# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 14:01:37 2024

@author: USER
"""

import requests
import json
import time
import warnings
from urllib3.exceptions import InsecureRequestWarning
import pickle
import path_set as ps
import api_keys as key
import pre.get_data as getd

root=ps.path()

# InsecureRequestWarning 경고를 무시합니다
warnings.simplefilter('ignore', InsecureRequestWarning)


APP_KEY=key.ls_api_key()[0]
APP_SECRET=key.ls_api_key()[1]


# print("호가파일")
print("LP호가 신고스프레드 start")

# 신고스프레드용 df
df = getd.get_etf_manager() 

# print(df)
# df.loc[93, ['FUND_CD', 'STK_CD', 'rp_spread', 'SP_TYP', 'OS_GB', 'MANAGER']] = ['9004U', 'A0046Y0', 1.0, None, '해외', '박지영']

# # 93번 행 수정
# df.loc[93, ['FUND_CD', 'STK_CD', 'rp_spread', 'SP_TYP', 'OS_GB', 'MANAGER']] = ['9004W', 'A0049M0', 1.0, None, '해외', '김중훈']

# # 94번 행 수정
# df.loc[94, ['FUND_CD', 'STK_CD', 'rp_spread', 'SP_TYP', 'OS_GB', 'MANAGER']] = ['9004V', 'A0049K0', 1.0, None, '혼합', '박지영']



df['STK_CD'] = df['STK_CD'].str.replace("A", "")
df = df[~df['FUND_CD'].isin(['9001C'])]
df.reset_index(drop=True, inplace=True)
df['cnt'] = 0           # 신고 스프레드 위반 횟수 (연속)

# print(df)


## 토큰발급
###############################################################6/1부터 api주소 변경#########################
# "https://openapi.ls-sec.co.kr:8080"
# "https://openapi.ebestsec.co.kr:8080"
BASE_URL = "https://openapi.ls-sec.co.kr:8080"
PATH = "oauth2/token"
URL = f"{BASE_URL}/{PATH}"
headers = {"content-type":"application/x-www-form-urlencoded"}

data_key="appkey="+APP_KEY+"&appsecretkey="+APP_SECRET+"&grant_type=client_credentials&scope=oob"

res = requests.post(URL, headers=headers, data=data_key,verify=False)
# print(res.status_code)

ACCESS_TOKEN = res.json()["access_token"]
# print(ACCESS_TOKEN)



# 개별 ETF 데이터 괴리율 초과 확인 (국내 1%, 해외 2%)
def fetch_etf_diff(shcode, res1, res2):
    sp_flag = 0
    
    # print(res)
    price = float(res2['t1906OutBlock']['bidho1'])      # 매수호가로 대체
    iNAV = float(res1['t1901OutBlock']['nav'])
    
    # 괴리율 계산
    ratio = (price-iNAV)/iNAV * 100
    
    row = df[df['STK_CD'] == shcode]
    fund_nm = row['ETF_NM'].iloc[0]
    OS_GB = row['OS_GB'].iloc[0]
    
    # 국내 1% / 해외 2% 초과시 알람
    if OS_GB == '국내':
        if ratio > 1 or ratio < -1: 
            sp_flag = 1
            # result_queue.put((shcode, fund_nm, OS_GB))
    elif OS_GB == '해외':
        if ratio > 2 or ratio < -2: 
            sp_flag = 1
            # result_queue.put((shcode, fund_nm, OS_GB))
    
    return fund_nm, OS_GB, sp_flag
    
        
# 스프레드 위반
def fetch_etf_spread(shcode, res):
    
    sp_flag = 0
    
    ask = float(res['t1906OutBlock']['offerho1'])
    bid = float(res['t1906OutBlock']['bidho1'])
    # sp = float(res2['t1901OutBlock']['spread'])
    
    ### (매도-매수)/매수
    if bid == 0: 
        print(shcode)
        row = df[df['STK_CD'] == shcode]
        fund_nm = row['ETF_NM'].iloc[0]
        sp_flag = 2
        
    else:
        spread = (ask - bid)/bid * 100
        # print(spread)
        # print(sp)
        
        # 신고 스프레드랑 비교
        row = df[df['STK_CD'] == shcode]
        fund_nm = row['ETF_NM'].iloc[0]
        rp_spread = float(row['rp_spread'].iloc[0]) # 신고 스프레드
        
        
        rp_cnt = int(row['cnt'].iloc[0])            # 스프레드 위반 횟수 (누적)
        
        if spread >= rp_spread:     # 스프레드 위반
            rp_cnt += 1
            if rp_cnt >= 3:                                                 # 3번 이상 스프레드 위반 -> flag & reset
                sp_flag = 1     
                df.loc[df['STK_CD'] == shcode, 'cnt'] = 0
            else: 
                df.loc[df['STK_CD'] == shcode, 'cnt'] = rp_cnt            # 3번 이하 스프레드 위반 -> add count
        
        else:                       # 스프레드 위반X
            df.loc[df['STK_CD'] == shcode, 'cnt'] = 0       
    
    return fund_nm, sp_flag
        
        
    
#https://teamroom.nate.com/api/webhook/1c36536c/KYX0Lc9BdNdAD7EnskoMOyi4  # 호가봇
#https://teamroom.nate.com/api/webhook/1c36536c/o2FRukw5tn10VFt0v9xWEpJ9  # 스프레드

def message(fund_nm, os_gb, manager):
    nate_webhook='https://teamroom.nate.com/api/webhook/c6d28a1b/4LQgZ9N1rQkXQnbsHeWGw6UB'     # ACE 호가모니터링
    
    if os_gb == '국내':
        text={"text": "@"+manager + " 매니저님 " + fund_nm + " 괴리율 1% 초과입니다 (국내)"}
    elif os_gb == '해외':
        text={"text": "@"+manager + " 매니저님 " + fund_nm + " 괴리율 2% 초과입니다 (해외)"}
    else: 
        if manager is None: text={"text": fund_nm + " 신고 스프레드 위반입니다"}
        else: text={"text": "@"+manager + " 매니저님 " + fund_nm + " 신고 스프레드 위반입니다"}
        head = {"text": "######## 연속 3회 스프레드 위반 ########"}
        requests.post(nate_webhook,json=head,verify=False)
        
    requests.post(nate_webhook,json=text,verify=False)

def message2(fund_nm, manager):
    nate_webhook='https://teamroom.nate.com/api/webhook/c6d28a1b/4LQgZ9N1rQkXQnbsHeWGw6UB'     # ACE 호가모니터링
    
    text={"text": "@"+manager + " 매니저님 " + fund_nm + " 매수 호가가 없습니다"}
    head = {"text": "######## 매수호가 없음 ########"}
    requests.post(nate_webhook,json=head,verify=False)
        
    requests.post(nate_webhook,json=text,verify=False)



def ETF_price(shcode):
    
    BASE_URL = "https://openapi.ls-sec.co.kr:8080"
    PATH = "stock/etf"
    URL = f"{BASE_URL}/{PATH}"
    
    header = {  
        "content-type": "application/json; charset=utf-8", 
        "authorization": f"Bearer {ACCESS_TOKEN}",
        "tr_cd": "t1906", 
        "tr_cont": "N",
        "tr_cont_key": "",
    }
    
    body = {
        "t1906InBlock": {    
            "shcode": shcode
        }  
    }
    
    request = requests.post(URL, headers=header, data=json.dumps(body), verify=False)
    
    return request

def ETF_spread(shcode):
    
    BASE_URL = "https://openapi.ls-sec.co.kr:8080"
    PATH = "stock/etf"
    URL = f"{BASE_URL}/{PATH}"
    
    header = {  
        "content-type": "application/json; charset=utf-8", 
        "authorization": f"Bearer {ACCESS_TOKEN}",
        "tr_cd": "t1901", 
        "tr_cont": "N",
        "tr_cont_key": "",
    }
    
    body = {
        "t1901InBlock": {    
            "shcode": shcode
        }  
    }
    
    request = requests.post(URL, headers=header, data=json.dumps(body), verify=False)
    
    return request    

def ETF_LP_price(shcode):
    
    BASE_URL = "https://openapi.ls-sec.co.kr:8080"
    PATH = "stock/etf"
    URL = f"{BASE_URL}/{PATH}"
    
    header = {  
        "content-type": "application/json; charset=utf-8", 
        "authorization": f"Bearer {ACCESS_TOKEN}",
        "tr_cd": "t1906", 
        "tr_cont": "N",
        "tr_cont_key": "",
    }
    
    body = {
        "t1906InBlock": {    
            "shcode": shcode
        }  
    }
    
    request = requests.post(URL, headers=header, data=json.dumps(body), verify=False)
    
    return request
    

# 모든 ETF에 대해 위반 점검 및 위반시 flag 출력 
if __name__ == "__main__":
    
    
    while True:
        
        hour = int(time.strftime('%H', time.localtime()))
        minute = int(time.strftime('%M', time.localtime()))
        
        if (hour < 9 or hour > 15):   # 16~익일8시까지는 동작X  # 수능 장 시간 변경
            break
        elif (hour == 9 and minute < 3):  # 9   # 수능 장 시간 변경
            continue
        elif (hour == 15 and minute > 20):   # 수능 장 시간 변경
            print("Done")
            break
            
        
        # 장중이면    
        timestamp = time.time()
        local_time = time.localtime(timestamp)
        formatted_time = time.strftime('%Y-%m-%d %H:%M:%S', local_time)
        # print(formatted_time) 
        start = time.time()
        
        for index, row in df.iterrows():
            
            # 종목 코드, 운용역 변수 저장
            shcode = row['STK_CD']
            manager = row['MANAGER']
            
            now = time.time()
            time.sleep(1-(now-start))
            
            # LS증권 API 호출
            req1 = ETF_price(shcode)
            
            start = time.time()
            
            # 응답이 잘 들어왔을 때
            if req1.status_code == 200: 
                
                # API 응답 본문
                res1 = req1.json()
                    
                # 스프레드 체크
                fund_nm_, sp_flag_ = fetch_etf_spread(shcode, res1)
                if sp_flag_ == 1:       
                    message(fund_nm_, 0, manager)
                    print(fund_nm_, " 신고 스프레드 위반")
                # elif sp_flag_ == 2:
                #     message2(fund_nm_, manager)
                #     print(fund_nm_, " 매수 호가 없음")
                    
            else: print(shcode, " API 호출 실패")
                
                
        
    # end = time.time()

    # print("수행시간: %f 초" % (end - start))
