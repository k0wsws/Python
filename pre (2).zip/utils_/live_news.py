import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.prompts.chat import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)
from langchain.chat_models import ChatOpenAI #openai
import utils_.stock_news_crawling as snc
import chardet
import pickle
import pre.DB_ETF as DB
import path_set as ps
import api_keys as key

root=ps.path()
conn=DB.conn()
cursor = conn.cursor()

# 1. Set up your OpenAI API key

os.environ['OPENAI_API_KEY']=key.openai_api_key()
os.environ['ANTHROPIC_API_KEY']=key.Anthropic_api_key()

# 6. Function to format headlines
def format_headlines(headlines):
    return "\n".join([f"{i+1}. {headline}" for i, headline in enumerate(headlines)])

def news_maker(grouped_df,GB):
    
    # 4. Create a prompt template
    template = """
    You are an AI assistant specializing in financial analysis for {stock_name}.

    Here are the latest news headlines with links related to {stock_name}:

    {headlines}

    Please provide a concise summary of the key points from these headlines.


    단. 한글로 대답해주는데 100 글자 내로 포인트만요약해서 대답해.
    다로 끝내지말고 요약하는 말투로 끝내 
    예시) --있음, --상승중,-- 필요 등등

 

    """

    chat_prompt = PromptTemplate(
        input_variables=["stock_name", "headlines"],
        template=template
    )

    # 6. Create the LLMChain
    chain = LLMChain(
        llm=ChatOpenAI(model="gpt-4o"), #ChatOllama(model="llama3.1"),
        prompt=chat_prompt
    )

    results=[]
    for index, row in grouped_df.iterrows():
        Ticker = row['jm_nm']
        headlines = row['Titles']
        
        # Ensure headlines are in list format
        if isinstance(headlines, str):
            # If headlines are a single string separated by a delimiter, split them
            headlines = headlines.split('. ')  # Adjust the delimiter as needed
            headlines = [headline.strip() for headline in headlines if headline.strip()]
        
        # Format the headlines
        formatted_headlines = format_headlines(headlines)
        
        # Run the LLMChain
        
        summary = chain.run(stock_name=Ticker, headlines=formatted_headlines)
        print(f"\nSummary for {Ticker}:")
        print(summary)
        results.append({"ticker": Ticker,"summary": summary})

    # =======================
    # 6. Create a New DataFrame with Summaries
    # =======================
    
    # Create the summary DataFrame
    summary_df = pd.DataFrame(results)
    summary_df.to_csv(root+f"summary_news_daily_{GB}.csv", encoding='utf-8-sig')
    
    return summary_df


def update():
    list_top=snc.process_top5_news()
    list_bot=snc.process_bot5_news()
    
    # Detect file encoding
    with open(root+'news_daily_top.csv', 'rb') as file:
        result = chardet.detect(file.read())
        encoding1 = result['encoding']
        
    # Detect file encoding
    with open(root+'news_daily_bot.csv', 'rb') as file:
        result = chardet.detect(file.read())
        encoding2 = result['encoding']
    
    df_top = pd.read_csv(root+'news_daily_top.csv', encoding=encoding1)
    df_bot = pd.read_csv(root+'news_daily_bot.csv', encoding=encoding2)
    
    
    grouped_df_top = df_top.groupby(['jm_nm'])['title'].apply(list).reset_index()
    grouped_df_top.rename(columns={'title': 'Titles'}, inplace=True)
    list_top.rename(columns={'name': 'ticker'}, inplace=True)
    
    grouped_df_bot = df_bot.groupby(['jm_nm'])['title'].apply(list).reset_index()
    grouped_df_bot.rename(columns={'title': 'Titles'}, inplace=True)
    list_bot.rename(columns={'name': 'ticker'}, inplace=True)
    
    news_maker(grouped_df_top,'top')
    news_maker(grouped_df_bot,'bot')
    
    news_top=pd.read_csv(root+'summary_news_daily_top.csv')    
    news_top=pd.merge(news_top,list_top,on='ticker',how='right')
    news_top['summary']=news_top['summary'].fillna('관련뉴스없음')
    news_top.loc[news_top['change_rate'] > 30, 'summary'] = '신규상장으로 인하여 큰폭으로 상승중'
    news_top=news_top.astype(str)
    cursor.execute("Delete from STOCK_NEWS_LIVE")
    for index, row in news_top.iterrows():
      
        
        query = "INSERT INTO STOCK_NEWS_LIVE (JM_NM, SUMMARY, RT,TD_GB) VALUES (?, ?, ?,?)"
        title =  row.ticker
        content = row.summary
        rt = row.change_rate
        cursor.execute(query, (title, content,rt,'T'))

    cursor.commit()
    
    news_bot=pd.read_csv(root+'summary_news_daily_bot.csv')    
    news_bot=pd.merge(news_bot,list_bot,on='ticker',how='right')
    news_bot['summary']=news_bot['summary'].fillna('관련뉴스없음')
    news_bot.loc[news_bot['change_rate'] < -30, 'summary'] = '신규상장으로 인하여 큰폭으로 하락중'
    
    news_bot=news_bot.astype(str)
    for index, row in news_bot.iterrows():
      
        
        query = "INSERT INTO STOCK_NEWS_LIVE (JM_NM, SUMMARY, RT,TD_GB) VALUES (?, ?, ?,?)"
        title =  row.ticker
        content = row.summary
        rt = row.change_rate
        cursor.execute(query, (title, content,rt,'B'))

    cursor.commit()

def crawl_global_news(page):
    
    url = f"https://finance.naver.com/news/news_list.naver?mode=LSS3D&section_id=101&section_id2=258&section_id3=403&page={page}"
    
    # 웹 페이지 요청
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
    }
    response = requests.get(url, headers=headers,verify=False)
    
    # HTML 파싱
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # 'li' 태그 안의 'a' 태그에서 'title' 속성을 추출
    li_tags = soup.find_all('dd',class_='articleSubject')  # 모든 li 태그 찾기
    
    pdf_link = []
    
    for li in li_tags:
        a_tag = li.find('a', title=True)  # 'a' 태그에서 'title' 속성이 있는 태그만 찾기
        if a_tag:
            pdf_link.append(a_tag['title'])  # 'title' 속성 값 저장
            
    return pdf_link

def update2():
    
    os.environ['OPENAI_API_KEY']='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'
    os.environ['ANTHROPIC_API_KEY']='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'
    
    llm = ChatOpenAI(model="gpt-4o")
    
    summary_news = """
    다음은 실시간 해외증시 뉴스들입니다:
    
    {content}
    
    위 내용을 간결하게 요약해줘 시황은 200자 내로 써주고 키워드 나열해줘
    (키워드는 미국증시 이런거말고 종목의 특이한 뉴스같은거나 특별한 포인트로 잡아줘 그리고 장중이라는 표현도 넣을수있으면 넣어줘)
    
    예시) 
    실시간 글로벌증시 요약:
    여기는요약 
    
    
    키워드: 1, 2, 3
           
    """
    
    prompt_template1 = PromptTemplate(input_variables=["content"], template=summary_news)
    
    chain1 = LLMChain(llm=llm, prompt=prompt_template1)
    
    summary1 = chain1.run({"content": str(crawl_global_news(1))})
    print(f"요약 결과: {summary1}")
    with open(root+"news_gl_now.pkl", "wb") as file:
        pickle.dump(summary1, file)
    