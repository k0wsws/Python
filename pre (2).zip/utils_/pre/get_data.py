# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 18:46:08 2024

@author: USER
"""

from dash import dcc, html, Input, Output, State, ALL
import json
import pandas as pd
import pre.DB_ETF as DB
import requests
import time
from pre.format_data import convert_to_percentage
from datetime import datetime, timedelta
import path_set as ps

root=ps.path()

# 파일에 업데이트 시간을 기록하는 함수
def save_update_time():
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(root+"update_time.txt", "w") as file:
        file.write(current_time)
    return current_time

# 파일에서 업데이트 시간을 읽는 함수
def read_update_time():
    try:
        with open(root+"update_time.txt", "r") as file:
            return file.read()
    except FileNotFoundError:
        return "No updates yet"


# ETF 구성종목 데이터 가져오기
def get_etf_data(etf_name, selected_date):
    conn = DB.conn()
    
    date_kr=f"""SELECT MAX(TR_YMD) TR_YMD FROM FN_ETFINFO WHERE TR_YMD<='{selected_date}'"""  
    date_kr = pd.read_sql(date_kr, conn)['TR_YMD'][0]
    date_us=f"""SELECT MAX(TR_YMD) TR_YMD FROM QUANT1.DBO.EOD0JG WHERE TR_YMD<{date_kr}AND JM_NM='APPLE'"""
    date_us = pd.read_sql(date_us, conn)['TR_YMD'][0]
    query = f"""
    SELECT JM_NM constituent_name,JM_CD, CT_RT performance, JM_WT weight fROM (
    SELECT A.*,RANK() OVER (ORDER BY JM_WT DESC) RK FROM (
    SELECT KSD_FUND_CD,FUND_NM,A.JM_NM,B.JM_CD,A.JM_WT,B.RT/100 CT_RT fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.FN_STOCK B 
    WHERE A.JM_KSD_CD =SUBSTRING(B.JM_CD,2,6) AND A.TR_YMD=B.TR_YMD AND A.TR_YMD='{date_kr}' AND FUND_NM ='{etf_name}'
    UNION
    SELECT KSD_FUND_CD,FUND_NM,A.JM_NM,B.JM_CD,A.JM_WT, ROUND((B.JONGGA /B.BF_JONGGA-1),4) CT_RT  
    fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.EOD0JG  B 
    WHERE A.JM_KSD_CD =B.JM_CD 
    AND A.TR_YMD='{date_kr}'
    AND B.TR_YMD='{date_us}'
    AND FUND_NM = '{etf_name}') A) A 
    """
    df = pd.read_sql(query, conn)
    conn.close()
    return df
# ETF 구성종목 데이터 가져오기

def get_etf_data2(etf_name, selected_date):
    conn = DB.conn()
    
    date_kr=f"""SELECT MAX(TR_YMD) TR_YMD FROM FN_ETFINFO WHERE TR_YMD<='{selected_date}'"""  
    date_kr = pd.read_sql(date_kr, conn)['TR_YMD'][0]
    date_us=f"""SELECT MAX(TR_YMD) TR_YMD FROM QUANT1.DBO.EOD0JG WHERE TR_YMD<{date_kr}AND JM_NM='APPLE'"""
    date_us = pd.read_sql(date_us, conn)['TR_YMD'][0]
    query = f"""
    SELECT JM_NM constituent_name,JM_CD, CT_RT performance, JM_WT weight fROM (
    SELECT A.*,RANK() OVER (ORDER BY JM_WT DESC) RK FROM (
    SELECT KSD_FUND_CD,FUND_NM,A.JM_NM,B.JM_CD,A.JM_WT,B.RT/100 CT_RT fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.FN_STOCK B 
    WHERE A.JM_KSD_CD =SUBSTRING(B.JM_CD,2,6) AND A.TR_YMD=B.TR_YMD AND A.TR_YMD='20241128' AND FUND_NM ='{etf_name}'
    UNION
    SELECT KSD_FUND_CD,FUND_NM,A.JM_NM,B.JM_CD,A.JM_WT, ROUND((B.JONGGA /C.JONGGA-1),4) CT_RT  
    fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.EOD0JG  B , QUANT1.DBO.EOD0JG  c 
    WHERE A.JM_KSD_CD =B.JM_CD 
    AND A.TR_YMD='20241128'
    AND B.TR_YMD='20241127'
    AND C.TR_YMD='20241101'
    AND C.JM_CD = B.JM_CD
    AND FUND_NM = '{etf_name}') A) A 
    """
    df = pd.read_sql(query, conn)
    conn.close()
    return df


# NAV 변동률 가져오기
def get_nav_chg(etf_name, selected_date):
    conn = DB.conn()
    query = f"""SELECT NAV_CHG_1D FROM FN_ETFDATA 
    WHERE TR_YMD=(SELECT MAX(TR_YMD) FROM FN_ETFINFO WHERE TR_YMD<='{selected_date}') 
    AND etf_nm='{etf_name}'"""
    df = pd.read_sql(query, conn)
    conn.close()
    return df['NAV_CHG_1D'][0]

# NAV 변동률 가져오기
def get_nav_chg2(etf_name, selected_date):
    conn = DB.conn()
    query = f"""SELECT (A.ETF_NAV/B.ETF_NAV-1)*100 NAV_CHG_1D fROM FN_ETFDATA A, FN_ETFDATA B WHERE A.TR_YMD='20241128' AND B.TR_YMD='20241104' AND A.ETF_CD=B.ETF_CD AND A.ETF_NM='{etf_name}'"""
    df = pd.read_sql(query, conn)
    conn.close()
    return df['NAV_CHG_1D'][0]
    
##### 호가 알람용 상품 및 매니저 데이터 가져오기 (상폐시 제외해줘야함) (LP호가신고스프레드) 
def get_etf_manager():
    conn = DB.conn()
    query = """ DECLARE @TRD_DT VARCHAR(8)
            	SET @TRD_DT = (select max(TR_YMD) from FN_ETFDATA WHERE ETF_CD='A105190' AND TR_YMD<=GETDATE())
        SELECT BB.FUND_CD, AA.ETF_NM, BB.STK_CD, BB.rp_spread, BB.SP_TYP, CC.OS_GB, DD.MANAGER
            FROM (select ETF_CD, ETF_NM from FN_ETFINFO where TR_YMD = @TRD_DT and ETF_NM like '%ACE%') as AA
            LEFT OUTER JOIN (select FUND_CD, STK_CD, rp_spread, SP_TYP from ES_FUND_MAP) BB on AA.ETF_CD = BB.STK_CD
            LEFT OUTER JOIN (select FUND_ID, OS_GB from BF000401) CC on BB.FUND_CD = CC.FUND_ID 
            LEFT OUTER JOIN (select FUND_CD, MANAGER from ES_MANAGER_MAST) DD on BB.FUND_CD = DD.FUND_CD
            where BB.FUND_CD != '9001C' and BB.FUND_CD != '9003H' and BB.FUND_CD != '9002N'
        
    """
    df = pd.read_sql(query, conn)
    conn.close()
    
    # 액티브 ETF 예외처리 
    for index, row in df.iterrows():
        if pd.isnull(row['OS_GB']):  # 'OS_GB' 값이 NULL일 경우
            if '미국' in row['ETF_NM'] or '테슬라' in row['ETF_NM'] or '엔비디아' in row['ETF_NM'] or '애플' in row['ETF_NM'] or '구글' in row['ETF_NM'] or '마이크로소프트' in row['ETF_NM'] or '글로벌' in row['ETF_NM'] or 'G2' in row['ETF_NM']:  # 'ETF_NM' 값에 '미국'이 포함될 경우
                df.at[index, 'OS_GB'] = '해외'
            else:
                df.at[index, 'OS_GB'] = '국내'
                
    return df
    

##### 호가 알람용 상품 및 매니저 데이터 가져오기 (상폐시 제외해줘야함) (LP호가이모티) 
def get_etf_spread():
    conn = DB.conn()
    query = """ select SUBSTRING(B.STK_CD,2,6) ETF_CD,c.ETF_NM,SP_TYP,D.ETF_MKT_BIG,A.MANAGER From ES_MANAGER_MAST A, ES_FUND_MAP B,FN_eTFINFO C, ES_SECTOR_MASTER D WHERE A.FUND_CD=B.FUND_cD AND B.STK_CD=D.STK_CD AND C.ETF_CD=B.STK_CD AND C.TR_YMD=(SELECT MAX(TR_YMD) FROM FN_ETFINFO WHERE TR_YMD<=GETDATE()) and D.STK_CD NOT IN ('A461260', 'A265690', 'A411050')"""
    df = pd.read_sql(query, conn)
    conn.close()
                
    return df

##### 호가 알람용 LP 데이터 가져오기
def get_etf_lp_amt():
    conn = DB.conn()
    query = """ DECLARE @TRD_DT_A VARCHAR(8),
                		@TRD_DT_K VARCHAR(8),
                		@TRD_DT VARCHAR(8)
                	SET @TRD_DT_A = (select max(STD_DT) from ETF_APAUM where GUBN = 'A' AND STD_DT<=GETDATE())
                	SET @TRD_DT_K = (select max(STD_DT) from ETF_APAUM where GUBN = 'K' AND STD_DT<=GETDATE())
                	SET @TRD_DT = (select max(TRD_DT) from ES_FUND_PRC_RAW where FUND_CD='9000A' AND TRD_DT<=GETDATE())
                select @TRD_DT, BB.STK_CD,
                		BB.FUND_NM,
                		AA.LP,
                		AA.AP_CNT,
                		CC.STD_PRC,
                		round(AA.AP_CNT * CC.STD_PRC/100000000, 2) as [AP_AMT]
                FROM ((SELECT STD_DT, KSD_FUND_CD as [ISIN_CD], AP_NM as [LP], HOLD_QTY as [AP_CNT] from ETF_APAUM where GUBN='K' AND STD_DT=@TRD_DT_K) UNION ALL (SELECT STD_DT, ETF_CD as [ISIN_CD], AP_NM as [LP], HOLD_AMT as [AP_CNT] from ETF_APAUM where GUBN = 'A' AND STD_DT=@TRD_DT_A)) AA
                LEFT OUTER JOIN (SELECT STK_CD, ISIN_CD, FUND_NM, FUND_CD from ES_FUND_MAP where FUND_NM like '%ACE%') BB on AA.ISIN_CD = BB.ISIN_CD
                LEFT OUTER JOIN (SELECT FUND_CD, STD_PRC from ES_FUND_PRC_RAW where TRD_DT = @TRD_DT) CC on BB.FUND_CD = CC.FUND_CD
                where AA.AP_CNT != 0 and (BB.FUND_CD != '9001L' and BB.FUND_CD != '9001K' and BB.FUND_CD != '9002N')
    """
    df = pd.read_sql(query, conn)
    conn.close()
    
    sum_amt = df.groupby('STK_CD')['AP_AMT'].sum().reset_index()
    sum_amt.rename(columns={'AP_AMT':'SUM_AMT'}, inplace=True)
    
    df = df.merge(sum_amt, on='STK_CD')
    
    df['AP_PCT'] = round((df['AP_AMT'] / df['SUM_AMT']) * 100, 2)
                
    return df

# 마켓 데이터
def get_etf_mkt():
    conn = DB.conn()
    query = """ DECLARE @TRD_DT VARCHAR(8)
            	SET @TRD_DT = (select max(TR_YMD) from FN_ETFDATA WHERE ETF_CD='A105190' AND TR_YMD<=GETDATE())
            SELECT SUBSTRING(A.ETF_CD,2,6) ETF_CD, A.ETF_NM, B.ETF_AST_MID
            from (select * from FN_ETFDATA where TR_YMD = @TRD_DT and ETF_NM like 'ACE%') as A
            left outer join (select STK_CD, ETF_AST_MID from ES_SECTOR_MASTER) as B on A.ETF_CD = B.STK_CD
    """
    df = pd.read_sql(query, conn)
    conn.close()
                
    return df


# ETF 가격조회 함수
def ETF_price2(stk_list):
    
    # 토큰발급
    APP_KEY = "PSGrbiZHQ5qatRI1NHcDZykOZVFwlyoUm5cg"
    APP_SECRET = "vSCjzXG5f13jcSNKRe6XOjAvAQpUxPhx"

    BASE_URL = "https://openapi.ls-sec.co.kr:8080"
    PATH = "oauth2/token"
    URL = f"{BASE_URL}/{PATH}"
    headers = {"content-type": "application/x-www-form-urlencoded"}

    data_key = "appkey=" + APP_KEY + "&appsecretkey=" + APP_SECRET + "&grant_type=client_credentials&scope=oob"

    res = requests.post(URL, headers=headers, data=data_key, verify=False)
    ACCESS_TOKEN = res.json()["access_token"]
    
    
    # 가격 조회 
    PATH = "stock/market-data"
    URL = f"{BASE_URL}/{PATH}"

    header = {
        "content-type": "application/json; charset=utf-8",
        "authorization": f"Bearer {ACCESS_TOKEN}",
        "tr_cd": "t8407",
        "tr_cont": "N",
        "tr_cont_key": "",
    }

    body = {
        "t8407InBlock":
        {
            "shcode": stk_list
        }
    }

    requset = requests.post(URL, headers=header, data=json.dumps(body), verify=False)
    df = pd.DataFrame(requset.json()["t8407OutBlock1"])
    return df

def etf_list_kr():
    conn = DB.conn()
    query = """SELECT SUBSTRING(A.ETF_CD, 2, 6) AS ETF_CD, A.ETF_NM, AUM FROM FN_ETFDATA A, FN_ETFINFO B WHERE A.TR_yMD = (SELECT MAX(TR_yMD) FROM FN_ETFINFO WHERE TR_YMD <= GETDATE()) AND A.ETF_NM LIKE 'ACE%' AND A.ETF_CD = B.ETF_CD AND B.CLASS_BIG LIKE '%국내주식%' AND A.TR_YMD = B.TR_YMD"""
    df = pd.read_sql(query, conn)
    conn.close()
                
    return df

def etf_list_gl():
    conn = DB.conn()
    query = """SELECT SUBSTRING(A.ETF_CD, 2, 6) AS ETF_CD, A.ETF_NM, AUM FROM FN_ETFDATA A, FN_ETFINFO B WHERE A.TR_yMD = (SELECT MAX(TR_yMD) FROM FN_ETFINFO WHERE TR_YMD <= GETDATE()) AND A.ETF_NM LIKE 'ACE%' AND A.ETF_CD = B.ETF_CD AND B.CLASS_BIG  LIKE '%해외주식%' AND A.TR_YMD = B.TR_YMD"""
    df = pd.read_sql(query, conn)
    conn.close()
                
    return df

def top5():
    conn = DB.conn()
    query = """
                SELECT A.종목명,A.관련뉴스요약,A."ACE 편입여부",A.상승률 변동률,A.편입비중 fROM (SELECT A.*, CASE WHEN "ACE 편입여부"='-' THEN RK ELSE 0 END NEW_RK FROM (
                select
                	A.JM_NM '종목명',
                	SUMMARY '관련뉴스요약',
                	CASE
                		WHEN B.FUND_NM IS NOT NULL THEN B.FUND_NM
                		ELSE '-'
                	END 'ACE 편입여부',
                	RT '상승률',
                	round(ISNULL(JM_WT, 0), 2) '편입비중', RANK() OVER (ORDER BY RT DESC) RK
                From
                	STOCK_NEWS_LIVE A
                LEFT OUTER JOIN QUANT1.DBO.FDTWB_ETFPDF B ON
                	A.JM_NM = B.JM_NM
                	AND B.TR_yMD = (SELECT MAX(TR_yMD) FROM FN_ETFDATA WHERE TR_yMD<=GETDATE())
                	AND B.FUND_NM LIKE 'ACE%'
                WHERE TD_GB='T' AND A.JM_NM NOT in (select etf_nm from fn_etfinfo where tr_Ymd=(SELECT MAX(TR_yMD) FROM FN_ETFDATA WHERE TR_yMD<=GETDATE())) AND A.JM_NM NOT LIKE '%ETN%') A ) A WHERE NEW_RK<=3
            """
    df = pd.read_sql(query, conn)
    conn.close()
                
    df['편입비중'] = df['편입비중'].astype(str)

    # Combine ETF명 and 편입비중 for rows with the same '종목명', '요약', and '상승률'
    df = df.groupby(['종목명', '관련뉴스요약', '변동률']).agg({
        'ACE 편입여부': ', '.join,
        '편입비중': ', '.join
    }).reset_index()

    df = df.sort_values(by='변동률',ascending=False)
    
    df['변동률'] = df['변동률'].apply(lambda x: f"{x}%")
    df['편입비중'] = df['편입비중'].apply(lambda x: f"{x}%")
    df.rename(columns={'변동률':'변동률(%)','편입비중':'편입비중(%)'}, inplace=True)
    
    return df

def bottom5():
    conn = DB.conn()
    query = """
    SELECT A.종목명,A.관련뉴스요약,A."ACE 편입여부",A.하락률 변동률,A.편입비중 fROM (SELECT A.*, CASE WHEN "ACE 편입여부"='-' THEN RK ELSE 0 END NEW_RK FROM (
    select
    	A.JM_NM '종목명',
    	SUMMARY '관련뉴스요약',
    	CASE
    		WHEN B.FUND_NM IS NOT NULL THEN B.FUND_NM
    		ELSE '-'
    	END 'ACE 편입여부',
    	RT '하락률',
    	round(ISNULL(JM_WT, 0), 2) '편입비중', RANK() OVER (ORDER BY RT ASC) RK
    From
    	STOCK_NEWS_LIVE A
    LEFT OUTER JOIN QUANT1.DBO.FDTWB_ETFPDF B ON
    	A.JM_NM = B.JM_NM
    	AND B.TR_yMD = (SELECT MAX(TR_yMD) FROM FN_ETFDATA WHERE TR_yMD<=GETDATE())
    	AND B.FUND_NM LIKE 'ACE%'
    WHERE TD_GB='B' AND A.JM_NM NOT in (select etf_nm from fn_etfinfo where tr_Ymd=(SELECT MAX(TR_yMD) FROM FN_ETFDATA WHERE TR_yMD<=GETDATE())) AND A.JM_NM NOT LIKE '%ETN%' ) A ) A WHERE NEW_RK<=3

    """
    df = pd.read_sql(query, conn)
    conn.close()
    
    df['편입비중'] = df['편입비중'].astype(str)

    # Combine ETF명 and 편입비중 for rows with the same '종목명', '요약', and '상승률'
    df = df.groupby(['종목명', '관련뉴스요약', '변동률']).agg({
        'ACE 편입여부': ', '.join,
        '편입비중': ', '.join
    }).reset_index()

    df=df.sort_values(by='변동률',ascending=True)
    df['변동률'] = df['변동률'].apply(lambda x: f"{x}%")
    df['편입비중'] = df['편입비중'].apply(lambda x: f"{x}%")
    df.rename(columns={'변동률':'변동률(%)','편입비중':'편입비중(%)'}, inplace=True)
                
    return df


def kr_stock():
    
    conn = DB.conn()
    query = """SELECT * fROM (select SUBSTRING(JM_CD,2,6) JM_CD,JM_NM,TM_AMT,CASE WHEN SUBSTRING(IND_GR,6,2)=10 THEN '에너지'
    						WHEN SUBSTRING(IND_GR,6,2)=15 THEN '소재'
    						WHEN SUBSTRING(IND_GR,6,2)=20 THEN '산업재'
    						WHEN SUBSTRING(IND_GR,6,2)=25 THEN '경기소비재'
    						WHEN SUBSTRING(IND_GR,6,2)=30 THEN '필수소비재'
    						WHEN SUBSTRING(IND_GR,6,2)=35 THEN '의료'
    						WHEN SUBSTRING(IND_GR,6,2)=40 THEN '금융'
    						WHEN SUBSTRING(IND_GR,6,2)=45 THEN 'IT'
    						WHEN SUBSTRING(IND_GR,6,2)=50 THEN '통신서비스'
    						WHEN SUBSTRING(IND_GR,6,2)=55 THEN '유틸리티' END 'SECTOR', RANK() OVER (PARTITION BY TR_yMD ORDER BY TM_AMT DESC) RK From QUANT1.DBO.FN_STOCK WHERE TR_yMD=(SELECT MAX(TR_yMD) FROM FN_ETFINFO WHERE TR_YMD<=GETDATE()) AND SECTOR IS NOT NULL) A WHERE RK<=200"""
    df = pd.read_sql(query, conn)
    conn.close()
                
    return df

def us_stock():

    conn = DB.conn()
    query = """SELECT *
                    FROM
                    	(
                    	SELECT
                    		JM_NM,
                    		ROUND((JONGGA / BF_JONGGA-1)*100,2) diff,
                    		MV,CASE WHEN gics_eupj1=10 THEN '에너지'
                    						WHEN gics_eupj1=15 THEN '소재'
                    						WHEN gics_eupj1=20 THEN '산업재'
                    						WHEN gics_eupj1=25 THEN '경기소비재'
                    						WHEN gics_eupj1=30 THEN '필수소비재'
                    						WHEN gics_eupj1=35 THEN '의료'
                    						WHEN gics_eupj1=40 THEN '금융'
                    						WHEN gics_eupj1=45 THEN 'IT'
                    						WHEN gics_eupj1=50 THEN '통신서비스'
                    						WHEN gics_eupj1=55 THEN '유틸리티' 
                    						WHEN gics_eupj1=60 THEN '부동산' END 'SECTOR',
                    		RANK() OVER (PARTITION BY TR_YMD
                    	ORDER BY
                    		MV DESC) RK
                    	fROM
                    		QUANT1.DBO.EOD0JG ej
                    	WHERE
                    		TR_YMD =(
                    		SELECT
                    			MAX(TR_YMD)
                    		FROM
                    			QUANT1.DBO.EOD0JG)
                    		AND MONEY_GB = 'USD'
                    		AND BF_JONGGA IS NOT NULL) A
                    WHERE
                    	RK <= 300  AND SECTOR IS NOT NULL"""
    
    df = pd.read_sql(query, conn)
    conn.close()
                
    return df

def etf_sector():
    
    conn = DB.conn()
    query = """
    SELECT SUBSTRING(STK_CD,2,6) ETF_CD,ETF_AST_MID SECTOR fROM ES_SECTOR_MASTER esm WHERE ETF_AST_BIG='주식'
    """
    
    df = pd.read_sql(query, conn)
    conn.close()
                
    return df

def stock_sector():
    conn = DB.conn()
    query = """
    select JM_NM,JM_CD,CASE WHEN SUBSTRING(IND_GR,6,2)=10 THEN '에너지'
    						WHEN SUBSTRING(IND_GR,6,2)=15 THEN '소재'
    						WHEN SUBSTRING(IND_GR,6,2)=20 THEN '산업재'
    						WHEN SUBSTRING(IND_GR,6,2)=25 THEN '경기소비재'
    						WHEN SUBSTRING(IND_GR,6,2)=30 THEN '필수소비재'
    						WHEN SUBSTRING(IND_GR,6,2)=35 THEN '의료'
    						WHEN SUBSTRING(IND_GR,6,2)=40 THEN '금융'
    						WHEN SUBSTRING(IND_GR,6,2)=45 THEN 'IT'
    						WHEN SUBSTRING(IND_GR,6,2)=50 THEN '통신서비스'
    						WHEN SUBSTRING(IND_GR,6,2)=55 THEN '유틸리티' END 'SECTOR'
    						From QUANT1.DBO.FN_STOCK WHERE TR_yMD=(select max(tr_ymd) from fn_etfinfo where tr_ymd<=getdate())
    						union
    						SELECT jm_nm,jm_cd,CASE WHEN gics_eupj1=10 THEN '에너지'
    						WHEN gics_eupj1=15 THEN '소재'
    						WHEN gics_eupj1=20 THEN '산업재'
    						WHEN gics_eupj1=25 THEN '경기소비재'
    						WHEN gics_eupj1=30 THEN '필수소비재'
    						WHEN gics_eupj1=35 THEN '의료'
    						WHEN gics_eupj1=40 THEN '금융'
    						WHEN gics_eupj1=45 THEN 'IT'
    						WHEN gics_eupj1=50 THEN '통신서비스'
    						WHEN gics_eupj1=55 THEN '유틸리티' 
    						WHEN gics_eupj1=60 THEN '부동산' END 'SECTOR' fROM  QUANT1.DBO.EOD0JG where tr_ymd=(select max(tr_ymd) from QUANT1.DBO.EOD0JG where tr_ymd<=getdate())"""
    
    df = pd.read_sql(query, conn)
    conn.close()
    
    df = df.rename(columns={'JM_NM': 'constituent_name'})
                
    return df

def volume_etf():
    
    conn = DB.conn()
    query = """
    SELECT ETF_NM ,round(TRD_AMT_AVG_20/1000000,0) TRD_AMT_AVG20 FROM FN_ETFDATA WHERE TR_yMD=(SELECT MAX(TR_yMD) FROM FN_ETFDATA WHERE TR_yMD<=GETDATE()) AND ETF_NM LIKE 'ACE%' 
    """
    
    df = pd.read_sql(query, conn)
    conn.close()
                
    return df


# API로 데이터 가져오기 
def main():
    
    # dataframe 불러오기
    df_list_kr = etf_list_kr()
    df_list_gl = etf_list_gl()
    list_kr_stk = kr_stock()
    
    # ETF 코드 목록 생성
    listkr_1 = df_list_kr['ETF_CD'][:50].astype(str).str.cat(sep='')
    listkr_2 = df_list_kr['ETF_CD'][50:].astype(str).str.cat(sep='')

    listgl_1 = df_list_gl['ETF_CD'][:50].astype(str).str.cat(sep='')
    listgl_2 = df_list_gl['ETF_CD'][50:].astype(str).str.cat(sep='')
    
    list1 = list_kr_stk['JM_CD'][:50].astype(str).str.cat(sep='')
    list2 = list_kr_stk['JM_CD'][50:100].astype(str).str.cat(sep='')
    list3 = list_kr_stk['JM_CD'][100:150].astype(str).str.cat(sep='')
    list4 = list_kr_stk['JM_CD'][150:200].astype(str).str.cat(sep='')


    df1 = ETF_price2(listkr_1)
    time.sleep(1.5)
    
    if len(listkr_2)>0:
        df2 = ETF_price2(listkr_2)
        time.sleep(1.5)
        df_final_kr = pd.concat([df1, df2])
    else:
        df_final_kr=df1
        
        
    df3 = ETF_price2(listgl_1)
    time.sleep(1.5)
    
    if len(listgl_2)>0:              
        df4 = ETF_price2(listgl_2)
        time.sleep(1.5)  
        df_final_gl = pd.concat([df3, df4])
    
    else:
        df_final_gl=df3

    df5 = ETF_price2(list1)
    time.sleep(1.5)
    df6 = ETF_price2(list2)
    time.sleep(1.5)    
    df7 = ETF_price2(list3)
    time.sleep(1.5)
    df8 = ETF_price2(list4)
    

    
    df_final_kr = df_final_kr[df_final_kr['price'] != 0]
    df_final_kr = df_final_kr.rename(columns={'shcode': 'ETF_CD', 'hname': 'ETF_NM'})

    df_final_kr = pd.merge(df_final_kr, df_list_kr, on=['ETF_CD', 'ETF_NM'], how='inner')
    df_final_kr['Value (%)'] = df_final_kr['diff'].apply(convert_to_percentage)
    df_final_kr['diff'] = df_final_kr['diff'].astype(float)

    
    df_final_gl = df_final_gl[df_final_gl['price'] != 0]
    df_final_gl = df_final_gl.rename(columns={'shcode': 'ETF_CD', 'hname': 'ETF_NM'})

    df_final_gl = pd.merge(df_final_gl, df_list_gl, on=['ETF_CD', 'ETF_NM'], how='inner')
    df_final_gl['Value (%)'] = df_final_gl['diff'].apply(convert_to_percentage)
    df_final_gl['diff'] = df_final_gl['diff'].astype(float)
    
    
    ##국내주식
    df_stk_kr = pd.concat([df5, df6, df7, df8])
    df_stk_kr = df_stk_kr.rename(columns={'shcode': 'JM_CD', 'hname': 'JM_NM'})

    df_stk_kr = pd.merge(df_stk_kr, list_kr_stk, on=['JM_CD', 'JM_NM'], how='inner')
    df_stk_kr['Value (%)'] = df_stk_kr['diff'].apply(convert_to_percentage)
    df_stk_kr['diff'] = df_stk_kr['diff'].astype(float)

    return df_final_kr, df_final_gl, df_stk_kr



