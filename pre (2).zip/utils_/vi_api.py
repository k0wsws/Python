# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 10:01:23 2024

@author: USER
"""

import json
import websocket
import requests
from functools import partial
import pandas as pd
import threading
import time
import pickle
import pre.DB_ETF as DB
import api_keys as key


print("VI start")

# 토큰발급

APP_KEY=key.ls_api_key()[0]
APP_SECRET=key.ls_api_key()[1]


BASE_URL = "https://openapi.ls-sec.co.kr:8080"
PATH = "oauth2/token"
URL = f"{BASE_URL}/{PATH}"
headers = {"content-type": "application/x-www-form-urlencoded"}

data_key = "appkey=" + APP_KEY + "&appsecretkey=" + APP_SECRET + "&grant_type=client_credentials&scope=oob"

res = requests.post(URL, headers=headers, data=data_key, verify=False)
ACCESS_TOKEN = res.json()["access_token"]

# 결과 dataframe (init)
result_df = pd.DataFrame(columns=['shcode', 'vi_gubun', 'vi_trgprice'])

def get_etf_data():
    conn = DB.conn()
    query = """DECLARE @TRD_DT VARCHAR(8)
            	SET @TRD_DT = (select max(TR_YMD) from FN_ETFDATA WHERE ETF_CD='A105190' AND TR_YMD<=GETDATE())
                SELECT SUBSTRING(ETF_CD,2,6) ETF_CD, ETF_NM from FN_ETFDATA where TR_YMD = @TRD_DT and ETF_NM like 'ACE%' 
    """
    df = pd.read_sql(query, conn)
    conn.close()
    
    return df

##### DataFrame -> pickle file (호가 알람)
def save_dataframe_to_pickle(df, filename):
    with open(filename, "wb") as f:
        pickle.dump(df, f)  # DataFrame을 pickle 형식으로 저장

## 
def process_message(msg_data):
    try:
        if msg_data is None or 'body' not in msg_data or msg_data['body'] is None:
            print("Invalid message data received:", msg_data)
            return
        
        vi_gubun = msg_data['body']['vi_gubun']
        shcode = msg_data['body']['shcode']
        vi_trgprice = res['body']['vi_trgprice']
        print(vi_gubun, shcode)
        
        global result_df
        
        if shcode in result_df['shcode'].values:
            # 존재하면 해당 행 업데이트
            result_df.loc[result_df['shcode'] == shcode, ['vi_gubun', 'vi_trgprice']] = vi_gubun, vi_trgprice
        else:
            # 존재하지 않으면 새로운 행 추가
            new_data = {'shcode': shcode, 'vi_gubun': vi_gubun, 'vi_trgprice': vi_trgprice}
            result_df.loc[len(result_df)] = new_data
            
        # # 업데이트된 DataFrame 출력
        # print("Updated Result Dataframe:\n", result_df)
        
        # # print("Result Dataframe: ", result_df)
        if not result_df.empty:    
            save_dataframe_to_pickle(result_df, "data/vi_data.pkl")
        #     top_5_df = result_df.loc[result_df['chg_rate'].abs().nlargest(5).index]
        #     save_dataframe_to_pickle(top_5_df, "chg_data.pkl")
        #     print("Top5: ", top_5_df)
    except KeyError as e:
        print("KeyError:Check message structure.")
    except Exception as e:
        print("Error in process_message")
        # Error in process_message: unsupported operand type(s) for /: 'str' and 'str'
    
    
# WebSocket 콜백 함수 정의
def on_open(ws, stk_cd):
    # print(f"{stk_cd} WebSocket 연결됨")
    
    # 전송할 메시지 생성 (예: 주문 상태 요청)
    message = {"header":{"token": ACCESS_TOKEN,"tr_type":"3"}, 
               "body":{"tr_cd": "VI_","tr_key": stk_cd}}
    
    # JSON 형식으로 메시지를 전송
    ws.send(json.dumps(message))


def on_message(ws, message):
    print("수신된 메시지:", message)
    msg_data = json.loads(message)
    process_message(msg_data)      
    

def on_error(ws, error):
    print("오류 발생:", error)

def on_close(ws):
    print("WebSocket 연결 종료")

def run_websocket(stk_cd):
    url = "wss://openapi.ls-sec.co.kr:9443/websocket"  # 운영 도메인
    while True:
        ws = websocket.WebSocketApp(url,
                                on_open=partial(on_open, stk_cd=stk_cd),  # stk_cd를 파라미터로 전달
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close)
        
        try:
            ws.run_forever()  # Keep the connection alive
            break  # Break the loop if the connection is successful
        except Exception as e:
            print("WebSocket connection error. Reconnecting...")
            time.sleep(3)

def main(stock_codes):
    # 각 주식 코드에 대해 스레드를 생성하여 WebSocket 연결
    threads = []
    for stk_cd in stock_codes:
        t = threading.Thread(target=run_websocket, args=(stk_cd,))
        t.start()
        threads.append(t)

    # 모든 스레드가 종료될 때까지 대기
    for t in threads:
        t.join()
    print("쓰레드 종료")


if __name__ == "__main__":
    
    df = get_etf_data()
    stock_codes = df['ETF_CD'].values.tolist()
    
    main(stock_codes)
    
    
