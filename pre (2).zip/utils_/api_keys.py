# -*- coding: utf-8 -*-
"""
Created on Sat Oct 19 09:59:25 2024

@author: USER
"""

def openai_api_key():
    key='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'
    if key=='':
        return print('openai api 키를 등록하세요')
    else:
        return key

def Anthropic_api_key():
    key='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'
    if key=='':
        return print('Anthropic api 키를 등록하세요')
    else:
        return key


def ls_api_key():
    
    APP_KEY="PSi6qqFcUm3hpUbEx3Mp9sxjaipgbnXlPEoM"
    APP_SECRET="aTSKrNzM0hipMXbHWIvFAUjcBCgJQ1ph"
    
    if APP_KEY=='':
        print('ls증권 api 키를 등록하세요')
    
    else:
        return APP_KEY,APP_SECRET


def twilio_api_key():
    
    sid="AC13be6881ba6dd1a2308b8b9442d9ab8a"
    token="e5dcb4221249d64d6faa7431fd3bea3b"
    
    if sid=='':
        print('twilio api 키를 등록하세요')
    
    else:
        return sid,token