# -*- coding: utf-8 -*-
"""
Created on Thu Sep 19 13:06:34 2024

@author: USER
"""

# 국내 주식 종목별 뉴스 가져오기 (네이버 뉴스)
# 1. DB의 JM_MAST 테이블에서 국내 주식 티커 불러오기
# 2. JM_KSD_CD를 활용하여 "https://finance.naver.com/item/news.naver?code=" + ticker 로 뉴스/공시 사이트 조회
# 3. 최근 뉴스 10개+@ -> 제목, 링크 가져오기
# 4. 각 링크마다 뉴스 본문 가져오기 

#필요한 라이브러리 
import pandas as pd 
import random
import ssl
from selenium import webdriver
from selenium.webdriver.common.by import By
import pre.crawl_list as cl
from datetime import datetime, timedelta
import path_set as ps
import requests
from bs4 import BeautifulSoup

root=ps.path()

today = datetime.now().date()
today_date = datetime.now().strftime("%Y%m%d")
input_date = (datetime.now() - timedelta(1)).strftime('%Y%m%d')
yesterday = (datetime.now() - timedelta(2)).strftime('%Y%m%d')

def reformat_date(date_obj):

    date_str = date_obj.strftime('%Y-%m-%d')
    formatted_date = date_str.replace('-', '.')
    return formatted_date

formatted_date = reformat_date(today)

def parsing_timestamps(df): 
    previous_date = None   
    for i, timestamp in enumerate(df['Timestamp']):
        if 'Today' in timestamp:
            df.at[i, 'Timestamp'] = input_date
            previous_date = input_date  
        elif any(month in timestamp for month in ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']):
            parsed_date = datetime.strptime(timestamp, "%b-%d-%y %I:%M%p").strftime("%Y-%m-%d")
            previous_date = parsed_date.split()[0]  
            df.at[i, 'Timestamp'] = parsed_date
        else:
            if previous_date:
                df.at[i, 'Timestamp'] = f"{previous_date}"
    
    return df


def get_timestamp(raw_time):
    """
    Convert raw time format from Finviz to a standardized datetime format.
    Finviz shows times like '5 minutes ago' or dates like 'Apr-20-23'.
    """
    current_time = datetime.datetime.now()
    if 'minute' in raw_time:
        minutes = int(raw_time.split()[0])
        timestamp = current_time - datetime.timedelta(minutes=minutes)
    elif 'hour' in raw_time:
        hours = int(raw_time.split()[0])
        timestamp = current_time - datetime.timedelta(hours=hours)
    elif 'day' in raw_time:
        days = int(raw_time.split()[0])
        timestamp = current_time - datetime.timedelta(days=days)
    else:
        # Assuming format like 'Apr-20-23'
        timestamp = datetime.datetime.strptime(raw_time, '%b-%d-%y')
    return timestamp.strftime('%Y-%m-%d %H:%M:%S')

def global_news_crawler(ticker):

    url = f"https://finviz.com/quote.ashx?t={ticker}&p=d"
    
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' \
                      'AppleWebKit/537.36 (KHTML, like Gecko) ' \
                      'Chrome/116.0.0.0 Safari/537.36'
    }
    
    response = requests.get(url, headers=headers,verify=False)
    
    if response.status_code != 200:
        print(f"Failed to load page {url} (Status code: {response.status_code})")
        df=[]
    
    else:
        
        try:
            # Parse the HTML content using BeautifulSoup    
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Find the news table
            # On Finviz, news are typically within tables with class 'fullview-news-outer'
            news_table = soup.find('table', class_='fullview-news-outer')
            
            # Initialize a list to store news items
            news_items = []
            
            # Iterate through each row in the news table
            for row in news_table.find_all('tr'):
                # Each row has two cells: one for the timestamp and one for the news
                cells = row.find_all('td')
                if len(cells) != 2:
                    continue  # Skip rows that don't have exactly 2 cells
            
                # Extract timestamp
                raw_time = cells[0].text.strip()
                timestamp = raw_time
            
                # Extract news title and link
                news_link = cells[1].find('a')
                if news_link:
                    title = news_link.text.strip()
                    link = news_link['href']
                else:
                    title = cells[1].text.strip()
                    link = ''
            
                # Append the news item to the list
                news_items.append({'Ticker':ticker,
                    'Timestamp': timestamp,
                    'Title': title,
                    'Link': link
                })
            
            # Convert the list of news items to a pandas DataFrame
            df = pd.DataFrame(news_items)
        
        except AttributeError as e:
            df=[]
    
    return df


# 특정 종목의 네이버 뉴스 크롤링 
def news_crawl(jm_cd, jm_nm, articles):
    
    USER_AGENTS = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/98.0.4758.102',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/98.0.4758.104',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/98.0.4758.110',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) Chrome/98.0.4758.102'
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) Chrome/98.0.4258.101'
    ]
    
    headers = {'User-Agent': random.choice(USER_AGENTS)}
    
    ssl.SSLContext.verify_mode = ssl.VerifyMode.CERT_OPTIONAL
    ssl._create_default_https_context = ssl._create_unverified_context
    
    driver = webdriver.Edge()
    url = f'https://finance.naver.com/item/news.naver?code={jm_cd}'
    driver.get(url)
    
    driver.switch_to.default_content()
    driver.switch_to.frame('news')
    
    try:
        rows = driver.find_elements(By.CSS_SELECTOR, "table.type5 > tbody > tr")
        
        for row in rows:
            
            a_tag = row.find_element(By.CSS_SELECTOR, "td.title > a")
            link = a_tag.get_attribute('href')
            title = a_tag.text
            date = row.find_element(By.CSS_SELECTOR, "td.date").text.split(" ")[0]
            
            articles.append({'jm_cd': jm_cd, 'jm_nm': jm_nm, 'date': date, 'title': title, 'link': link})
    except :       
        articles.append({'jm_cd': jm_cd, 'jm_nm': jm_nm, 'date': today, 'title': '뉴스없음', 'link': ''})
        
def process_kr_news(date,cursor):

    list_kr = cl.crawl_list(date)[0]

    articles = []
    
    for index, row in list_kr.iterrows():
        # if index > 10: break
        ksd_cd = row["JM_KSD_CD"]
        nm = row["JM_NM"]
        
        news_crawl(ksd_cd, nm, articles)
        
    
    # print(articles)
    df = pd.DataFrame(articles)
    df = df.drop_duplicates(subset=['link'])
    df_ = df[df['date'] != '']
    df_ = df_.reset_index(drop=True)
    
    print(df_)
    df_.to_csv(root+f'news_kr_{date}.csv', index=False)

    # 데이터프레임 형식 : Index(['jm_cd', 'jm_nm', 'date', 'title', 'link'], dtype='object')
    df_ = df_.astype(str)
    df_['date'] = df_['date'].str.replace('.', '')
    df_['jm_cd'] = df_['jm_cd'].str.zfill(6)
    
    df_=df_[df_['date']>=input_date]


    # update DB
    for index,row in df_.iterrows():
        cursor.execute("INSERT INTO STOCK_NEWS_KR values(?,?,?,?,?)", row.date, row.jm_cd, row.jm_nm, row.title, row.link)

    cursor.commit()

def process_global_news(date,cursor):
    # 크롤링 데이터 불러오기
    list_gl = cl.crawl_list(date)[1]

    # 데이터프레임 초기화
    df = pd.DataFrame()

    # 각 아이템에 대해 뉴스 크롤링 및 데이터프레임 생성
    for i in list_gl['JM_KSD_CD']:
        print(i)
        news_data = global_news_crawler(i)
        if len(news_data) != 0:
            df = pd.concat([df, news_data])


    raw_csv_filename = root+f'Global_news_raw_{date}.csv'
    df.to_csv(raw_csv_filename, encoding="utf-8-sig")
    df_1 = pd.read_csv(raw_csv_filename)
    df_1 = df_1.drop(columns=['Unnamed: 0'])

    # 파싱 후 데이터 저장
    df_processed = parsing_timestamps(df_1)
    processed_csv_filename = root+f'news_global_{date}.csv'
    df_processed.to_csv(processed_csv_filename, index=False)
    
    # 해외 뉴스 CSV 불러오기 및 데이터베이스 업데이트
    df2 = pd.read_csv(processed_csv_filename, encoding='utf-8')
    df2 = df2.astype(str)
    df2['Timestamp'] = df2['Timestamp'].str.replace('-', '')
    
    df2=df2[df2['Timestamp']>=input_date]

    for index, row in df2.iterrows():
        cursor.execute("INSERT INTO STOCK_NEWS_GLOBAL values(?,?,?,?)", row.Timestamp, row.Ticker, row.Title, row.Link)

    cursor.commit()

    return processed_csv_filename


def process_top5_news():

    list_kr = cl.crawl_list_top5()[0:10]

    articles = []
    
    for index, row in list_kr.iterrows():
        # if index > 10: break
        ksd_cd = row["code"]
        nm = row["name"]
        
        news_crawl(ksd_cd, nm, articles)
        
    
    # print(articles)
    df = pd.DataFrame(articles)
    df = df.drop_duplicates(subset=['link'])
    df=df[df['date']==formatted_date]
    df_ = df[df['date'] != '']
    df_ = df_.reset_index(drop=True)
    
    print(df_)
    df_.to_csv(root+'news_daily_top.csv', index=False, encoding='cp949')
    
    return list_kr

def process_bot5_news():

    list_kr = cl.crawl_list_bot5()[0:10]

    articles = []
    
    for index, row in list_kr.iterrows():
        # if index > 10: break
        ksd_cd = row["code"]
        nm = row["name"]
        
        news_crawl(ksd_cd, nm, articles)
        
    
    # print(articles)
    df = pd.DataFrame(articles)
    df = df.drop_duplicates(subset=['link'])
    df=df[df['date']==formatted_date]
    df_ = df[df['date'] != '']
    df_ = df_.reset_index(drop=True)
    
    print(df_)
    df_.to_csv(root+'news_daily_bot.csv', index=False, encoding='cp949')
    
    return list_kr


   
