# -*- coding: utf-8 -*-
"""
Created on Tue May 14 09:54:39 2024

@author: USER
"""

import requests
import json
import pandas as pd
import time as tm
from datetime import datetime, timedelta, time
import pickle
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import pre.DB_ETF as DB
import path_set as ps
import api_keys as key

root=ps.path()

print("LP호가 알람 start")

##DB 접속
conn = DB.conn() 
cursor = conn.cursor()
    
# 호가 이모티용 dataframe
with open(root+"data2.pkl", "rb") as f:
    df_list = pickle.load(f)      


df_list=df_list[~df_list['SP_TYP'].isnull()]

APP_KEY=key.ls_api_key()[0]
APP_SECRET=key.ls_api_key()[1]

## 토큰발급
BASE_URL = "https://openapi.ls-sec.co.kr:8080"
PATH = "oauth2/token"
URL = f"{BASE_URL}/{PATH}"
headers = {"content-type":"application/x-www-form-urlencoded"}

data_key="appkey="+APP_KEY+"&appsecretkey="+APP_SECRET+"&grant_type=client_credentials&scope=oob"

warnings.simplefilter('ignore', InsecureRequestWarning)

res = requests.post(URL, headers=headers, data=data_key,verify=False)

ACCESS_TOKEN = res.json()["access_token"]



##ETF 개인순매수조회
def ETF_NET(STK_CD):
    
    BASE_URL = "https://openapi.ls-sec.co.kr:8080"
    PATH = "stock/frgr-itt"
    URL = f"{BASE_URL}/{PATH}"
    
    header = {  
        "content-type":"application/json; charset=utf-8", 
        "authorization": f"Bearer {ACCESS_TOKEN}",
        "tr_cd":"t1702", 
        "tr_cont":"N",
        "tr_cont_key":"",
    }
    
    body = {
  "t1702InBlock" : {
    "shcode" : STK_CD,
    "todt" : "",
    "volvalgb" : "0",
    "msmdgb" : "0",
    "cumulgb" : "0",
    "cts_date" : " ",
    "cts_idx" : 0
  }
}
        
    requset = requests.post(URL, headers=header, data=json.dumps(body),verify=False)
    
    return round(requset.json()["t1702OutBlock1"][0]['amt0008']/100,2)

    BASE_URL = "https://openapi.ls-sec.co.kr:8080"
    PATH = "/stock/frgr-itt"
    URL = f"{BASE_URL}/{PATH}"
    
    header = {  
        "content-type":"application/json; charset=utf-8", 
        "authorization": f"Bearer {ACCESS_TOKEN}",
        "tr_cd":"t1702", 
        "tr_cont":"N",
        "tr_cont_key":"",
    }
    
    body = {
        "t1702InBlock" : 
        {    
           "shcode" : '005930'
        }  
    }
        
    requset = requests.post(URL, headers=header, data=json.dumps(body),verify=False)
    
    return requset.json()["t1702OutBlock1"]

##ETF LP호가조회
def ETF_LP(STK_CD):
    BASE_URL = "https://openapi.ls-sec.co.kr:8080"
    PATH = "stock/etf"
    URL = f"{BASE_URL}/{PATH}"
    
    header = {  
        "content-type":"application/json; charset=utf-8", 
        "authorization": f"Bearer {ACCESS_TOKEN}",
        "tr_cd":"t1906", 
        "tr_cont":"N",
        "tr_cont_key":"",
    }
    
    body = {
        "t1906InBlock" : 
        {    
           "shcode" : STK_CD
        }  
    }
        
    requset = requests.post(URL, headers=header, data=json.dumps(body),verify=False)
    
    return requset.json()["t1906OutBlock"]


##ETF 스프레드조회


def ETF_INFO(STK_CD):
    BASE_URL = "https://openapi.ls-sec.co.kr:8080"
    PATH = "stock/etf"
    URL = f"{BASE_URL}/{PATH}"
    
    header = {  
        "content-type":"application/json; charset=utf-8", 
        "authorization": f"Bearer {ACCESS_TOKEN}",
        "tr_cd":"t1901", 
        "tr_cont":"Y",
        "tr_cont_key":"",
    }
    
    body = {
        "t1901InBlock" : 
        {    
           "shcode" : STK_CD
        }  
    }
        
    requset = requests.post(URL, headers=header, data=json.dumps(body),verify=False)
   
    
    return requset.json()["t1901OutBlock"]



def main():
    
    df_f=pd.DataFrame()
    df_lp=pd.DataFrame()
    
    for i in df_list['ETF_CD']:
        
        print(i)
        
        #data=ETF_INFO(i)
        data2=ETF_LP(i)
        #df2=pd.DataFrame({'ETF_CD':[i],'NAME':[data["hname"]],'INav':[data["nav"]],'Spread':[data["spread"]],'괴리율':[data["kasis"]],'VI_GB':[data["vi_gubun"]]})
        df3=pd.DataFrame([data2])
        df3['ETF_CD']=i
        #df_f=pd.concat([df_f,df2])
        df_lp=pd.concat([df_lp,df3])
        tm.sleep(0.5)
        
    df_lp=pd.merge(left = df_lp , right = df_list, how = "inner", on = ["ETF_CD"])
    df_lp['BO_sum']=df_lp['bid']+df_lp['offer']
    df_lp['lp_sum_offer']=df_lp['lp_offerrem1']+df_lp['lp_offerrem2']+df_lp['lp_offerrem3']+df_lp['lp_offerrem4']+df_lp['lp_offerrem5']+df_lp['lp_offerrem6']+df_lp['lp_offerrem7']+df_lp['lp_offerrem8']+df_lp['lp_offerrem9']+df_lp['lp_offerrem10']
    df_lp['lp_sum_bid']=df_lp['lp_bidrem1']+df_lp['lp_bidrem2']+df_lp['lp_bidrem3']+df_lp['lp_bidrem4']+df_lp['lp_bidrem5']+df_lp['lp_bidrem6']+df_lp['lp_bidrem7']+df_lp['lp_bidrem8']+df_lp['lp_bidrem9']+df_lp['lp_bidrem10']
    df_lp['lp_sum']=df_lp['lp_sum_bid']+df_lp['lp_sum_offer']
    df_lp['SPREAD']=(df_lp['offerho1']-df_lp['bidho1'])*100/df_lp['price']
    df_lp['bid_chg']=df_lp['bid']/(df_lp['bid']-df_lp['prebidcha'])-1
    df_lp['off_chg']=df_lp['offer']/(df_lp['offer']-df_lp['preoffercha'])-1
    df_lp['bo_chg']=(df_lp['offer']+df_lp['bid'])/(df_lp['bid']-df_lp['prebidcha']+df_lp['offer']-df_lp['preoffercha'])-1
    

    return df_lp

# 테스트 https://teamroom.nate.com/api/webhook/1c36536c/KYX0Lc9BdNdAD7EnskoMOyi4
# ace용 https://teamroom.nate.com/api/webhook/c6d28a1b/4LQgZ9N1rQkXQnbsHeWGw6UB
def message(i,fund_nm,manager):
    nate_webhook='https://teamroom.nate.com/api/webhook/c6d28a1b/4LQgZ9N1rQkXQnbsHeWGw6UB'
    
    if i==0:
        text={"text": fund_nm+" 스프레드 초과 "+manager+"매니저 일하세요 ^.^"}
    elif i==1:
        text={"text": fund_nm+" 호가괴리발생 "+manager+"매니저 일하세요 ^.^"}
    elif i==2:
        text={"text": fund_nm+" 호가수량 급변 "+manager+"매니저 얼른 일하세요 ^.^"}
    elif i==3:
        text={"text": fund_nm+" LP호가 빠짐 "+manager+"매니저 얼른 일하세요 ^.^"}

    requests.post(nate_webhook,json=text,verify=False)
    
def message_base(text):
    nate_webhook='https://teamroom.nate.com/api/webhook/c6d28a1b/4LQgZ9N1rQkXQnbsHeWGw6UB'

    requests.post(nate_webhook,json=text)
    
    
def timeline(country):
    start_time2= time(00, 00)
    end_time2= time(00, 00)
    if country=='VIET':
        start_time = time(11, 15)  # 오전 11시 15분
        end_time = time(13, 30)    # 오후 1시 30분
        
        start_time2 = time(15, 00)  # 오전 3시 00분
        end_time2 = time(15, 30)    # 오후 3시 30분
        
    if country=='HK':
        start_time = time(10, 30)  # 오전 10시 30분
        end_time = time(15, 30)    # 오후 3시 30분
    if country=='KR':
        start_time = time(9, 0)  # 오전 9시 00분
        end_time = time(15, 30)    # 오후 3시 30분
        
    if country=='IN':
        start_time = time(11, 15)  # 오전 11시 00분
        end_time = time(14, 00)    # 오후 2시 00분
        
    if country=='CN':
        start_time = time(11, 0)  # 오전 11시 00분
        end_time = time(14, 0)    # 오후 2시 00분    
    
    return start_time,end_time,start_time2,end_time2

##스프레드 알림

# 1	시장대표,국내채권 10bp
# 2	합성파생형(선물헷지) 30bp
# 3	국내테마형 50bp
# 4	액티브 70bp
# 5	미국테마형 100bp
# 6	선진국(베트남,인도네시아) 150bp
# 7	그외 200bp

def SPR(df,i):
    i=int(i)
    
    if i==1:
        n=10
    elif i==2:
        n=30
    elif i==3:
        n=50
    elif i==4:
        n=70
    elif i==5:
        n=100
    elif i==6:
        n=150
    elif i==7:
        n=200
    
    return df['SPREAD']>=n

def SPR_DH(df,n):
    
    return df[df['SPREAD']>=n]

if __name__ == "__main__":
    
    while True:
        a=main()
        now= datetime.now().time()
        a2=a
        kor=a[a['ETF_MKT_BIG']=='국내']
        kor=kor.reset_index()
        glo=a[a['ETF_MKT_BIG']!='국내']
        
        glo2=glo
        viet=glo[(glo['ETF_CD']=='245710')|(glo['ETF_CD']=='371130')]
        viet=viet.reset_index()
        HK=glo[glo['ETF_CD']=='371870']
        HK=HK.reset_index()
        IN=glo[glo['ETF_CD']=='256440']
        IN=IN.reset_index()
        cn=glo[(glo['ETF_CD']=='168580')|(glo['ETF_CD']=='219900')]
        cn=cn.reset_index()
        phil=glo[glo['ETF_CD']=='261920']
        a=a[(a['ETF_CD']!='245710')&(a['ETF_CD']!='371130')&(a['ETF_CD']!='261920')&(a['ETF_CD']!='371870')&(a['ETF_CD']!='256440')&(a['ETF_CD']!='168580')&(a['ETF_CD']!='219900')]
        glo=glo[(glo['ETF_CD']!='245710')&(glo['ETF_CD']!='371130')&(glo['ETF_CD']!='261920')&(glo['ETF_CD']!='371870')&(glo['ETF_CD']!='256440')&(glo['ETF_CD']!='168580')&(glo['ETF_CD']!='219900')]
        glo=glo.reset_index()
       
        ##개장시간
        
        if time(8,58)<=now<=time(9,0):
            message_base({"text":'∩   ∩\n(  •‿• )つ  —장열어         —장열어\n(つ　 <                —장열어\n｜　 _つ      +  —장열어         —장열어\n`し´\n'})
        
        if time(9,5)<=now<=time(15,20):
            
            if timeline('KR')[0]<=now<=timeline('KR')[1]:
                ov_sp=pd.DataFrame()
                
                for i in range(len(kor)):
                    if SPR(kor[i:i+1],kor[i:i+1]['SP_TYP'][i])[i]:
                        ov_sp=pd.concat([ov_sp,kor[i:i+1]])
                
                if ov_sp.empty== False:
                    n=0
                    message_base({"text":'┌───────────┐\n│  스프레드 초과(국내)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})
                    for i in range(len(ov_sp)):
                        message(n,ov_sp[i:i+1]['ETF_NM'][i],ov_sp[i:i+1]['MANAGER'][i])
                               
                             
                ##LP호가 알림
                if a[a['lp_sum']==0].empty == False:
                    ov_sp=pd.DataFrame()
                    
                    for i in range(len(glo)):
                        if SPR(glo[i:i+1],glo[i:i+1]['SP_TYP'][i])[i]:
                            ov_sp=pd.concat([ov_sp,glo[i:i+1]])
                    
                    if ov_sp.empty== False:
                        n=0
                        message_base({"text":'┌───────────┐\n│  스프레드 초과(해외)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})
                        for i in range(len(ov_sp)):
                            message(n,ov_sp[i:i+1]['ETF_NM'][i],ov_sp[i:i+1]['MANAGER'][i])
                            
                            
                   
                    message_base({"text":'┌─────────┐\n│  LP호가 빠짐내역   │\n└∩───────∩┘\n        ヽ(`・ω・´)ノ'})
                           
                    #message_base({"text":'#################LP호가 빠짐내역###############'})
                    n=3
                    ba_sum=a[a['lp_sum']==0].reset_index()
                    for i in range(len(a[a['lp_sum']==0])):
                        message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])
                        
                        
            ##베트남 알림
            
            # if ((timeline('VIET')[0]<=now<=timeline('VIET')[1])|(timeline('VIET')[2]<=now<=timeline('VIET')[3])):
            #     if viet[viet['lp_sum']==0].empty == False:
            #         ov_sp=pd.DataFrame()
                    
            #         for i in range(len(viet)):
            #             if SPR(viet[i:i+1],viet[i:i+1]['SP_TYP'][i])[i]:
            #                 ov_sp=pd.concat([ov_sp,viet[i:i+1]])
                    
            #         if ov_sp.empty== False:
            #             n=0
            #             message_base({"text":'┌───────────┐\n│  스프레드 초과(해외)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})
            #             for i in range(len(ov_sp)):
            #                 message(n,ov_sp[i:i+1]['ETF_NM'][i],ov_sp[i:i+1]['MANAGER'][i])
                            
            #         #         if viet[viet['lp_sum']==0].empty == False:
            #         # if SPR(viet,1.5).empty == False:
            #         #     message_base({"text":'┌───────────┐\n│  스프레드 초과(해외)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})              
            #         #     n=0
            #         #     ba_sum=SPR(viet,1).reset_index()
            #         #     for i in range(len(SPR(viet,1))):
            #         #         message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])
                            
            #         message_base({"text":'┌─────────┐\n│  LP호가 빠짐내역   │\n└∩───────∩┘\n        ヽ(`・ω・´)ノ'})
            #         n=3
            #         ba_sum=viet[viet['lp_sum']==0].reset_index()
            #         for i in range(len(viet[viet['lp_sum']==0])):
            #             message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])
    
            ##홍콩 알림
            if timeline('HK')[0]<=now<=timeline('HK')[1]:
                ov_sp=pd.DataFrame()
                
                if HK[HK['lp_sum']==0].empty == False:
                    
                    for i in range(len(HK)):
                        if SPR(HK[i:i+1],HK[i:i+1]['SP_TYP'][i])[i]:
                            ov_sp=pd.concat([ov_sp,HK[i:i+1]])
                    
                    if ov_sp.empty== False:
                        n=0
                        message_base({"text":'┌───────────┐\n│  스프레드 초과(해외)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})
                        for i in range(len(ov_sp)):
                            message(n,ov_sp[i:i+1]['ETF_NM'][i],ov_sp[i:i+1]['MANAGER'][i])
                            

                            
                    message_base({"text":'┌─────────┐\n│   LP호가 빠짐내역    │\n└∩────────∩┘\n        ヽ(`・ω・´)ノ'})
                    n=3
                    ba_sum=HK[HK['lp_sum']==0].reset_index()
                    for i in range(len(HK[HK['lp_sum']==0])):
                        
                        message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])
                        
            
            ##중국 알림
            if timeline('CN')[0]<=now<=timeline('CN')[1]:
                ov_sp=pd.DataFrame()
                
                if cn[cn['lp_sum']==0].empty == False:
                    
                    for i in range(len(cn)):
                        if SPR(cn[i:i+1],cn[i:i+1]['SP_TYP'][i])[i]:
                            ov_sp=pd.concat([ov_sp,cn[i:i+1]])
                    
                    if ov_sp.empty== False:
                        n=0
                        message_base({"text":'┌───────────┐\n│  스프레드 초과(해외)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})
                        for i in range(len(ov_sp)):
                            message(n,ov_sp[i:i+1]['ETF_NM'][i],ov_sp[i:i+1]['MANAGER'][i])
                            

                            
                    message_base({"text":'┌─────────┐\n│   LP호가 빠짐내역    │\n└∩────────∩┘\n        ヽ(`・ω・´)ノ'})
                    n=3
                    ba_sum=cn[cn['lp_sum']==0].reset_index()
                    for i in range(len(cn[cn['lp_sum']==0])):
                        
                        message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])
 
            ##인도네시아 알림
            if timeline('IN')[0]<=now<=timeline('IN')[1]:
                ov_sp=pd.DataFrame()
                
                if IN[IN['lp_sum']==0].empty == False:
                    
                    for i in range(len(IN)):
                        if SPR(IN[i:i+1],IN[i:i+1]['SP_TYP'][i])[i]:
                            ov_sp=pd.concat([ov_sp,IN[i:i+1]])
                    
                    if ov_sp.empty== False:
                        n=0
                        message_base({"text":'┌───────────┐\n│  스프레드 초과(해외)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})
                        for i in range(len(ov_sp)):
                            message(n,ov_sp[i:i+1]['ETF_NM'][i],ov_sp[i:i+1]['MANAGER'][i])
                            

                            
                    message_base({"text":'┌─────────┐\n│   LP호가 빠짐내역    │\n└∩────────∩┘\n        ヽ(`・ω・´)ノ'})
                    n=3
                    ba_sum=IN[IN['lp_sum']==0].reset_index()
                    for i in range(len(IN[IN['lp_sum']==0])):
                        
                        message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])    
            # ##LP호가 알림
            # if a2[a2['bo_chg']<=-0.5].empty == False:
            #     message_base({"text":'┌──────────┐\n│     호가 급변내역    │\n└∩────────∩┘\n        ヽ(`・ω・´)ノ'})
            #     n=2
            #     ba_sum=a2[a2['bo_chg']<=-0.5].reset_index()
            #     for i in range(len(a2[a2['bo_chg']<=-0.5])):
            #         message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])
        
        ##동시호가
        if time(15,20)<=now<=time(15,30):  # 수능 장 시간 변경
            ##스프레드 알림
            if SPR_DH(kor,0.7).empty == False:
                n=0
                message_base({"text":'┌───────────┐\n│  스프레드 초과(국내)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})
                ba_sum=SPR_DH(kor,0.7).reset_index()
                for i in range(len(SPR_DH(kor,0.7))):
                    message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])
                    
            if SPR_DH(glo2,1.5).empty == False:
                message_base({"text":'┌───────────┐\n│  스프레드 초과(해외)    │\n└∩─────────∩┘\n        ヽ(`・ω・´)ノ'})
                n=0
                ba_sum=SPR_DH(glo2,1.5).reset_index()
                for i in range(len(SPR_DH(glo2,1.5))):
                    message(n,ba_sum[i:i+1]['ETF_NM'][i],ba_sum[i:i+1]['MANAGER'][i])
                
            tm.sleep(180) # 3분에 한번씩
            
        if now>=time(15,30,30):  # 수능 장 시간 변경
            message_base({"text":'　　　　　／＞　　フ\n　　　　　| 　●　 ● l\n　 　　　／` ミ＿xノ\n　　 　 /　　　 　 |\n　　　 /　 ヽ　　 ﾉ\n　 　 │　　|　|　|\n　／￣|　　 |　|　|\n　| (￣ヽ＿_ヽ_)__)\n　＼二つ'})
            message_base({"text":'☆.。.:*・°☆.。.:*・°☆.。.:*・°☆.。.:*・°☆\n                  장 종 료               \n☆.。.:*・°☆.。.:*・°☆.。.:*・°☆.。.:*・°☆ '})
            
            break;
  
            