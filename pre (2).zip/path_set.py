# -*- coding: utf-8 -*-
"""
Created on Fri Oct 18 19:13:28 2024

@author: USER
"""

## 데이터 파일 경로
def path(): 
    root='C://Users//USER//Desktop//경진_final//data//'
    if root=='':
        print('데이터 파일 경로를 설정하세요')
    else:
        return root

## host, port 정보
def path_host():
    
    ip='192.168.193.65'
    port=8051
    
    if ip=='':
        print('호스트 주소를 설정하세요')
    else:       
        return ip, port