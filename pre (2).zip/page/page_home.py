# Page Layout


from dash import dcc, html, Input, Output, State, ALL
import dash_bootstrap_components as dbc
import os
import pickle
from pre.format_data import format_data
import path_set as ps

root=ps.path()

# 변수 정의 

file_path_kr = root+'news_kr.pkl' 
file_path_gl = root+'news_gl.pkl'


with open(file_path_kr, "rb") as file:
    news = pickle.load(file) #전일 국내시황

with open(file_path_gl, "rb") as file:
    news2 = pickle.load(file) #전일 해외시황


# 로그인 페이지 레이아웃
layout = dbc.Container([
            dbc.Card([
                dbc.Row([
                    dbc.Col([
                        html.H1("ETF InsighTor: Your Expert Market Navigator", className="text-left mt-5", style={"font-weight": "bold", "color": "#6390bf"}),
                        html.P("Your streamlined solution for effortless ETF performance analysis and proactive risk monitoring.", 
                               className="text-left", 
                               style={"font-size": "18px","font-weight": "bold", "margin-top": "10px","color":"#4C2C0E"}),
                    ], width=12)
                ]),
    
             html.Div([
                html.Iframe(
                    src="https://www.aceetf.co.kr/about/aboutAceEtf",  # 외부 웹사이트 URL
                    style={
                        "height": "400px", 
                        "width": "60%", 
                        "border": "none", 
                        "overflow": "hidden"  # 스크롤을 방지
                    }
                )
            ], style={"overflow": "hidden"}),
             
            dbc.Row([
                dbc.Col([
            #html.H5("전일 시황", className="text-center mb-4", style={"font-weight": "bold"}),
                    dbc.Card(
                            dbc.CardBody([
                                html.Div([
                                    html.Div([
                                       # html.H6(f"총 성과: {total_performance_combined:.2f}% 종목 성과: {constituent_performance:.2f}% 기타 성과 (환율, 비용 등): {dollar_performance:.2f}%", className="card-title", style={"font-weight": "bold"}),
                                        html.P(format_data(news), className="card-text", style={"whiteSpace": "pre-wrap","font-weight": "bold","font-size": "14px", "color": "#6c757d"}),
                                    ], className="ml-3"),
                                ], className="d-flex align-items-center"),  # 아이콘과 텍스트 정렬
                            ]),
                            className="mb-3 shadow-sm",
                            style={"border-left": "5px solid #6390bf", "border-radius": "10px"}  # 카드 좌측에 강조선 추가
                        ),
                    dbc.Card(
                            dbc.CardBody([
                                html.Div([
                                    html.Div([
                                       # html.H6(f"총 성과: {total_performance_combined:.2f}% 종목 성과: {constituent_performance:.2f}% 기타 성과 (환율, 비용 등): {dollar_performance:.2f}%", className="card-title", style={"font-weight": "bold"}),
                                        html.P(format_data(news2), className="card-text", style={"whiteSpace": "pre-wrap","font-weight": "bold","font-size": "14px", "color": "#6c757d"}),
                                    ], className="ml-3"),
                                ], className="d-flex align-items-center"),  # 아이콘과 텍스트 정렬
                            ]),
                            className="mb-3 shadow-sm",
                            style={"border-left": "5px solid #6390bf", "border-radius": "10px"}  # 카드 좌측에 강조선 추가
                    ),
                ], width=12)  # 뉴스 데이터는 오른쪽 4열을 차지
            ]),
            dbc.Row([
                dbc.Col([
                    dbc.Button("Explore ACE ETF", className="mt-4 explore-button", size="lg", href="/treemap"),
                ], width=12, style={"color": "#6390bf"}, className="d-flex justify-content-center")
            ])
        ], className="shadow p-4"),
    ], fluid=True)
