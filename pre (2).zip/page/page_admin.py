
# Page Layout

from dash import dcc, html, Input, Output, State
import dash_bootstrap_components as dbc
import pandas as pd
import requests

from pre.get_data import get_etf_manager, main, get_etf_mkt, get_etf_spread
from pre.format_data import save_dataframe_to_pickle
from pre.process_func import hoga_alarm, news_crawl, stop_process, chg_rate_api, vi_api
import path_set as ps

root=ps.path()


# 필요한 변수 설정
df_lp1 = get_etf_manager()
df_lp2 = get_etf_spread()
df_kr, df_gl, df_krstk= main()
df_mkt = get_etf_mkt()

df_all=pd.concat([df_kr,df_gl])


requests.packages.urllib3.disable_warnings()  # Ignore SSL warnings

process1 = None         # LP호가알림(신고스프레드) 
process2 = None         # LP호가알림(이모티)
process_vi = None
process_chg_rate = None
process_crawl = None


# 레이아웃 생성
layout = dbc.Container([
        dbc.Card([
                dbc.Row([
                    dbc.Col([
                        html.H2("Function 실행", className="text-center", style={"font-weight": "bold"}),
                        html.P("ETF 모니터링 기능 실행 및 관리자 페이지입니다.", className="text-left",style={"font-weight": "bold","color":'#4C2C0E'}),
                        
                        html.Button("종목 뉴스 크롤링하기", id="news-crawl-button", className="btn btn-primary", style={"marginTop": "20px"}),
                        html.Button("실시간 VI/등락률 실행하기", id="api-button", className="btn btn-primary", style={"marginTop": "20px"}),
                        
                        # 체크박스 개수 표시
                        html.Div(id='etf-count', style={"fontSize": "13px", "color": "black", "marginTop": "20px", "textAlign": "right"}),
            
                        # 체크박스 열 구성
                        dbc.Row([
                            # 국내 ETF 체크박스
                            dbc.Col([
                                html.H4("국내 ETF", className="mt-4"),
                                dcc.Checklist(
                                    id="domestic-etf-checklist",
                                    options=[{'label': etf, 'value': etf} for etf in df_lp1[df_lp1['OS_GB'] == '국내']['ETF_NM']],
                                    value=list(df_lp1[df_lp1['OS_GB'] == '국내']['ETF_NM']),  # 기본적으로 모든 국내 ETF가 선택된 상태
                                    inline=True,
                                    labelStyle={"display": "block", "marginBottom": "5px","textAlign": "left"},  # 고정된 너비와 왼쪽 정렬
                                    style={"maxHeight": "350px", "overflowY": "scroll"}  # 최대 높이 및 스크롤 추가
                                ),
                            ], width=6),  # 국내 ETF 열
            
                            # 해외 ETF 체크박스
                            dbc.Col([
                                html.H4("해외 ETF", className="mt-4"),
                                dcc.Checklist(
                                    id="foreign-etf-checklist",
                                    options=[{'label': etf, 'value': etf} for etf in df_lp1[df_lp1['OS_GB'] == '해외']['ETF_NM']],
                                    value=list(df_lp1[df_lp1['OS_GB'] == '해외']['ETF_NM']),  # 기본적으로 모든 해외 ETF가 선택된 상태
                                    inline=True,
                                    labelStyle={"display": "block", "marginBottom": "5px","textAlign": "left"},  # 고정된 너비와 왼쪽 정렬
                                    style={"maxHeight": "350px", "overflowY": "scroll"}  # 최대 높이 및 스크롤 추가
                                ),
                            ], width=6),  # 해외 ETF 열
                            # 실행 버튼
                            dbc.Row([
                                html.Button("네이트온 호가 알람 실행하기", id="run-button", className="btn btn-primary", style={"marginTop": "40px", "width":"5px"}),
                            ], justify="end"),
                            
                        ]),  # 체크박스 열 구성
                    ], width=12),  # 전체 컬럼
                ]),
            ], className="shadow p-4"),
        ], fluid=True)


# 콜백 함수 추가 (해당 페이지에 쓰이는 콜백)
def register_callbacks(app):
    
    ## 네이트온 호가알람 관련 
    # ETF 체크박스 상태가 변경되면 총 ETF 개수 업데이트 (호가 알림)
    @app.callback(
        Output('etf-count', 'children'),
        [Input('domestic-etf-checklist', 'value'),
         Input('foreign-etf-checklist', 'value')]
    )
    def update_etf_count(selected_domestic_etfs, selected_foreign_etfs):
        # 선택된 ETF에 따라 개수 계산
        selected_etfs = selected_domestic_etfs + selected_foreign_etfs
        etf_count = len(selected_etfs)
        return f"*선택된 ETF 개수: {etf_count}"


    ##### 버튼 클릭 시 색 변경 및 함수 실행/중지 콜백 (호가 알림)
    @app.callback(
        [Output('run-button', 'style'),
         Output('run-button', 'children')],
        [Input('run-button', 'n_clicks')],
        [State('domestic-etf-checklist', 'value'),
         State('foreign-etf-checklist', 'value')]
    )
    def on_button_click(n_clicks, selected_domestic_etfs, selected_foreign_etfs):
        global process1
        global process2
        
        if n_clicks is None:
            # 초기 상태: 버튼 검은색, 함수 실행 안 함
            return {"backgroundColor": "#6390bf", "color": "white"}, "네이트온 호가알람 실행하기"
        
        # n_clicks가 홀수이면 함수 실행, 버튼 회색
        if n_clicks % 2 == 1:
            style = {"backgroundColor": "gray", "color": "white"}
            label = "중지하기"
            
            selected_etfs = selected_domestic_etfs + selected_foreign_etfs
            
            filtered_df = df_lp1[df_lp1['ETF_NM'].isin(selected_etfs)]
            save_dataframe_to_pickle(filtered_df, root+"data.pkl")
            
            filtered_df2 = df_lp2[df_lp2['ETF_NM'].isin(selected_etfs)]
            save_dataframe_to_pickle(filtered_df2, root+"data2.pkl")
            
            
            # 함수를 비동기로 실행
            process1, process2 = hoga_alarm(process1, process2)
            
            return style, label
        
        # n_clicks가 짝수이면 함수 중지, 버튼 검은색
        else:
            process1 = stop_process(process1)
            process2 = stop_process(process2)
            return {"backgroundColor": "#6390bf", "color": "white"}, "네이트온 호가알람 실행하기"
    
    
    # news-crawl-button
    @app.callback(
        [Output('news-crawl-button', 'style'),
         Output('news-crawl-button', 'children')],
        [Input('news-crawl-button', 'n_clicks')]
    )
    def news_crawl_button(n_clicks):
        global process_crawl
        
        if n_clicks is None:
            # 초기 상태: 버튼 검은색, 함수 실행 안 함
            return {"backgroundColor": "#6390bf", "color": "white", "marginLeft": "10px", "marginTop": "15px"}, "종목 뉴스 크롤링하기"
        
        # n_clicks가 홀수이면 함수 실행, 버튼 회색
        if n_clicks % 2 == 1:
            style = {"backgroundColor": "gray", "color": "white", "marginLeft": "10px", "marginTop": "15px"}
            label = "크롤링 중지하기"
            
            # 함수를 비동기로 실행
            process_crawl = news_crawl(process_crawl)
            
            return style, label
        
        # n_clicks가 짝수이면 함수 중지, 버튼 검은색
        else:
            process_crawl = stop_process(process_crawl)
            return {"backgroundColor": "#6390bf", "color": "white", "marginLeft": "10px", "marginTop": "15px"}, "종목 뉴스 크롤링하기"
    
    
    # run vi, chg_rate button
    @app.callback(
        [Output('api-button', 'style'),
         Output('api-button', 'children')],
        [Input('api-button', 'n_clicks')]
    )
    def api_button(n_clicks):
        global process_chg_rate
        global process_vi
        
        if n_clicks is None:
            # 초기 상태: 버튼 검은색, 함수 실행 안 함
            return {"backgroundColor": "#6390bf", "color": "white", "marginLeft": "10px", "marginTop": "15px"}, "실시간 VI/등락률 실행하기"
        
        # n_clicks가 홀수이면 함수 실행, 버튼 회색
        if n_clicks % 2 == 1:
            style = {"backgroundColor": "gray", "color": "white", "marginLeft": "10px", "marginTop": "15px"}
            label = "실시간 VI/등락률 중지하기"
            
            # 함수를 비동기로 실행
            process_chg_rate = chg_rate_api(process_chg_rate)
            process_vi = vi_api(process_vi)
            
            return style, label
        
        # n_clicks가 짝수이면 함수 중지, 버튼 검은색
        else:
            process_chg_rate = stop_process(process_chg_rate)       
            process_vi = stop_process(process_vi)     
            return {"backgroundColor": "#6390bf", "color": "white", "marginLeft": "10px", "marginTop": "15px"}, "실시간 VI/등락률 실행하기"
    
    