# -*- coding: utf-8 -*-
"""
Created on Fri Oct 20 20:40:32 2023

@author: user
"""

