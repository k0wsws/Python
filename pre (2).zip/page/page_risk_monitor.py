
# Page Layout

import dash
from dash import dcc, html, Input, Output, State, ALL
import dash_bootstrap_components as dbc
from twilio.rest import Client
from datetime import datetime, timedelta
from datetime import date
import requests
import pickle
import path_set as ps
from pre.holiday_calendar import generate_week_calendar
from pre.get_data import get_etf_manager, get_etf_lp_amt
import api_keys as key
root=ps.path()
# 필요한 변수 설정
today = datetime.now()
df_lp1 = get_etf_manager()
df_lp_amt = get_etf_lp_amt()

requests.packages.urllib3.disable_warnings()  # Ignore SSL warnings


# 레이아웃 생성
layout = dbc.Container([
        dbc.Card(dbc.Row([
            
            html.P("실시간 주의 종목을 선별하고, 실제 ETF의 호가와 LP 잔고를 모니터링하여 운용역/LP에 알림을 제공할 수 있습니다.\n현재는 3초에 한번씩 업데이트 되고 있습니다.", className="text-left",style={"whiteSpace": "pre-line","font-weight": "bold","color":'#4C2C0E'}),
            
            # 캘린더 추가
            html.H4("휴장 캘린더 (주간)", style={"marginTop": "20px","fontFamily": "Pretendard","color":'#6390bf'}),
            dbc.Row(generate_week_calendar(today),  # 주간 캘린더 생성 #10.11
                    style={"marginTop": "20px", 
                           "border": "1px solid #ddd", 
                           "padding": "5px",
                           "maxWidth": "1200px",  # 전체 캘린더 박스 크기 제한
                           "marginLeft": "0",
                           "boxShadow": "none"  }), # 테두리 효과 제거
            
            # 실시간 VI, 등락률 확인
            dbc.Container([
                dcc.Interval(
                    id='interval-component',
                    interval=3*1000,  # 3초
                    n_intervals=0
                ),
                
                html.H4("실시간 VI 발동 확인", style={"marginTop": "30px","fontFamily": "Pretendard","color":'#6390bf'}),
                dbc.Row([
                    html.Div(id='vi-trigger-info', children=[
                        # html.P("현재 VI 발동 상품 목록:", className="mb-2"),
                        # 카드들을 가로로 나열할 Div
                        dbc.Row(id='vi-trigger-list', style={"display": "flex", "flexWrap": "wrap"})  # Flexbox로 가로 나열
                    ])
                ], style={"marginBottom": "20px"}),
                
                html.H4("실시간 등락률 Top5", style={"marginTop": "30px","fontFamily": "Pretendard","color":'#6390bf'}),
                dbc.Row([
                    html.Div(id='chg-trigger-info', children=[
                        # html.P("현재 VI 발동 상품 목록:", className="mb-2"),
                        # 카드들을 가로로 나열할 Div
                        dbc.Row(id='chg-trigger-list', style={"display": "flex", "flexWrap": "wrap"})  # Flexbox로 가로 나열
                    ])
                ], style={"marginBottom": "20px"}),
            ]),
            

            # 드롭다운 추가 (ETF 선택)
            html.H4("LP잔고 모니터링 및 메세지 전송", className="mt-4", style={"marginTop": "30px","fontFamily": "Pretendard","color":'#6390bf'}),
            dbc.Col([    
                
                # LP 테이블 내보내기 
                html.Div([
                    html.H6("LP 메세지 전송", className="mt-4", style={"marginTop": "30px", "font-weight": "bold"}),
                    dcc.Dropdown(id='etf-dropdown', options=[{'label': etf, 'value': etf} for etf in df_lp1['ETF_NM']], value='ACE 200', placeholder="ETF를 선택하세요"),
                    html.Div(id='lp-info', style={"marginTop": "20px"}),
                ])
            ], width=7),  # 왼쪽 컬럼
            
            dbc.Col(id='input-fields', width=5)  # 오른쪽 컬럼
        ]), className="shadow p-4"),
    ], fluid=True)


# 콜백 함수 추가 (해당 페이지에 쓰이는 콜백)
def register_callbacks(app):
    
    ## 실시간 VI 및 등락
    # 등락률 리스트업 콜백 함수 정의
    @app.callback(
        Output('chg-trigger-list', 'children'),
        Input('interval-component', 'n_intervals'),
        Input('chg-trigger-list', 'id')  # 업데이트 트리거
    )
    def update_chg_trigger_list(n_intervals, _):
        # chg_data.pkl 파일에서 데이터 로드
        
        # print(os.getcwd())
        with open(root+'chg_data.pkl', 'rb') as f:
            df =  pickle.load(f)
            # print(df)
        if df.empty:
            return [html.P("현재 등락률을 확인할 수 없습니다.", className="text-danger")]  # 빈 리스트 반환
        
        df['shcode'] = 'A'+df['shcode']
        df_merged = df.merge(df_lp1[['STK_CD', 'ETF_NM']], left_on='shcode', right_on='STK_CD', how='left')
        
        # 각 행에 대해 카드 생성
        cards = []
        for index, row in df_merged.iterrows():
            if row['chg_rate'] > 0:
                color = "red"
                img = "🔺"
            elif row['chg_rate'] < 0:
                color = "blue"
                img = "🔻"
            else:
                color = "black"
                img = ""
            
            card = dbc.Col(
                dbc.Card(
                    dbc.CardBody([
                        html.H6(f"{row['ETF_NM']} ({row['shcode']})", className="card-title", style={"font-size": "16px"}),
                        html.P(f"현재가: {format(int(row['price']), ',d')}(원)", className="card-text", style={"font-size": "14px"}),
                        html.P([
                            "등락률: ",
                            html.Span(f"{img}{round(row['chg_rate'], 2)}(%)", style={"color": color})  # 등락률 값만 색상 변경
                        ], className="card-text", style={"font-size": "14px", "color": "black"})  # "등락률" 텍스트는 검은색 유지
                    ]),
                    style={
                        "margin": "10px",
                        "width": "250px",  # 고정 가로 길이
                        "height": "150px",  # 고정 세로 길이
                        "box-shadow": "0 4px 8px rgba(0,0,0,0.1)"  # 그림자 효과
                    }
                ),
                width='auto'
            )
            cards.append(card)

        return cards  # 카드 리스트 반환
    
    # VI 리스트업 콜백 함수 정의
    @app.callback(
        Output('vi-trigger-list', 'children'),
        # Input('interval-component', 'n_intervals')
        Input('vi-trigger-list', 'id')  # 업데이트 트리거
    )
    def update_vi_trigger_list(_):
        # vi_data.pkl 파일에서 데이터 로드
        # print(os.getcwd())
        with open(root+'vi_data.pkl', 'rb') as f:
            df =  pickle.load(f)
        
        if df.empty:
            return [html.P("현재 VI 발동 중인 상품이 없습니다.", className="text-danger")]  # 빈 리스트 반환
        
        df['shcode'] = 'A'+df['shcode']
        df_merged = df.merge(df_lp1[['STK_CD', 'ETF_NM']], left_on='shcode', right_on='STK_CD', how='left')
        # 각 행에 대해 카드 생성
        cards = []
        for index, row in df_merged.iterrows():
            if row['vi_gubun'] == "1":
                vi_gubun = "정적발동"
            elif row['vi_gubun'] == "2":
                vi_gubun = "동적발동"
            if row['vi_gubun'] == "3":
                vi_gubun = "정적&동적발동"
            
            card = dbc.Col(
                dbc.Card(
                    dbc.CardBody([
                        html.H6(f"{row['ETF_NM']} ({row['shcode']})", className="card-title", style={"font-size": "16px"}),
                        html.P(f"VI 구분: {vi_gubun}", className="card-text", style={"font-size": "14px"}),
                        html.P(f"VI발동가격: {format(int(row['vi_trgprice']), ',d')}(원)", className="card-text", style={"font-size": "14px"}),
                    ]), 
                    style={
                        "margin": "10px",
                        "width": "250px",  # 고정 가로 길이
                        "height": "150px",  # 고정 세로 길이
                        "box-shadow": "0 4px 8px rgba(0,0,0,0.1)"  # 그림자 효과
                    }
                ),
                width='auto'
            )
            cards.append(card)

        return cards  # 카드 리스트 반환
    
    ## LP 잔고 모니터링 및 메세지 전송
    # 선택된 ETF에 따라 LP 및 AP_AMT 정보를 표시하는 콜백
    @app.callback(
        Output('lp-info', 'children'),
        [Input('etf-dropdown', 'value')]
    )
    def display_lp_info(selected_etf):
        if selected_etf is None:
            selected_etf = 'ACE 200'
            # return "", html.Div()  # ETF가 선택되지 않으면 테이블과 입력 필드 모두 숨김

        # df_lp1에서 선택된 ETF에 해당하는 stk_cd 가져오기
        selected_stk_cd = df_lp1[df_lp1['ETF_NM'] == selected_etf]['STK_CD'].values[0]
        
        # SQL 쿼리로 가져온 데이터프레임에서 선택된 stk_cd에 맞는 row 찾기
        etf_data = df_lp_amt[df_lp_amt['STK_CD'] == selected_stk_cd]
        
        if not etf_data.empty:
            # 여러 행을 테이블로 표시
            table_header = [html.Tr([html.Th("LP"), html.Th("LP 잔고 (억 원)"), html.Th("전송하기")])]
            table_rows = [
                html.Tr([
                    html.Td(row['LP']),
                    html.Td(f"{row['AP_AMT']}"),
                    html.Td(html.Button("전송", id={'type': 'send-button', 'index': i}, 
                                n_clicks=0, 
                                style={
                                'backgroundColor': 'transparent',  # 배경색을 투명하게 설정
                                'border': '1px',  # 테두리 제거
                                'color': '#000000',  # 텍스트 색상
                                'cursor': 'pointer',  # 커서를 포인터로 설정
                                'padding': '5px',  # 여백 최소화
                                'borderRadius': '5px',
                                'boxShadow': '0px 4px 6px rgba(0, 0, 0, 0.1)',
                                'transition': 'background-color 0.3s ease',
                                # 'textDecoration': 'underline'  # 버튼을 링크처럼 보이게 하기 위해 밑줄 추가
                            }))  # 각 행에 전송 버튼 추가
                ]) for i, (_, row) in enumerate(etf_data.iterrows())
            ]

            return dbc.Table(table_header + table_rows, bordered=True, hover=True, striped=True)
        else:
            return "해당 ETF에 대한 데이터를 찾을 수 없습니다."
        
        
    # 전송 버튼 클릭 시 하단에 입력 필드 표시 및 전송 처리 콜백 
    @app.callback(
        Output('input-fields', 'children'),
        [Input({'type': 'send-button', 'index': ALL}, 'n_clicks')],
        [State({'type': 'send-button', 'index': ALL}, 'id'),
         State('etf-dropdown', 'value')]
    )
    def display_input_fields(n_clicks, button_ids, selected_etf):
        # 어떤 버튼이 클릭되었는지 확인
        ctx = dash.callback_context
        if not ctx.triggered or all(n == 0 for n in n_clicks):
            return [html.Div()]  # 기본적으로 아무것도 반환하지 않음
        
        # ETF가 선택되지 않았을 때 입력 필드를 숨김
        if selected_etf is None:
            return [html.Div()]  # 빈 입력 필드 반환
        
        # 클릭된 버튼의 ID 확인
        clicked_button_id = ctx.triggered[0]['prop_id'].split('.')[0]
        clicked_button_id = eval(clicked_button_id)  # 문자열로 전달된 ID를 딕셔너리로 변환

        if clicked_button_id:
            # 클릭된 버튼의 인덱스를 사용하여 LP 및 AP_AMT 정보를 가져오기
            row_index = clicked_button_id['index']
            
            # df_lp1에서 선택된 ETF에 해당하는 stk_cd 가져오기
            selected_stk_cd = df_lp1[df_lp1['ETF_NM'] == selected_etf]['STK_CD'].values[0]
            
            # SQL 쿼리로 가져온 데이터프레임에서 선택된 stk_cd에 맞는 row 찾기
            etf_data = df_lp_amt[df_lp_amt['STK_CD'] == selected_stk_cd]
            
            if not etf_data.empty and row_index < len(etf_data):
                lp = etf_data.iloc[row_index]['LP']
                ap_amt = etf_data.iloc[row_index]['AP_AMT']
                # print(lp)
                
                # 전화번호와 메시지 입력 필드, 선택된 LP 정보와 함께 표시
                return [
                    html.Div([
                        # 전화번호와 메세지 입력란을 감싸는 컨테이너
                        html.Div([
                            html.P(f"{lp} LP에게 메세지 전송"),
                            # 전화번호 입력
                            dcc.Store(id='select-lp', data=lp),

                            # 메세지 입력
                            dcc.Textarea(id="message-content", placeholder="여기에 메세지를 입력하세요...",
                                         style={
                                             "width": "100%", "height": "150px", "padding": "10px", 
                                             "fontSize": "16px", "border": "1px solid #ccc",
                                             "borderBottomLeftRadius": "5px", "borderBottomRightRadius": "5px",
                                             "resize": "none"
                                         }),

                            # 메세지 전송 버튼
                            html.Div([
                                html.Button("메세지 전송", id="send-message", n_clicks=0,
                                            style={
                                                "backgroundColor": "#4CAF50", "color": "white", 
                                                "border": "none", "padding": "10px 20px", 
                                                "fontSize": "16px", "cursor": "pointer",
                                                "borderBottomLeftRadius": "5px", "borderBottomRightRadius": "5px",
                                                "borderRadius": "5px"
                                            })
                            ], style={"textAlign": "right", "marginTop": "10px"}),
                            
                            html.Div(id='send-result', style={"marginTop": "20px"})
                        ], style={"width": "100%", "margin": "10px auto", "maxWidth": "400px", "boxShadow": "0 4px 8px rgba(0, 0, 0, 0.1)", "padding": "20px", "borderRadius": "5px", "backgroundColor": "white"})

                    ])
                ]
        
        return [html.Div()]  # 기본적으로 아무것도 반환하지 않음
    
    # 메시지 전송 처리 콜백
    @app.callback(
        [Output('send-result', 'children'),
         Output('send-message', 'children'),
         Output('send-message', 'style')],
        [Input('send-message', 'n_clicks')],
        [State('message-content', 'value'),
         State('select-lp', 'data')]
    )
    def send_message(n_clicks, message_content, lp):
        if n_clicks > 0:
            
            lp_phone_dict = {
                '한국투자증권': '01066057416',
                'NH투자증권': '01066057416',
                '키움증권': '01066057416',
                '미래에셋증권': '01089652562',
                '삼성증권': '01089652562',
                'KB증권': '01045145787',
                '메리츠증권': '01045145787',
                '신한투자증권': '01045145787'
            }
            
            phone_number = lp_phone_dict.get(lp)
            
            if phone_number and message_content:
                # 메시지 전송 로직 추가 - Twilio API
                sid = key.twilio_api_key()[0]
                token =  key.twilio_api_key()[1]
                
                client = Client(sid, token, http_client=requests.Session())
                client.http_client.verify = False  # Disable SSL verification
                
                # Create a Bot instance with the SSL context
                message = client.messages.create(
                    to='+82'+ phone_number, 
                    from_="+19099391164",
                    body=f'{message_content}'
                )
                
                return ( f"{lp} LP에게 메시지 전송 완료!",  # 전송 결과 메시지
                    "전송 완료",  # 버튼 텍스트 변경
                    {"backgroundColor": "gray", "color": "white", "border": "none", "padding": "10px 20px", "fontSize": "16px", 
                     "cursor": "pointer", "borderBottomLeftRadius": "5px", "borderBottomRightRadius": "5px", "borderRadius": "5px"}  # 버튼 색상 변경
                )
                
            else:
                return "메세지를 입력하세요.", "메세지 전송", {"backgroundColor": "#4CAF50", "color": "white", "border": "none", "padding": "10px 20px",  "fontSize": "16px",
                                                             "cursor": "pointer", "borderBottomLeftRadius": "5px", "borderBottomRightRadius": "5px","borderRadius": "5px"}
        
        return "", "메세지 전송", {"backgroundColor": "#4CAF50", "color": "white", "border": "none", "padding": "10px 20px",  "fontSize": "16px",
                                                     "cursor": "pointer", "borderBottomLeftRadius": "5px", "borderBottomRightRadius": "5px","borderRadius": "5px"}
