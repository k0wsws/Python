
# Page Layout

import dash
from dash import dcc, html, Input, Output, State, ALL
import dash_bootstrap_components as dbc
from flask import Flask, session
import plotly.graph_objs as go
import pandas as pd
from plotly.subplots import make_subplots
import urllib.parse  # URL 인코딩/디코딩에 사용
from datetime import datetime, timedelta
import pickle
import re
import utils_.live_news as ln
from pre.get_data import main, get_etf_mkt, top5, bottom5, us_stock, etf_sector, volume_etf,read_update_time,save_update_time
from pre.layout_func import generate_table
from pre.favorites import load_favorites, save_favorites
from pre.fig_tree import fig_tree
import pre.DB_ETF as DB
import path_set as ps

root=ps.path()

with open(root+"news_gl_now.pkl", "rb") as file:
    summary3 = pickle.load(file)

## 데이터불러오기
df_kr, df_gl, df_krstk= main()
df_all=pd.concat([df_kr,df_gl])
df_mkt = get_etf_mkt()
list_us_stk = us_stock()
etf_sector = etf_sector()
volume_etf = volume_etf()

top5 = top5()
bot5 = bottom5()

today = datetime.now()
conn =DB.conn()

## 필요한 변수
# Finviz 스타일의 색상 스케일 (빨간색에서 초록색까지)
finviz_colorscale = [
    [0.0, '#ec413f'],  # 매우 낮은 값 (음수)
    [0.5, '#4f4554'],  # 중간 값 (0%)
    [1.0, '#46ad57']   # 매우 높은 값 (양수)
]

# 빨강-파랑
finviz_colorscale = [
    [0.0, '#ec413f'],  # 매우 낮은 값 (음수)
    [0.5, '#4f4554'],  # 중간 값 (0%)
    [1.0, 'blue']   # 매우 높은 값 (양수)
]


## 트리맵 페이지 레이아웃
layout = dbc.Container([
    dbc.Card([
        # Tabs layout
        html.P(
            "전체 ACE ETF의 현재 시황을 확인하고 전체 시장 동향을 한눈에 파악할 수 있습니다.\n"
            "관련 뉴스는 실시간으로 수집하여 AI가 요약한 결과입니다.",
            className="text-left",
            style={"whiteSpace": "pre-line", "font-weight": "bold", "color": '#4C2C0E'}
        ),
        
        dcc.Tabs(id="tabs", value='tab-1', children=[
            dcc.Tab(label='전체시황', value='tab-1'),
            dcc.Tab(label='관심종목', value='tab-2'),
        ], style={
            'z-index': '1',
            'top': '0px',
            'left': '10px',
            'width': '300px',
            'height': '60px',
            'font-size': '20px',
        }),

        # Content that will change based on the selected tab
        html.Div(id='tabs-content')
    ], className="shadow p-4")
], style={"fontFamily": "Pretendard"}, fluid=True)

                    
                    
def register_callbacks(app):                
## 콜백 함수 추가 (해당 페이지에 쓰이는 콜백)

    # 관심 ETF 콜백 함수 
    @app.callback(
        Output("etf-checklist1", "value"),
        Output("etf-checklist1", "options"),
        Output("etf-checklist2", "value"),
        Output("etf-checklist2", "options"),
        Output("etf-checklist3", "value"),
        Output("etf-checklist3", "options"),
        Input("save-button", "n_clicks"),
        Input("select-all-button", "n_clicks"),
        Input("deselect-all-button", "n_clicks"),
        State("etf-checklist1", "value"),
        State("etf-checklist2", "value"),
        State("etf-checklist3", "value"),
        prevent_initial_call=False
    )
    def manage_watchlist(save_clicks, select_all_clicks, deselect_all_clicks,
                          checklist1_values, checklist2_values, checklist3_values):
        
        username = session.get('username')
        
        # 콜백이 발생한 원인 확인
        ctx = dash.callback_context
        
        if not ctx.triggered:
            button_id = None
        else:
            button_id = ctx.triggered[0]['prop_id'].split('.')[0]

        # Load the options for each checklist
        options1 = df_all[df_all['ETF_NM'].isin(df_mkt[df_mkt['ETF_AST_MID'] == '시장대표']['ETF_NM'])]['ETF_NM'].tolist()
        options2 = df_all[df_all['ETF_NM'].isin(df_mkt[(df_mkt['ETF_AST_MID'] == '전략') | (df_mkt['ETF_AST_MID'] == '리츠')]['ETF_NM'])]['ETF_NM'].tolist()
        options3 = df_all[df_all['ETF_NM'].isin(df_mkt[df_mkt['ETF_AST_MID'] == '업종섹터']['ETF_NM'])]['ETF_NM'].tolist()
        

        if button_id == 'save-button':
            # Combine the checklist values into a single list without duplicates
            combined_favorites = list(set((checklist1_values or []) + (checklist2_values or []) + (checklist3_values or [])))

            # Construct the data dictionary
            data = {
                'checklist1': checklist1_values or [],
                'checklist2': checklist2_values or [],
                'checklist3': checklist3_values or [],
                'favorites': combined_favorites
            }
            # print(f"Data to be saved: {data}")  # Debug print
            save_favorites(username, data)

        elif button_id == 'select-all-button':
            # Select all options in each checklist
            checklist1_values = options1
            checklist2_values = options2
            checklist3_values = options3
            # return options1, options2, options3

        elif button_id == 'deselect-all-button':
            # Deselect all options in each checklist
            checklist1_values = []
            checklist2_values = []
            checklist3_values = []

        else:
            # On page load, load the favorites
            data = load_favorites(username)
            checklist1_values = data.get('checklist1', [])
            checklist2_values = data.get('checklist2', [])
            checklist3_values = data.get('checklist3', [])
            
        def reorder_options(all_options, selected_values):
            options = [{'label': etf, 'value': etf} for etf in all_options]
            selected_options = [option for option in options if option['value'] in selected_values]
            unselected_options = [option for option in options if option['value'] not in selected_values]
            return selected_options + unselected_options

        reoptions1 = reorder_options(options1, checklist1_values)
        reoptions2 = reorder_options(options2, checklist2_values)
        reoptions3 = reorder_options(options3, checklist3_values)
            
        return checklist1_values, reoptions1, checklist2_values, reoptions2, checklist3_values, reoptions3
    
    
    @app.callback(
        Output("stock-chart", "figure"),
        Output("volume", "children"),
        Output("update-data-button", "n_clicks"),
        Input("save-button", "n_clicks"),
        #Input('tabs', 'value'),  # 탭 선택 이벤트를 Input으로 사용
        Input("update-data-button", "n_clicks"),     # 업데이트 버튼
    )
    def treemap_fav(save,n):
        username = session.get('username')
        global df_kr
        global df_gl
        global df_krstk
        global df_all
    
        if not username:
            return "로그인이 필요합니다.", [], go.Figure()
        

        # JSON 파일에서 사용자의 관심종목 불러오기
        data = load_favorites(username)
        favorites = data.get('favorites', [])

        # 콜백이 발생한 원인 확인
        ctx = dash.callback_context
        
        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]

     
        if favorites:
            if trigger_id == 'update-data-button':
                df_kr, df_gl, df_krstk= main()
                df_all=pd.concat([df_kr,df_gl])
                ln.update()
                ln.update2()
                save_update_time()

            
            df_my = df_all[df_all['ETF_NM'].isin(favorites)]
        else:
            
            if trigger_id == 'update-data-button':
                df_kr, df_gl, df_krstk= main()
                df_all=pd.concat([df_kr,df_gl])
                ln.update()
                ln.update2()
                save_update_time()
                
            df_my = pd.DataFrame(columns=['ETF_NM', 'AUM', 'diff'])
         
        # 트리맵 차트 생성
        if not df_my.empty:
            # diff 컬럼의 최소값과 최대값을 계산
            diff_min = -3
            
            diff_max = 3
            tickvals = [diff_min, 0, diff_max]
            ticktext = [f'{diff_min:.1f}%', '0%', f'{diff_max:.1f}%']
            
            fig2 = make_subplots(rows=1, cols=1, 
                                specs=[[{'type': 'domain'}]])
            fig2.add_trace(
                go.Treemap(
                    labels=df_my['ETF_NM'],
                    parents=["" for _ in df_my['ETF_NM']],  # 최상위 노드 (부모가 없는 노드)
                    values=df_my['AUM'],
                    marker=dict(
                    colors=df_my['diff'],
                    cmin=diff_min,  # 색상 범위 최소값을 diff 최소값으로 설정
                cmax=diff_max,  # 색상 범위 최대값을 diff 최대값으로 설정
                    colorscale=finviz_colorscale,  # 빨강-파랑 색상 스케일
            ),
                    text=df_my['diff'],  # 텍스트로 diff 데이터를 사용
                    texttemplate="<b>%{label}</b><br> %{text:.2f}%",  # 텍스트 형식 설정: label과 diff 표시
                    textposition="middle center",  # 텍스트를 중앙에 위치
                ),
                row=1, col=1
            )
            
            # 레이아웃 업데이트
            
            fig2.update_layout(title="나의 관심 ETF",
                height=555,  # 전체 높이
                width=790,  # 전체 너비,
                margin=dict(t=50, b=10),
                title_x=0.5,  # 타이틀 중앙 정렬
                title_font=dict(size=20, family='Pretendard, sans-serif'),  # 타이틀 폰트 크기 및 폰트 설정
            font=dict(family='Pretendard, sans-serif', size=16),  # 플롯 내 폰트 설정
                showlegend=False
            )

        else:
            fig2 = go.Figure()
            fig2.update_layout(title="관심종목 트리맵", annotations=[{
                'text': '관심종목이 없습니다.',
                'xref': 'paper',
                'yref': 'paper',
                'showarrow': False,
                'font': {'size': 20}
            }])
            
            columns = ['ETF', '거래량(주)', '거래대금(백만)', '거래량추이']
            empty_df = pd.DataFrame(columns=columns)
          
            card=generate_table(empty_df[['ETF','거래량(주)','거래대금(백만)','거래량추이']].sort_values(by='거래대금(백만)',ascending=False),'관심종목 실시간 거래량')
            
            return fig2,card,0
           
        
        df_my_adj=pd.merge(df_my,volume_etf,on='ETF_NM',how='inner') 
        df_my_adj['최근대비'] = df_my_adj.apply(
        lambda row: '👆' if row['value'] > 1.2 * row['TRD_AMT_AVG20'] 
                    else '👇' if row['value'] < 1.2 * row['TRD_AMT_AVG20'] 
                    else '👉', axis=1)
    
        df_my_adj = df_my_adj.rename(columns={'ETF_NM':'ETF', 'volume':'거래량(주)','value':'거래대금(백만)', '최근대비': '거래량추이'})
        card=generate_table(df_my_adj[['ETF','거래량(주)','거래대금(백만)','거래량추이']].sort_values(by='거래대금(백만)',ascending=False),'관심종목 실시간 거래량')

        return fig2,card,0
    
    # 트리맵2 생성 콜백 
    @app.callback(
        Output("stock-chart2", "figure"),
        Output("update-data-button2", "n_clicks"),
        Input("update-data-button2", "n_clicks")     # 업데이트 버튼
    )
    def treemap_fav2(n):
        username = session.get('username')
        global df_kr
        global df_gl
        global df_krstk
        global df_all
        
        if not username:
            return "로그인이 필요합니다.", [], go.Figure()
    
        # # 콜백이 발생한 원인 확인
        ctx = dash.callback_context
        
        trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]

     
        # if favorites:
        if trigger_id == 'update-data-button2':
                df_kr, df_gl, df_krstk= main()
                df_all=pd.concat([df_kr,df_gl])
                ln.update()
                ln.update2()
                save_update_time()
            
        fig=fig_tree(df_kr,df_gl,df_krstk,list_us_stk)
            # 레이아웃 업데이트
        fig.update_layout(
                height=1000,  # 전체 높이
                width=1200,  # 전체 너비
                margin=dict(l=175, r=50, t=30, b=0),
                showlegend=False
            )

        return fig,0
    
    # # 클릭된 종목의 뉴스를 팝업으로 표시하고 닫기 버튼을 동적으로 생성하는 콜백
    @app.callback(
        [Output('popup-news', 'children'),
          Output('popup-news', 'style'),
          Output('popup-visible', 'data')],
        [Input('stock-chart2', 'clickData'),
          Input({'type': 'dynamic-button', 'index': ALL}, 'n_clicks')],
        [State('popup-visible', 'data')]
    )
    def display_news_popup(clickData_kr, close_clicks, popup_visible):
        
        selected_date=today.strftime('%Y%m%d')
        
        
        date_kr=f"""SELECT MAX(TR_YMD) TR_YMD FROM FN_ETFINFO WHERE TR_YMD<='{selected_date}'"""  
        date_kr = pd.read_sql(date_kr, conn)['TR_YMD'][0]
        date_us=f"""SELECT MAX(TR_YMD) TR_YMD FROM QUANT1.DBO.EOD0JG WHERE TR_YMD<'{date_kr}'AND JM_NM='APPLE'"""
        date_us = pd.read_sql(date_us, conn)['TR_YMD'][0]
        date_jmnews=f""" SELECT MAX(TRD_DT) TRD_DT FROM STOCK_NEWS_SUMMARY WHERE TRD_DT<= '{selected_date}'"""
        date_jmnews = pd.read_sql(date_jmnews, conn)['TRD_DT'][0]
        
        # 기본 스타일 (숨김 상태)
        style = {'display': 'none', 'position': 'absolute', 'padding': '20px', 'background-color': '#f9f9f9', 'border': '1px solid #ccc', 'box-shadow': '2px 2px 10px rgba(0, 0, 0, 0.1)'}

        # 닫기 버튼 클릭 시 팝업 닫기
        if any(close_clicks) and popup_visible:
            return "", style, False

        # 클릭된 데이터가 있는 경우 팝업을 띄우고 내용을 표시
        jm_news=f"""
            select TRD_DT,JM_NM,SUMMARY from STOCK_NEWS_SUMMARY sns
            UNION
            SELECT TRD_DT,ETF_NM,SUMMARY fROM ETF_NEWS_SUMMARY ens 
            WHERE TRD_DT='{date_jmnews}'"""
        jm_news = pd.read_sql(jm_news, conn)
        

            
        if clickData_kr :
            label = clickData_kr['points'][0]['label']
            
            news = jm_news[jm_news['JM_NM'] == label]
            #df_kr, df_gl = main()  # 데이터 가져오기
            for index, row in news.iterrows():
                news_summary = re.split(r'관련 뉴스 링크:',  row['SUMMARY'])[0].strip()

            # 팝업 위치를 고정된 위치로 설정
            style['display'] = 'block'
            style['left'] = '82%'  # 팝업의 가로 위치
            style['top'] = '80%'   # 팝업의 세로 위치

            return html.Div([
                html.H4(f"News for {label}"),
                html.P(news_summary),
                html.Button("Close", id={'type': 'dynamic-button', 'index': 'close'}, n_clicks=0)
            ]), style, True

        return "", style, False
    
    
    # 탭 구분하여 나타내는 콜백 함수
    @app.callback(
        Output('tabs-content', 'children'),
        Input('tabs', 'value')
    )
    def render_content(tab):
        if tab == 'tab-1':
            return dbc.Container([
                dbc.Card([
                    dbc.Row([html.P(
                        "종목 클릭시 관련뉴스 요약을 볼 수 있습니다.",
                        style={"whiteSpace": "pre-line", "font-weight": "bold", "color": '#4C2C0E'}
                    ),
                        html.Div("마지막 업데이트시간: " + read_update_time(), style={"margin-top": "20px", "text-align": "right"}),
                        # 버튼을 감싸는 로딩 인디케이터 추가
                        dbc.Col(
                            dcc.Loading(
                                id="loading-indicator1",
                                type="circle",  # 로딩 인디케이터 타입
                                children=[
                                    dbc.Button('🔄', id="update-data-button2", style={"font-size": "40px", "border": "none", "background": "none"})
                                ],
                                fullscreen=False  # 전체화면 로딩 해제, 버튼 위에서만 로딩
                            ),
                            width="auto"
                        ),
                    ], justify="end"),                
                dbc.Row(dbc.Col([dbc.Card(
                        dbc.CardBody([
                            html.Div([
                                html.Div([
                                    # html.H6(f"총 성과: {total_performance_combined:.2f}% 종목 성과: {constituent_performance:.2f}% 기타 성과 (환율, 비용 등): {dollar_performance:.2f}%", className="card-title", style={"font-weight": "bold"}),
                                    html.P(summary3, className="card-text", style={"whiteSpace": "pre-line","font-weight": "bold","font-size": "14px", "color": "#6c757d"}),
                                ], className="ml-3"),
                            ], className="d-flex align-items-center"),  # 아이콘과 텍스트 정렬
                        ]),
                        className="mb-3 shadow-sm",
                        style={"border-left": "5px solid #6390bf", "border-radius": "10px", "top": "10px",  # 화면의 상단으로 이동
                        "right": "60px" },  # 카드 좌측에 강조선 추가
                    )],width=8),justify="center"),
                dbc.Row([
                    dcc.Graph(id="stock-chart2", clickData=None)  # 차트 영역
                ]),dbc.Row([
                    dbc.Col(
                        dbc.Card(
                            dbc.CardBody([                        
                                # html.H5("실시간 국내 주식 상승 TOP5", className="card-title text-center"),
                                generate_table(pd.concat([top5,bot5]), '실시간 주요등락 종목현황')  # Insert the table into the card
                            ]),
                            className="text-left mt-5",
                            style={"width": "100%", "margin": "auto"},  # Set card width and center it
                        ),
                        width=12,  # Full width for the card
                    )
                ], justify="center")])], style={"fontFamily": "Pretendard"}, fluid=True)

        elif tab == 'tab-2':
            return dbc.Container([
                dbc.Card([dbc.Row([html.P(
                    "종목 클릭시 전일성과 분석 페이지로 이동합니다",
                    className="text-left",
                    style={"whiteSpace": "pre-line", "font-weight": "bold", "color": '#4C2C0E'}
                ),html.Div("마지막 업데이트시간: " + read_update_time(), style={"margin-top": "20px", "text-align": "right"}),

                    # 버튼을 감싸는 로딩 인디케이터 추가
                    dbc.Col(
                        dcc.Loading(
                            id="loading-indicator2",
                            type="circle",  # 로딩 인디케이터 타입
                            children=[
                                dbc.Button('🔄', id="update-data-button", style={"font-size": "40px", "border": "none", "background": "none"})
                            ],
                            fullscreen=False  # 전체화면 로딩 해제, 버튼 위에서만 로딩
                        ),
                        width="auto"
                    ),
                ], justify="end"),
                    
                # 관심 ETF 체크박스 및 차트 섹션
                dbc.Row([
                    dbc.Col([dbc.Card(dcc.Graph(id="stock-chart", className="mt-4"),style={"margin-left": "5px","margin-right": "5px"}),  
                     
                    ], width=7),
                    
                    dbc.Col([
                        dbc.Card(
                            # dbc.Col(dbc.Button("관심 종목 지정하기", id="go-back", color="primary", size="sm", className="mr-1", href="/ho-ga-admin"), width="auto"),
                            dbc.CardBody([
                                html.Div(id='volume')  # Insert the table into the card
                            ]),
                            className="mb-3 shadow-sm",
                            style={"maxHeight": "580px", "overflowY": "scroll"}  # 최대 높이 및 스크롤 추가
                        ),
                    ], width=5),
                ], className="mt-4", style={"margin-left": "5px","margin-right": "5px"}),
                          
                dbc.Row([dbc.Card(dbc.Row([
                    
                    dbc.Row([
                        html.H3("관심 ETF 관리", className="text-center", style={"font-weight": "bold"}),
                        dbc.Col(dbc.Button("전체 선택", id="select-all-button", color="success", size="sm", className="mr-1"), width="auto"),
                        dbc.Col(dbc.Button("전체 선택 해제", id="deselect-all-button", color="danger", size="sm", className="mr-1"), width="auto"),
                        dbc.Col(dbc.Button("저장", id="save-button", color="primary", size="sm", className="mr-1"), width="auto"),
                        #dbc.Col(dbc.Button("시장 모니터링 돌아가기", id="go-back", color="primary", size="sm", className="mr-1", href="/treemap"), width="auto")                    
                    ], justify="end", className="mt-2",),  
                    dbc.Col([
                        html.H4("시장대표 ETF", className="mt-4"),
                        dcc.Checklist(
                            id="etf-checklist1",
                            options = [{'label': etf, 'value': etf} for etf in df_all[df_all['ETF_NM'].isin(df_mkt[df_mkt['ETF_AST_MID'] == '시장대표']['ETF_NM'])]['ETF_NM']],
                            value=[],  # 기본적으로 비어 있는 상태
                            inline=True,
                            labelStyle={"display": "block", "marginBottom": "5px","textAlign": "left"},  # 고정된 너비와 왼쪽 정렬
                            style={"maxHeight": "400px", "overflowY": "scroll"}  # 최대 높이 및 스크롤 추가
                        ),
                    ], width=4),  # 주식 ETF 열

                    # 해외 ETF 체크박스
                    dbc.Col([
                        html.H4("전략형 ETF", className="mt-4"),
                        dcc.Checklist(
                            id="etf-checklist2",
                            options = [{'label': etf, 'value': etf} for etf in df_all[df_all['ETF_NM'].isin(df_mkt[df_mkt['ETF_AST_MID'] == '전략']['ETF_NM'])]['ETF_NM']],
                            value=[],  # 기본적으로 비어 있는 상태
                            inline=True,
                            labelStyle={"display": "block", "marginBottom": "5px","textAlign": "left"},  # 고정된 너비와 왼쪽 정렬
                            style={"maxHeight": "400px", "overflowY": "scroll"}  # 최대 높이 및 스크롤 추가
                        ),
                    ], width=4),  # 채권 ETF 열
                    
                    dbc.Col([
                        html.H4("업종섹터 ETF", className="mt-4"),
                        dcc.Checklist(
                            id="etf-checklist3",
                            options = [{'label': etf, 'value': etf} for etf in df_all[df_all['ETF_NM'].isin(df_mkt[df_mkt['ETF_AST_MID'] == '업종섹터']['ETF_NM'])]['ETF_NM']],
                            value=[],  # 기본적으로 비어 있는 상태
                            inline=True,
                            labelStyle={"display": "block", "marginBottom": "5px","textAlign": "left"},  # 고정된 너비와 왼쪽 정렬
                            style={"maxHeight": "400px", "overflowY": "scroll"}  # 최대 높이 및 스크롤 추가
                        ),
                    ], width=4),  # 채권 ETF 열
                ]),style={
                        "width": "1400px",  # 카드의 너비를 200px로 설정
                        "height": "550px"})],justify="center"),  # 카드의 높이를 150px로 설정),
                dbc.Button("로그아웃", id="logout-button", color="secondary", className="mt-3"),
                dcc.Location(id="url-redirect", refresh=True)])], style={"fontFamily": "Pretendard"}, fluid=True)
                    
       
    ## 페이지 이동 관리     
    # 트리맵 클릭 시 성과 분석 페이지로 이동
    @app.callback(
        Output('url', 'href'),
        [Input('stock-chart', 'clickData')],
        prevent_initial_call=True   
    )
    def redirect_to_performance(clickData_kr):
        if clickData_kr:
            label = clickData_kr['points'][0]['label']
            # 성과 분석 페이지로 이동하며 클릭된 종목 이름을 URL 파라미터로 전달
            return f"/analysis?etf={urllib.parse.quote(label)}"
        return dash.no_update

    
    
    ## 로그아웃 콜백
    @app.callback(
        Output("url-redirect", "pathname"),
        Input("logout-button", "n_clicks"),
        prevent_initial_call=True
    )
    def logout_user(n_clicks):
        session.pop('logged_in', None)
        session.pop('username', None)
        return "/login"
    
    