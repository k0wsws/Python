# Page Layout

import dash
from dash import dcc, html, Input, Output, State, ALL
import dash_bootstrap_components as dbc
import plotly.graph_objs as go
import plotly.express as px
import pandas as pd
from plotly.subplots import make_subplots
import requests
import urllib.parse  # URL 인코딩/디코딩에 사용
from datetime import datetime, timedelta
import re
import pre.DB_ETF as DB

from pre.get_data import get_etf_manager, main, stock_sector, get_etf_data, get_nav_chg, get_etf_data2, get_nav_chg2
from pre.layout_func import create_keyword_boxes, generate_table

# 필요한 변수 설정
df_lp1 = get_etf_manager()
df_kr, df_gl, df_krstk= main()
df_all=pd.concat([df_kr,df_gl])

sector = stock_sector()
conn = DB.conn()

# Finviz 스타일의 색상 스케일 (빨간색에서 초록색까지)
finviz_colorscale = [
    [0.0, '#ec413f'],  # 매우 낮은 값 (음수)
    [0.5, '#4f4554'],  # 중간 값 (0%)
    [1.0, '#46ad57']   # 매우 높은 값 (양수)
]

finviz_colorscale = [
    [0.0, '#ec413f'],  # 매우 낮은 값 (음수)
    [0.5, '#4f4554'],  # 중간 값 (0%)
    [1.0, 'blue']   # 매우 높은 값 (양수)
]



requests.packages.urllib3.disable_warnings()  # Ignore SSL warnings


# analysis 레이아웃 생성
layout = dbc.Container([
        dbc.Card([
            dbc.CardBody([
                # html.H2("성과 분석", className="text-center mb-4"),
                html.P(" 전일 종목 뉴스들을 AI로 요약하고,\n ACE ETF 종목의 손익기여 데이터와 함께 성과분석 코멘트를 작성하여 제공합니다.", className="text-left",style={"whiteSpace": "pre-line","font-weight": "bold","color":'#4C2C0E'}),
                dbc.Row([
                    dbc.Col([
                        html.Label("ETF 선택"),
                        dcc.Dropdown(id='etf-name', placeholder="ETF 선택"),  # 클릭된 종목을 반영
                    ], width=6),
                    dbc.Col([
                        html.Label("기준일 선택"),
                        dcc.DatePickerSingle(id='selected-date', date=datetime.today().date(),display_format='YYYY-MM-DD',  # 표시 형식을 조정 가능
                                             style={"display": "block", "width": "100%"})  # 전체 너비로 설정)
                    ], width=6),
                ], className="mb-4"),
                dbc.Row([
                    dbc.Col([
                        html.H5("ETF Today's AI Brief", className="text-center mb-4", style={"font-weight": "bold"}),
                        html.Div(id='news-content'),
                    ], width=12)  # 뉴스 데이터는 오른쪽 4열을 차지
                ]),
                dbc.Row([
                    dbc.Col([
                        html.H5("주요 종목 뉴스 AI Summary", className="text-center mb-4", style={"font-weight": "bold"})
                    ], width=12)
                ]),
                dbc.Row([
                    dbc.Col(html.Div(id='news-content-1'), width=6),  # 첫 번째 열
                    dbc.Col(html.Div(id='news-content-2'), width=6)   # 두 번째 열
                ], className="mb-3"),
                dbc.Row([
                    dbc.Col(html.Div(id='news-content-3'), width=6),  # 세 번째 열
                    dbc.Col(html.Div(id='news-content-4'), width=6)   # 네 번째 열
                ]),
                dbc.Row([
                    dbc.Col([
                        dcc.Graph(
                            id='performance-pie-chart',
                            style={'textAlign': 'center'}  # 차트를 가운데 정렬
                        ),dcc.Graph(
                            id='performance-etf',
                            style={'textAlign': 'center'}  # 차트를 가운데 정렬
                        )
                    ], width=12, className='d-flex justify-content-center')  # Col 가운데 정렬
                ]),
                dbc.Row([ html.H3('업종별 기여성과', className="text-left my-4", style={"font-family": "Pretendard, sans-serif", "color": "#6390bf"}),
                                dbc.Col(dcc.Graph(id='performance-bar-chart',style={'textAlign': 'center'} ), width=4, className="mb-4"),
                                dbc.Col(html.Div(id='topsector'), width=4, className="mb-4"),
                                dbc.Col(html.Div(id='botsector'), width=4, className="mb-4"),
                ]),
                dbc.Row([
                    html.H3('구성종목 TOP5 기여성과 ', className="text-left my-4", style={"font-family": "Pretendard, sans-serif", "color": "#6390bf"}),
                    dbc.Col(dcc.Graph(id='contribution-bar-chart'), width=4, className="mb-4"),
                    dbc.Col(html.Div(id='top5'), width=4, className="mb-4"),
                    dbc.Col(html.Div(id='bot5'), width=4, className="mb-4"),
                ]),
                
                html.H3("ETF 전체 성과", className="mt-4 text-center"),
                dbc.Row([
                    dbc.Col(dbc.Card(dbc.CardBody([
                        html.H6("총 성과", className="text-center"),
                        html.H2(id='total-performance', className="text-center")
                    ])), width=4, className="mb-4"),
                    dbc.Col(dbc.Card(dbc.CardBody([
                        html.H6("종목 성과", className="text-center"),
                        html.H2(id='constituent-performance', className="text-center")
                    ])), width=4, className="mb-4"),
                    dbc.Col(dbc.Card(dbc.CardBody([
                        html.H6("기타 성과 (환율, 비용 등)", className="text-center"),
                        html.H2(id='dollar-performance', className="text-center")
                    ])), width=4, className="mb-4"),
                ])
            ])
        ], className="shadow p-4"),
    ], style={"fontFamily": "Pretendard"}, fluid=True)
    

# 콜백 함수 추가 (해당 페이지에 쓰이는 콜백)
def register_callbacks(app):
    # etf-name 가져오기
    @app.callback(
        dash.dependencies.Output('etf-name', 'value'),
        [dash.dependencies.Input('url', 'pathname'),
         dash.dependencies.Input('url', 'search')]
    )
    def update_etf_name(pathname, search):
        etf_name = 'ACE 200'  # 기본값
        if search:
            params = urllib.parse.parse_qs(search[1:])
            etf_name = params.get('etf', [None])[0]
        return etf_name
    
    # ETF 선택 옵션 업데이트
    @app.callback(
        Output('etf-name', 'options'),
        Input('selected-date', 'date')
    )
    def update_etf_options(selected_date):
        conn = DB.conn()
        ace_query = """
        SELECT ETF_NM NM FROM FN_ETFDATA 
        WHERE TR_YMD=(SELECT MAX(TR_YMD) FROM FN_ETFINFO WHERE TR_YMD<=GETDATE()) 
        AND ETF_CD IN (SELECT STk_CD FROM ES_fUND_MAP) 
        AND (ETF_NM NOT LIKE '%레버리지%' AND ETF_NM NOT LIKE '%합성%')
        """
        ace = pd.read_sql(ace_query, conn)
        conn.close()

        return [{'label': nm, 'value': nm} for nm in ace['NM']]
    
    # 성과 분석 차트 업데이트
    @app.callback(
        [Output('performance-pie-chart', 'figure'),
         Output('performance-etf', 'figure'),
         Output('news-content', 'children'),
         Output('news-content-1', 'children'),
         Output('news-content-2', 'children'),
         Output('news-content-3', 'children'),
         Output('news-content-4', 'children'),
         Output('top5', 'children'),
         Output('bot5', 'children'),
         Output('topsector', 'children'),
         Output('botsector', 'children'),
         Output('performance-bar-chart', 'figure'),
         Output('contribution-bar-chart', 'figure'),
         Output('total-performance', 'children'),
         Output('constituent-performance', 'children'),
         Output('dollar-performance', 'children')],
        [Input('etf-name', 'value'),
         Input('selected-date', 'date')]
    )
    def update_charts(etf_name, selected_date):
        
        date_kr=f"""SELECT MAX(TR_YMD) TR_YMD FROM FN_ETFINFO WHERE TR_YMD<='{selected_date}'"""  
        date_kr = pd.read_sql(date_kr, conn)['TR_YMD'][0]
        date_us=f"""SELECT MAX(TR_YMD) TR_YMD FROM QUANT1.DBO.EOD0JG WHERE TR_YMD<'{date_kr}'AND JM_NM='APPLE'"""
        date_us = pd.read_sql(date_us, conn)['TR_YMD'][0]
        date_jmnews=f""" SELECT MAX(TRD_DT) TRD_DT FROM STOCK_NEWS_SUMMARY WHERE TRD_DT<= '{selected_date}'"""
        date_jmnews = pd.read_sql(date_jmnews, conn)['TRD_DT'][0]
        if etf_name:
            
            df = get_etf_data2(etf_name, selected_date)
            rt = get_nav_chg2(etf_name, selected_date)
            
            etf_news=f"""
            SELECT ETF_NM,SUMMARY FROM ETF_NEWS_SUMMARY where trd_dt=(select max(trd_dt) from ETF_NEWS_SUMMARY WHERE TRD_DT <='{selected_date}')
            """
            df2=pd.read_sql(etf_news, conn)
            
            news=df2[df2['ETF_NM']==etf_name]
            selected_date = datetime.strptime(selected_date, '%Y-%m-%d')
            selected_date = selected_date.strftime('%Y%m%d')
            jm_news=f"""
            SELECT A.*,B.NAV_CHG_1D ETF_RT FROM (SELECT FUND_NM,JM_KSD_CD TICKER,A.JM_NM,RT*100 RT,ROUND(CT_RT,3) CT_RT,ISNULL(SUMMARY,'관련된 최신 뉴스가 없습니다') SUMMARY FROM (SELECT * fROM (
        SELECT A.*,RANK() OVER (PARTITION BY FUND_NM ORDER BY CT_RT DESC) RK1,RANK() OVER (PARTITION BY FUND_NM ORDER BY CT_RT ASC) RK2  FROM (
        SELECT KSD_FUND_CD,FUND_NM,A.JM_KSD_CD,A.JM_NM,A.JM_WT,A.JM_WT*B.RT/100 CT_RT,B.RT/100 RT fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.FN_STOCK B 
        WHERE A.JM_KSD_CD =SUBSTRING(B.JM_CD,2,6) AND A.TR_YMD=B.TR_YMD AND A.TR_YMD='20241128' AND FUND_NM LIKE 'ACE%'
        UNION
        SELECT KSD_FUND_CD,FUND_NM,TICKER_ID,A.JM_NM,A.JM_WT, A.JM_WT*(ROUND((B.JONGGA /D.JONGGA-1),4)) CT_RT,ROUND((B.JONGGA /D.JONGGA-1),4) RT  
        fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.EOD0JG  B , QUANT1.DBO.EOD0JG  D, (select DISTINCT LEFT(TICKER_ID, CHARINDEX(' ', TICKER_ID) ) as TICKER_ID, JM_KSD_CD from (SELECT DISTINCT ISIN_ID, TICKER_ID FROM BFXA1000) A, QUANT1.DBO.FDTWB_ETFPDF B where A.ISIN_ID=B.JM_KSD_CD AND TR_YMD='20241128') C
        WHERE A.JM_KSD_CD =B.JM_CD 
        AND A.JM_KSD_CD =C.JM_KSD_CD 
        AND A.TR_YMD='20241128'
        AND B.TR_YMD='20241127'
        AND D.TR_YMD='20241101'
        AND A.JM_KSD_CD =D.JM_CD 
        AND FUND_NM LIKE 'ACE%') A) A WHERE RK1 IN (1,2) OR RK2 IN (1,2)) A LEFT OUTER JOIN STOCK_NEWS_SUMMARY_M B ON A.JM_KSD_CD=B.TICKER AND  B.TRD_DT='202411') A, (SELECT ETF_cD,ETF_NM,NAV_CHG_1D  fROM FN_ETFDATA WHERE TR_YMD='20241128') B WHERE A.FUND_NM=B.ETF_NM
"""
            jm_news = pd.read_sql(jm_news, conn)
            news2=jm_news[jm_news['FUND_NM']==etf_name]
            
            # 기여도 산출
            df['contribution'] = df['performance'] * df['weight']
            total_performance = df['contribution'].sum()
            
            # ETF 전체 성과 계산
            constituent_performance = total_performance
            total_performance_combined = rt
            dollar_performance = rt - constituent_performance

            fig2 = make_subplots(rows=1, cols=1, 
                                specs=[[{'type': 'domain'}]])
            fig2.add_trace(
                go.Treemap(
                    labels=df['constituent_name'],
                    parents=["" for _ in df['constituent_name']],  # 최상위 노드 (부모가 없는 노드)
                    values=df['weight'],
                    marker=dict(
                    colors=df['performance']*100,
                    cmin=-3,  # 색상 범위 최소값을 diff 최소값으로 설정
                cmax=3,  # 색상 범위 최대값을 diff 최대값으로 설정
                    colorscale=finviz_colorscale,  # 빨강-파랑 색상 스케일
            ),
                    text=df['performance']*100,  # 텍스트로 diff 데이터를 사용
                    texttemplate="<b>%{label}</b><br> %{text:.2f}%",  # 텍스트 형식 설정: label과 diff 표시
                    textposition="middle center",  # 텍스트를 중앙에 위치
                ),
                row=1, col=1
            )
            
            
            fig2.update_layout(title="편입종목 트리맵",
                height=550,  # 전체 높이
                width=900,  # 전체 너비,
                margin=dict(l=180, r=50, t=30, b=30),
                title_x=0.56,
                title_font=dict(size=20, family='Pretendard, sans-serif'),  # 타이틀 폰트 크기 및 폰트 설정
            font=dict(family='Pretendard, sans-serif', size=16),
                showlegend=False
            )
            
            # 뉴스 데이터를 카드 형태로 표시
            
            news_cards = []
            # '키워드:'가 포함된 경우와 포함되지 않은 경우를 처리
            for index, row in news.iterrows():
                if '키워드:' in row['SUMMARY']:
                    # '키워드:'를 기준으로 뉴스 요약과 키워드 부분을 나눔
                    parts = re.split(r'키워드:', row['SUMMARY'], maxsplit=1)
                    news_summary = parts[0].strip()  # 키워드 이전의 뉴스 요약 부분
                    keywords_part = parts[1].strip()  # 키워드 이후 부분
            
                    # 키워드를 리스트로 변환 (쉼표로 구분)하고 각 키워드에 '#' 추가
                    keywords = [f"#{keyword.strip()}" for keyword in keywords_part.split(',')]
                else:
                    # '키워드:'가 없는 경우 전체 텍스트를 요약으로 간주
                    news_summary = row['SUMMARY'].strip()
                    keywords = []  # 키워드가 없는 경우 빈 리스트
                

                
                keyword_boxes = create_keyword_boxes(keywords)                        
                card = dbc.Card(
                    dbc.CardBody([
                        html.Div([
                            html.Div([
                                html.H6(f"총 성과: {total_performance_combined:.2f}% 종목 성과: {constituent_performance:.2f}% 기타 성과 (환율, 비용 등): {dollar_performance:.2f}%", className="card-title", style={"font-weight": "bold"}),
                                dcc.Markdown(news_summary, className="card-text", style={"font-size": "14px", "color": "#6c757d"}),  # Display the main text
                                html.Div(keyword_boxes, style={"margin-top": "10px"}) ,
                            ], className="ml-3"),
                        ], className="d-flex align-items-center"),  # Align icon and text
                    ]),
                    className="mb-3 shadow-sm",
                    style={"border-left": "5px solid #6390bf", "border-radius": "10px"}  # Emphasize the left side of the card
                )
                news_cards.append(card)


            news_cards2 = []
            for index, row in news2.iterrows():
                
                if row['SUMMARY']!='관련된 최신 뉴스가 없습니다':
                    news_summary = re.split(r'관련 뉴스 링크:',  row['SUMMARY'])[0].strip()
                    news_links = re.findall(r'\((.*?)\)',  row['SUMMARY'].split('관련 뉴스 링크:')[1].strip())
                else:
                    news_summary=row['SUMMARY']
                    news_links='없음'
                    
                
                
                # Function to create HTML link elements
                def create_links(link_list):
                    
                    links = []
                    if link_list!='없음':
                        for idx, url in enumerate(link_list, 1):
                            links.append(html.A(f"링크{idx}", href=url, target="_blank", style={"margin-right": "10px"}))
                    else:
                        links=link_list
                    return links
                                        
                card = dbc.Card(
                    dbc.CardBody([
                        html.Div([
                            html.Div([
                                html.H6(f"{row['JM_NM']} ({row['TICKER']}) ({row['RT']:.2f}%)", className="card-title", style={"font-weight": "bold"}),
                                dcc.Markdown(news_summary, className="card-text", style={"font-size": "14px", "color": "#6c757d"}),  # Display the main text
                                html.Div([
                                    html.Span("관련 뉴스 링크: ", style={"font-weight": "bold"}),  # Bold label for the links
                                    *create_links(news_links)  # Display links as clickable items (e.g., "링크1", "링크2")
                                ], style={"margin-top": "10px"}),
                            ], className="ml-3"),
                        ], className="d-flex align-items-center"),  # Align icon and text
                    ]),
                    className="mb-3 shadow-sm",
                    style={"border-left": "5px solid #6390bf", "border-radius": "10px"}  # Emphasize the left side of the card
                )
                news_cards2.append(card)
            
            # 2x2 뉴스 카드 분배
            news_card_1 = news_cards2[0] if len(news_cards2) > 0 else ""
            news_card_2 = news_cards2[1] if len(news_cards2) > 1 else ""
            news_card_3 = news_cards2[2] if len(news_cards2) > 2 else ""
            news_card_4 = news_cards2[3] if len(news_cards2) > 3 else ""
            
            if not df.empty:
                # 상위 15개 항목을 선택하고, 나머지를 "기타"로 묶기
                top_10 = df.nlargest(15, 'weight')
                
                if len(df)>15:
                    others = df[~df.index.isin(top_10.index)]
                    others_sum = others['weight'].sum()       
                    # '기타' 항목 추가
                    others_df = pd.DataFrame({'constituent_name': ['기타'], 'weight': [others_sum]})
                    top_10 = pd.concat([top_10, others_df], ignore_index=True)

                # 성과 기여도 차트
                fig_pie = px.pie(top_10, values='weight', names='constituent_name', title='ETF 구성종목 비중', hole=0.4,
                                 color_discrete_sequence=px.colors.sequential.Blues)
                # 텍스트 정보를 간소화하고, 원의 크기를 유지
                fig_pie.update_traces(
                    textinfo='label+percent',  # 텍스트 정보를 라벨과 퍼센트로 제한
                    textposition='inside',  # 텍스트를 원 안에 배치
                    insidetextorientation='radial'  # 텍스트가 원형을 따르게 배치
                )
                
                # 레이아웃에서 고정 크기 설정
                fig_pie.update_layout(
                    title={'text':'ETF 구성종목 비중','x':0.53},
                    title_font=dict(
                        size=20,  # 제목 폰트 크기
                        family='Pretendard, sans-serif',  # 폰트 설정
                        color='black',  # 제목 글자 색상
                    ),
                    font=dict(
                        family='Pretendard, sans-serif',
                        size=16
                    ),
                    showlegend=True,  # 범례 표시
                    width=600,  # 원하는 너비로 고정
                    height=500,  # 원하는 높이로 고정
                    margin=dict(t=50, b=50, l=130, r=10),  # 차트 주변 마진 설정
                    uniformtext_minsize=12,  # 텍스트 최소 크기 설정
                    #uniformtext_mode='hide'  # 텍스트가 차트에 너무 크면 숨김
                )
                
                
                # 섹터 기여도 산출
                def convert_percent(value):
                    return f"{value:.1f}%"  # 100을 곱하고, 'bp'를 문자열로 붙임
                
                # 특정 컬럼을 bp 형식으로 변환

          
                df['contribution'] = df['performance'] * df['weight'] 
                df=pd.merge(df,sector,on='JM_CD',how='inner')
                df_groupby=df.groupby('SECTOR')['contribution'].sum().reset_index()
                
                df_groupby['contribution']=round(df_groupby['contribution']*100,1)
                
                df_groupby = df_groupby.rename(columns={'SECTOR': '업종','contribution':'기여수익률(bp)'})
                
                
                df_groupby_plus=df_groupby[df_groupby['기여수익률(bp)']>=0]
                df_groupby_minus=df_groupby[df_groupby['기여수익률(bp)']<0]
                # df_groupby_plus['기여수익률(bp)'] = df_groupby_plus['기여수익률'].apply(convert_percent)
                # df_groupby_minus['기여수익률(bp)'] = df_groupby_minus['기여수익률'].apply(convert_percent)
                
                top_sector=generate_table(df_groupby_plus[['업종','기여수익률(bp)']].sort_values(by='기여수익률(bp)',ascending=False),'상승기여 업종')
                bot_sector=generate_table(df_groupby_minus[['업종','기여수익률(bp)']].sort_values(by='기여수익률(bp)',ascending=True),'하락기여 업종')
                
                # 성과 기여도 차트
                df_groupby=df_groupby.sort_values(by='기여수익률(bp)', ascending=False)
                fig_contrib = px.bar(
                    df_groupby, 
                    x='업종', 
                    y='기여수익률(bp)', 
                    color='업종', 
                    color_discrete_sequence=px.colors.sequential.Viridis
                )
                
                fig_contrib.update_layout(showlegend=False)
                
                total_performance = df['contribution'].sum()
                
                df['contribution']=round(df['contribution']*100,1)
                df['performance']=round(df['performance']*100,2)
                
                df = df.rename(columns={'performance': '수익률','contribution':'기여수익률(bp)','constituent_name_x':'종목명'})
                
                top_5 = df.nlargest(5, '기여수익률(bp)')
                bot_5 = df.nsmallest(5, '기여수익률(bp)')
                top_5['수익률(%)'] = top_5['수익률'].apply(convert_percent)
                bot_5['수익률(%)'] = bot_5['수익률'].apply(convert_percent)
                
                df_sorted_contrib=pd.concat([top_5,bot_5]).sort_values(by='기여수익률(bp)', ascending=False)
                fig_contrib2 = px.bar(df_sorted_contrib, x='종목명', y='기여수익률(bp)',
                                     color='종목명', color_discrete_sequence=px.colors.sequential.Viridis)
                fig_contrib2.update_layout(showlegend=False)
                

                top5_const=generate_table(top_5[['종목명','수익률(%)','기여수익률(bp)']].sort_values(by='기여수익률(bp)',ascending=False),'상승기여 TOP5종목')
                bot5_const=generate_table(bot_5[['종목명','수익률(%)','기여수익률(bp)']].sort_values(by='기여수익률(bp)',ascending=True),'하락기여 TOP5종목')
                

                # ETF 전체 성과 계산
                
                constituent_performance = total_performance
                total_performance_combined = rt
                dollar_performance = rt - constituent_performance

                return (fig_pie,fig2,news_cards,news_card_1,news_card_2,news_card_3,news_card_4,top5_const,bot5_const,top_sector,bot_sector, fig_contrib, fig_contrib2,
                        f"{total_performance_combined:.2f}%", 
                        f"{constituent_performance:.2f}%",
                        f"{dollar_performance:.2f}%")
        return {}, {}, {}, "N/A", "N/A", "N/A"

    