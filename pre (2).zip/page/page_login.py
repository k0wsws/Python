
# Page Layout

from dash import dcc, html, Input, Output, State, ALL
import dash_bootstrap_components as dbc
from flask import Flask, session



# 사용자 정보 설정
users = {
    'ws': {'email': 'user1@example.com', 'name': 'User One', 'password': 'wsws'},
    'jh': {'email': 'user2@example.com', 'name': 'User Two', 'password': 'jhjh'},
    'sh': {'email': 'user3@example.com', 'name': 'User Three', 'password': 'shsh'},
    'ace': {'email': 'user3@example.com', 'name': 'User Three', 'password': 'ace'},
    'jy': {'email': 'user3@example.com', 'name': 'User Three', 'password': 'jyjy'},
    'jih': {'email': 'user3@example.com', 'name': 'User Three', 'password': 'jhjh'},
    'jonghoon': {'email': 'user3@example.com', 'name': 'User Three', 'password': 'jhjh'},
    'cody': {'email': 'user3@example.com', 'name': 'User Three', 'password': 'cody'},
    'hn': {'email': 'user3@example.com', 'name': 'User Three', 'password': 'hnhn'},
    'ys': {'email': 'user3@example.com', 'name': 'User Three', 'password': 'ysys'}
}



# 로그인 페이지 레이아웃
layout = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.H2("로그인 페이지", className="text-center"),
            dcc.Input(id="username", type="text", placeholder="사용자명", className="form-control mb-3"),
            dcc.Input(id="password", type="password", placeholder="비밀번호", className="form-control mb-3"),
            dbc.Button("로그인", id="login-button",  className="w-100", style={"background-color": "4C2C0E", "color": "white"}),
            html.Div(id="login-message", className="mt-3", style={"color": "red"})
        ], width=4)
    ], justify="center", className="vh-100 align-items-center")
])



# 콜백 함수 추가 (해당 페이지에 쓰이는 콜백)
def register_callbacks(app):
    
    # 로그인 콜백
    @app.callback(
        Output("login-message", "children"),
        Output("url", "pathname"),
        Input("login-button", "n_clicks"),
        State("username", "value"),
        State("password", "value"),
        prevent_initial_call=True
    )
    def login_user(n_clicks, username, password):
        if username in users and users[username]['password'] == password:
            session['logged_in'] = True
            session['username'] = username
            return "", "/"
        else:
            return "사용자명 또는 비밀번호가 잘못되었습니다.", "/login"
        