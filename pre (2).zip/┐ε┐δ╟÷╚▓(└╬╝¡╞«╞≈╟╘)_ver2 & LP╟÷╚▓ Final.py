# -*- coding: utf-8 -*-

###### F5로 실행 #######
"""
Created on Thu Aug  4 14:21:04 2022

@author: kwsws123
"""


""" 2025.01.14 AITAS, KFP 설정 환매 및 AP 잔고 데이터 자동화 완료 """
""" BOS 데이터 자동화, 기준가격 데이터 DB화,  """


import os
import warnings
import time
from datetime import date,timedelta,datetime
from pandas.tseries.offsets import BDay
#import datetime
import win32com.client
import math
#from tkinter import *
#from tkinter import filedialog, messagebox
import xlsxwriter
warnings.filterwarnings('ignore')
from tkinter import *
from tkinter import filedialog, messagebox
import pandas as pd
import pyodbc
import path
import xlwings as xw
import openpyxl as op
from openpyxl.styles import PatternFill
from openpyxl.styles import Border, Side
from openpyxl.styles.fonts import Font
from pandas.tseries.offsets import BDay
import exchange_calendars as ecals
import time
from datetime import date

XKRX = ecals.get_calendar("XKRX") # 한국 코드


def Pday(): 
    
    day=date.today()-BDay(1)
    while XKRX.is_session(day) is False:
        day=day-BDay(1)
    
    if day == date(2023, 10, 2):            # 갑자기 생긴 대체공휴일 처리
        day=date(2023, 9, 27)
    if day == date(2025, 1, 27):
        day=date(2025, 1, 24)
    if day == date(2025, 3, 3):
        day=date(2025, 2, 28)

    return day

date1=date.today()-pd.Timedelta(days=1)
date1=date1.strftime('%Y%m%d')

def error():
    messagebox.showinfo("에러","파일날짜확인해주세요")
        
root=path.Path('')
os.getcwd()
server = 'tcp:192.168.194.229,1433'
database = 'etf'
username = 'etf'
password = 'etf@@5282'
 
os.chdir('//Etf_통계용_pc//ETF//Daily//운용현황(ver2)')


##DB 접속
conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
cursor = conn.cursor()    


### Repository Option ###
global_file_path = "C:\\"


#########################신규상장 es_sector_master 추가(퀀티 로그인이 되어있어야함)###################

ck="""select ETF_CD from FN_ETFINFO WHERE TR_YMD=(SELECT MAX(TR_YMD) FROM FN_ETFINFO WHERE TR_YMD<=GETDATE())
EXCEPT
SELECT STK_CD FROM ES_SECTOR_MASTER"""

df_ck=pd.read_sql(ck,conn)

if len(df_ck) == 0:
    print('신규상장없음')
else:
    print('신규상장 '+str(len(df_ck))+'개 있음')
    new=pd.read_excel(f"//Etf_통계용_pc/ETF/Daily/es_sector_master.xlsm",engine='openpyxl',skiprows=12)
    len_org0=len(new)+14
    for i in df_ck['ETF_CD']:
        new=pd.read_excel(f"//Etf_통계용_pc/ETF/Daily/es_sector_master.xlsm",engine='openpyxl',skiprows=12)
        len_org=len(new)+14      
        
        excel=win32com.client.Dispatch("Excel.Application")
        wb = excel.Workbooks.Open(f"//Etf_통계용_pc/ETF/Daily/es_sector_master.xlsm")
        ws = wb.Worksheets('etf') # Worksheet 설정
        ws.Cells(len_org,1).Value = i
        ws.Range("K"+str(len_org-1)+":"+"K"+str(len_org-1)).Copy()
        ws.Paste(ws.Range("K"+str(len_org)))
        wb.Save()
        wb.Close()
        excel.Quit()
        
        
        
    wb = xw.Book(f"//Etf_통계용_pc/ETF/Daily/es_sector_master.xlsm")
    macro_test = wb.macro('Refresh_NewButton')
    macro_test()
    wb.save(f"//Etf_통계용_pc/ETF/Daily/es_sector_master.xlsm")
    # excel.Quit()
    
    
    for i in range(len(df_ck['ETF_CD'])):
        excel=win32com.client.Dispatch("Excel.Application")
        wb = excel.Workbooks.Open(f"//Etf_통계용_pc/ETF/Daily/es_sector_master.xlsm")
        ws = wb.Worksheets('etf') #Worksheet 설정
        val=ws.Cells(len_org0+i,11).Value
        cursor.execute(val)
        cursor.commit()
        wb.Close()
        excel.Quit()


############################ 분배금 인서트 ############################
div = """DECLARE @TRD_DT_MAG VARCHAR(8),
                @TRD_DT VARCHAR(8)
                SET @TRD_DT_MAG ='#{Start_DT}' --영업일 전일 (input값)
                SET @TRD_DT = (select max(TR_YMD) from FN_ETFINFO WHERE ETF_CD='A105190' AND TR_YMD<=@TRD_DT_MAG)    -- 최근영업일
        INSERT INTO ES_FUND_DIV (TRD_DT, FUND_CD, DIV_AMT)
        sELECT CLS_TERM_TODATE AS TRD_DT,
                FUND_ID AS FUND_CD,
                DIVD_AMT/QTY AS DIV_AMT 
        fROM BP000601 
        where cls_term_todate=@TRD_DT and FUND_ID like '9%'
    """

div = div.replace('#{Start_DT}', date1)

try:
    cursor.execute(div)
    conn.commit()  # 트랜잭션 커밋
    print("분배금 적재완료")
    
except pyodbc.IntegrityError as e:
    # Primary Key 오류 무시
    print("Primary Key 오류가 발생했지만 무시합니다:", e)
    conn.commit()  # 오류가 발생해도 트랜잭션을 계속 진행
except Exception as e:
    # 다른 예외 처리
    print("예상치 못한 오류 발생:", e)
    conn.commit()


############################ 인서트 (BOS, AITAS, KFP 데이터) ###################################

try:
    # SQL 실행 (예: 데이터 삽입)
    cursor.execute("EXEC Insert_ES_MAG_STATUS_M @StartDate=?, @EndDate=?", (date1, date1))
    cursor.execute("EXEC Insert_B8061 @StartDate=?, @EndDate=?", (date1, date1)) ## 2분정도걸림
    
    conn.commit()  # 트랜잭션 커밋
    
    print("적재완료")
    
except pyodbc.IntegrityError as e:
    # Primary Key 오류 무시
    print("Primary Key 오류가 발생했지만 무시합니다:", e)
    conn.commit()  # 오류가 발생해도 트랜잭션을 계속 진행
except Exception as e:
    # 다른 예외 처리
    print("예상치 못한 오류 발생:", e)



    
################################데이터 불러오기##########################################

## B8009_운용현황
# df = pd.read_csv(f'//Etf_통계용_pc/ETF/data/BOS_DAILY/B8009_운용현황.csv',encoding='cp949')

## B8183_기준가격현황
#df2 = pd.read_csv(f'//Etf_통계용_pc/ETF/data/BOS_DAILY/B8183_기준가격현황.csv',encoding='cp949')   

# 1) 아이타스    
# df3 = pd.read_excel(f'//Etf_통계용_pc/ETF/data/AITAS/A11400_ETF설정환매.xlsx',engine='openpyxl') 
    
# # 2) 한국펀드파트너스    
# df4 = pd.read_excel(f'//Etf_통계용_pc/ETF/data/KFP/M2502_ETF설정환매.xlsx',engine='openpyxl')        


##################################데이터 전처리##############################################

# df = df[1:]
# df=df.iloc[:,1:]
# df['ETF']=['ETF' if s.startswith('9') else 'FUND' for s in df['펀드']]
# df.rename(columns={'Unnamed: 12':'BND_NAV_RT'},inplace=True)
# df.rename(columns={'Unnamed: 13':'BND_TA_RT'},inplace=True)
# df.rename(columns={'Unnamed: 15':'STK_NAV_RT'},inplace=True)
# df.rename(columns={'Unnamed: 16':'STK_TA_RT'},inplace=True)
# df.rename(columns={'Unnamed: 18':'DRV_NAV_RT'},inplace=True)
# df.rename(columns={'Unnamed: 19':'DRV_TA_RT'},inplace=True)
# df.rename(columns={'Unnamed: 21':'CIS_NAV_RT'},inplace=True)
# df.rename(columns={'Unnamed: 22':'CIS_TA_RT'},inplace=True)
# df.rename(columns={'Unnamed: 24':'CASH_NAV_RT'},inplace=True)
# df.rename(columns={'Unnamed: 25':'CASH_TA_RT'},inplace=True)
# df.rename(columns={'Unnamed: 29':'STD_CHG'},inplace=True)
# df['기준일']=df['기준일'].str.replace('-','')
# df['설정일']=df['설정일'].str.replace('-','')
# df['결산일']=df['결산일'].str.replace('-','')
# df['설정액']=df['설정액'].str.replace(',','')
# df['채권']=df['채권'].str.replace(',','')
# df['BND_NAV_RT']=df['BND_NAV_RT'].str.replace(',','')
# df['BND_TA_RT']=df['BND_TA_RT'].str.replace(',','')
# df['주식']=df['주식'].str.replace(',','')
# df['STK_NAV_RT']=df['STK_NAV_RT'].str.replace(',','')
# df['STK_TA_RT']=df['STK_TA_RT'].str.replace(',','')
# df['파생']=df['파생'].str.replace(',','')
# df['DRV_NAV_RT']=df['DRV_NAV_RT'].str.replace(',','')
# df['DRV_TA_RT']=df['DRV_TA_RT'].str.replace(',','')
# df['집합증권']=df['집합증권'].str.replace(',','')
# df['CIS_NAV_RT']=df['CIS_NAV_RT'].str.replace(',','')
# df['CIS_TA_RT']=df['CIS_TA_RT'].str.replace(',','')
# df['현금성기타']=df['현금성기타'].str.replace(',','')
# df['CASH_NAV_RT']=df['CASH_NAV_RT'].str.replace(',','')
# df['CASH_TA_RT']=df['CASH_TA_RT'].str.replace(',','')
# df['순자산']=df['순자산'].str.replace(',','')
# df['총자산']=df['총자산'].str.replace(',','')
# df['기준가격']=df['기준가격'].str.replace(',','')
# df['STD_CHG']=df['STD_CHG'].str.replace(',','')


# df2 = df2[1:]
# df2=df2.iloc[:,1:]
# df2['산출일자']=df2['산출일자'].str.replace('-','')
# df2['수정기준가격']=df2['수정기준가격'].str.replace(',','')


# AITAS
# df3=df3.iloc[:,1:]
# df3.rename(columns={'청구\nCU수':'CU'},inplace=True)
# df3.rename(columns={'업무\n구분':'설정환매'},inplace=True)
# df3=df3.astype(str)
# df3['청구일자']=df3['청구일자'].str.replace('-','')

# for i in range(len(df3)):
#     df3['청구일자'][i]=df3['청구일자'][i][0:8]

# # KFP
# df4=df4.iloc[:,1:]
# df4.rename(columns={'청구\nCU수':'CU'},inplace=True)
# df4.rename(columns={'업무\n구분':'설정환매'},inplace=True)
# df4=df4.astype(str)
# df4['입력일자']=df4['입력일자'].str.replace('-','')



########################## 리셋 #############################

# if df['기준일'][1]==str(date.today()-timedelta(1)).replace("-", "")[0:8]:
#     cursor.execute("Delete from ES_MAG_STATUS_N WHERE TRD_DT= '"+df["기준일"][1]+"'")
# else:
#     print("파일 날짜를 다시 확인해주세요.")

    
# if df2['산출일자'][1]==str(date.today()-timedelta(1)).replace("-", "")[0:8]:
#     cursor.execute("Delete from ES_FUND_PRC WHERE FUND_CD NOT IN ('asiatop50') AND TRD_DT= '"+str(Pday()).replace("-","")[0:8]+"'")
#     # cursor.execute("Delete from ES_SR_DAILY WHERE TRD_DT= '"+df3["청구일자"][0]+"'")
#     # if df4['입력일자'][0]==str(Pday()).replace("-", "")[0:8]:
#     #     cursor.execute("Delete from ES_SR_DAILY WHERE TRD_DT= '"+df4["입력일자"][0]+"'")
#     cursor.commit()
# else:
#     print("파일 날짜를 다시 확인해주세요.")

#############################인서트###########################

# #운용현황
# for index,row in df.iterrows():
#     cursor.execute("INSERT INTO ES_MAG_STATUS_N  values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row.기준일, row.운용역, row.팀명,row.펀드,row.펀드명,row.설정일,row.결산일,row.설정액,str(row.매매회전율),row.잔존만기,str(row.채권),str(row.BND_NAV_RT),str(row.BND_TA_RT),str(row.주식),str(row.STK_NAV_RT),str(row.STK_TA_RT),str(row.파생),str(row.DRV_NAV_RT),str(row.DRV_TA_RT),str(row.집합증권),str(row.CIS_NAV_RT),str(row.CIS_TA_RT),str(row.현금성기타),str(row.CASH_NAV_RT),str(row.CASH_TA_RT),str(row.순자산),row.총자산,row.기준가격,row.STD_CHG,row.일수익률,row.연수익률,row.수탁사,row.ETF)

# cursor.commit()


#기준가

# if (Pday())==datetime.strptime(df2["산출일자"][1],'%Y%m%d'):   
#     for index,row in df2.iterrows():
#         cursor.execute("INSERT INTO ES_FUND_PRC  values(?,?,?)", row.산출일자,row.펀드,row.수정기준가격)
# else:
#     for index,row in df2.iterrows():
#         cursor.execute("INSERT INTO ES_FUND_PRC  values(?,?,?)", str(Pday()).replace("-","")[0:8],row.펀드,row.수정기준가격)
        
# cursor.commit()
    

# ##설정환매
    
# #아이타스

# if df3['청구일자'][0]==str(Pday()).replace("-", "")[0:8]:
#     for index,row in df3.iterrows():
#         cursor.execute("INSERT INTO ES_SR_DAILY  values(?,?,?,?)", row.청구일자,row.ETF종목코드,row.설정환매,row.CU)
        
# cursor.commit()

# #KFP

# if df4['입력일자'][0]==str(Pday()).replace("-", "")[0:8]:
    
#     for index,row in df4.iterrows():
#         cursor.execute("INSERT INTO ES_SR_DAILY  values(?,?,?,?)", row.입력일자,row.ETF종목코드,row.구분,row.CU수)
          
# cursor.commit() 

## 기초데이터 준비.
class generate_data():
    
    def __init__(self,start_dt):
        
        self.start_dt = start_dt
        self.df_date = self.date()
        self.df_date2 = self.date2()
        self.df1 = self.df11()
        self.df_nav = self.df_nav()
        self.df_yield = self.df_yield()
        self.df_overview = self.df_overview()
        self.df_overview_ace = self.df_overview_ace()
        self.df_csfw = self.df_csfw()
        self.df_csfw_ace = self.df_csfw_ace()
        # self.df2 = self.df22()
        self.nav1 = self.NAV()
        self.nav2 = self.NAV2()
        self.ca_kor  =  self.CA_kor()
        self.ca_gbl  =  self.CA_gbl()
        self.df_fee = self.df_fee()
        self.df_AP = self.df_AP()
        self.df_AP_PDAY = self.df_AP_PDAY()
        self.df_p_amt = self.df_p_amt()
        self.df_lp_sum = self.df_lp_sum()


    # 데이터조회
    def date(self):
        
        date = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8),
        		@TRD_DT_PWEEK VARCHAR(8),
        		@TRD_DT_PMON1 VARCHAR(8),
        		@TRD_DT_PMON3 VARCHAR(8),
        		@TRD_DT_PMON6 VARCHAR(8),
        		@TRD_DT_PYEAR VARCHAR(8),
        		@TRD_DT_MTD VARCHAR(8),
        		@TRD_DT_YTD VARCHAR(8)
        
        SET @TRD_DT_MAG ='#{Start_DT}'
        SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)
        SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PWEEK =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(WEEK,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PMON1 =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PMON3 =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-3, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PMON6 =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-6, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PYEAR =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(YEAR,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_MTD =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT LIKE (SELECT CONCAT(SUBSTRING(CONVERT(VARCHAR(8),DATEADD(MONTH,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112),1,6),'%'))) --전월말
        SET @TRD_DT_YTD =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT LIKE (SELECT CONCAT(SUBSTRING(CONVERT(VARCHAR(8),DATEADD(YEAR,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112),1,4),'12%'))); --전년말
        
        SELECT CONVERT(VARCHAR(20),CONVERT(datetime,@TRD_DT_PDAY,1),120) TRD_DT_PDAY,
        	   CONVERT(VARCHAR(20),CONVERT(datetime,@TRD_DT_PWEEK,1),120) TRD_DT_PWEEK,
        	   CONVERT(VARCHAR(20),CONVERT(datetime,@TRD_DT_PMON1,1),120) TRD_DT_PMON1, 
        	   CONVERT(VARCHAR(20),CONVERT(datetime,@TRD_DT_PMON3,1),120) TRD_DT_PMON3,
        	   CONVERT(VARCHAR(20),CONVERT(datetime,@TRD_DT_PMON6,1),120) TRD_DT_PMON6,
        	   CONVERT(VARCHAR(20),CONVERT(datetime,@TRD_DT_PYEAR,1),120) TRD_DT_PYEAR,
        	   CONVERT(VARCHAR(20),CONVERT(datetime,@TRD_DT_MTD,1),120) TRD_DT_MTD,
        	   CONVERT(VARCHAR(20),CONVERT(datetime,@TRD_DT_YTD,1),120) TRD_DT_YTD"""
        
        date = date.replace('#{Start_DT}', self.start_dt)
        df_date=pd.read_sql(date,conn)
                            
        return df_date
    
    def date2(self):
        
        date = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8),
        		@TRD_DT_PWEEK VARCHAR(8),
        		@TRD_DT_PMON1 VARCHAR(8),
        		@TRD_DT_PMON3 VARCHAR(8),
        		@TRD_DT_PMON6 VARCHAR(8),
        		@TRD_DT_PYEAR VARCHAR(8),
        		@TRD_DT_MTD VARCHAR(8),
        		@TRD_DT_YTD VARCHAR(8),
                @TRD_DT_PLAST VARCHAR(8)
        
        SET @TRD_DT_MAG ='#{Start_DT}'
        SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)
        SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PWEEK =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(WEEK,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PMON1 =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PMON3 =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-3, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PMON6 =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-6, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PYEAR =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(YEAR,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_MTD =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT LIKE (SELECT CONCAT(SUBSTRING(CONVERT(VARCHAR(8),DATEADD(MONTH,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112),1,6),'%'))) --전월말
        SET @TRD_DT_YTD =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT LIKE (SELECT CONCAT(SUBSTRING(CONVERT(VARCHAR(8),DATEADD(YEAR,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112),1,4),'12%'))); --전년말
        SET @TRD_DT_PLAST =(select max(trd_dt) from ES_MAG_STATUS_N WHERE FUND_CD='9000A' AND TRD_DT LIKE (SELECT CONCAT(SUBSTRING(CONVERT(VARCHAR(8),DATEADD(YEAR,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112),1,4),'12%'))); --전년마지막날
        
        SELECT @TRD_DT TRD_DT,
               @TRD_DT_PDAY TRD_DT_PDAY,
        	   @TRD_DT_PWEEK TRD_DT_PWEEK,
        	   @TRD_DT_PMON1 TRD_DT_PMON1, 
        	   @TRD_DT_PMON3 TRD_DT_PMON3,
        	   @TRD_DT_PMON6 TRD_DT_PMON6,
        	   @TRD_DT_PYEAR TRD_DT_PYEAR,
        	   @TRD_DT_MTD TRD_DT_MTD,
        	   @TRD_DT_YTD TRD_DT_YTD,
               @TRD_DT_PLAST TRD_DT_PLAST"""
        
        date = date.replace('#{Start_DT}', self.start_dt)
        df_date=pd.read_sql(date,conn)
                            
        return df_date
    
    def df11(self): 

        df_date= self.date2()
        query1 = """
        SELECT A.FUND_CD,FUND_NM,MANAGER,CONVERT(VARCHAR(10),CONVERT(datetime,SET_DT,1),120) SET_DT,CONVERT(VARCHAR(10),CONVERT(datetime,STL_DT,1),120) STL_DT,NAV,RT,B.BP1,B.BP2,B.BP3,B.BP4,B.BP5,B.BP6,B.BP7,B.BP8,SET_AMT/POWER(10,6) SET_AMT,D.CU,C.STD_PRC,typ,NAV_DIF FROM (select A.FUND_CD,M.FUND_NM,A.MANAGER,A.SET_DT,A.STL_DT,A.NAV/POWER(10,6) NAV ,A.SET_AMT, A.TYP,A.RT/100 RT,(isnull(A.NAV,0)-isnull(B.NAV,0))/POWER(10,6) NAV_DIF  from ES_MAG_STATUS_N A LEFT OUTER JOIN ES_FUND_MAP M ON A.FUND_CD = M.FUND_CD LEFT OUTER JOIN ES_MAG_STATUS_N B ON A.FUND_CD=B.FUND_CD AND B.TRD_DT='#{TRD_DT_PLAST}' WHERE A.TRD_DT='#{Start_DT}') A
                                                                              ,(SELECT A.*,B.BP1 BP7,B.BP2 BP8 FROM
        (select isnull(A.FUND_CD,isnull(B.FUND_CD,isnull(C.FUND_CD,isnull(D.FUND_CD,isnull(E.FUND_CD,isnull(F.FUND_CD,null)))))) FUND_CD,A.BP BP1,isnull(B.BP,null) BP2,ISNULL(C.BP,null) BP3,ISNULL(D.BP,null) BP4,ISNULL(E.BP,null) BP5,ISNULL(F.BP,null) BP6 FROM (SELECT
        	A.FUND_CD,ROUND(10000*((B.STD_PRC/A.STD_PRC)-(isnull(convert(float,D.CLS_PRC),1)/isnull(C.CLS_PRC,1))),5) BP
        FROM
        	ES_FUND_PRC_V A,
        	ES_FUND_PRC_V B,
        	(SELECT '#{TRD_DT_PDAY}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT='#{TRD_DT_PDAY}') C,
        	(SELECT '#{TRD_DT}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT= '#{TRD_DT}') D
        WHERE A.FUND_CD = B.FUND_CD
        	AND A.TRD_DT=C.TRD_DT
        	AND B.TRD_DT=D.TRD_DT
        	AND A.FUND_CD= C.FUND_CD
        	AND A.FUND_CD = D.FUND_CD) A LEFT OUTER JOIN (SELECT
        	A.FUND_CD,ROUND(10000*((B.STD_PRC/A.STD_PRC)-(isnull(convert(float,D.CLS_PRC),1)/isnull(C.CLS_PRC,1))),5) BP
        FROM
        	ES_FUND_PRC_V A,
        	ES_FUND_PRC_V B,
        	(SELECT '#{TRD_DT_PWEEK}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT='#{TRD_DT_PWEEK}') C,
        	(SELECT '#{TRD_DT}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT= '#{TRD_DT}') D
        WHERE A.FUND_CD = B.FUND_CD
        	AND A.TRD_DT=C.TRD_DT
        	AND B.TRD_DT=D.TRD_DT
        	AND A.FUND_CD= C.FUND_CD
        	AND A.FUND_CD = D.FUND_CD) B ON A.FUND_CD=B.FUND_CD left OUTER JOIN 
        	(SELECT
        	A.FUND_CD,ROUND(10000*((B.STD_PRC/A.STD_PRC)-(isnull(convert(float,D.CLS_PRC),1)/isnull(C.CLS_PRC,1))),5) BP
        FROM
        	ES_FUND_PRC_V A,
        	ES_FUND_PRC_V B,
        	(SELECT '#{TRD_DT_PMON1}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT='#{TRD_DT_PMON1}') C,
        	(SELECT '#{TRD_DT}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT= '#{TRD_DT}') D
        WHERE A.FUND_CD = B.FUND_CD
        	AND A.TRD_DT=C.TRD_DT
        	AND B.TRD_DT=D.TRD_DT
        	AND A.FUND_CD= C.FUND_CD
        	AND A.FUND_CD = D.FUND_CD) C ON B.FUND_CD=C.FUND_CD  left OUTER JOIN 
        	(SELECT
        	A.FUND_CD,ROUND(10000*((B.STD_PRC/A.STD_PRC)-(isnull(convert(float,D.CLS_PRC),1)/isnull(C.CLS_PRC,1))),5) BP
        FROM
        	ES_FUND_PRC_V A,
        	ES_FUND_PRC_V B,
        	(SELECT '#{TRD_DT_PMON3}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT='#{TRD_DT_PMON3}') C,
        	(SELECT '#{TRD_DT}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT= '#{TRD_DT}') D
        WHERE A.FUND_CD = B.FUND_CD
        	AND A.TRD_DT=C.TRD_DT
        	AND B.TRD_DT=D.TRD_DT
        	AND A.FUND_CD= C.FUND_CD
        	AND A.FUND_CD = D.FUND_CD) D ON C.FUND_CD=D.FUND_CD left OUTER JOIN 
        	(SELECT
        	A.FUND_CD,ROUND(10000*((B.STD_PRC/A.STD_PRC)-(isnull(convert(float,D.CLS_PRC),1)/isnull(C.CLS_PRC,1))),5) BP
        FROM
        	ES_FUND_PRC_V A,
        	ES_FUND_PRC_V B,
        	(SELECT '#{TRD_DT_PMON6}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT='#{TRD_DT_PMON6}') C,
        	(SELECT '#{TRD_DT}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT= '#{TRD_DT}') D
        WHERE A.FUND_CD = B.FUND_CD
        	AND A.TRD_DT=C.TRD_DT
        	AND B.TRD_DT=D.TRD_DT
        	AND A.FUND_CD= C.FUND_CD
        	AND A.FUND_CD = D.FUND_CD) E ON D.FUND_CD=E.FUND_CD left OUTER JOIN 
        	(SELECT
        	A.FUND_CD,ROUND(10000*((B.STD_PRC/A.STD_PRC)-(isnull(convert(float,D.CLS_PRC),1)/isnull(C.CLS_PRC,1))),5) BP
        FROM
        	ES_FUND_PRC_V A,
        	ES_FUND_PRC_V B,
        	(SELECT '#{TRD_DT_PYEAR}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT='#{TRD_DT_PYEAR}') C,
        	(SELECT '#{TRD_DT}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT= '#{TRD_DT}') D
        WHERE A.FUND_CD = B.FUND_CD
        	AND A.TRD_DT=C.TRD_DT
        	AND B.TRD_DT=D.TRD_DT
        	AND A.FUND_CD= C.FUND_CD
        	AND A.FUND_CD = D.FUND_CD) F ON E.FUND_CD=F.FUND_CD ) A left OUTER JOIN 
        	(select A.FUND_CD,A.BP BP1,B.BP BP2 FROM
        (SELECT
        	A.FUND_CD,ROUND(10000*((B.STD_PRC/A.STD_PRC)-(isnull(convert(float,D.CLS_PRC),1)/isnull(C.CLS_PRC,1))),5) BP
        FROM
        	ES_FUND_PRC_V A,
        	ES_FUND_PRC_V B,
        	(SELECT '#{TRD_DT_MTD}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT='#{TRD_DT_MTD}') C,
        	(SELECT '#{TRD_DT}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT= '#{TRD_DT}') D
        WHERE A.FUND_CD = B.FUND_CD
        	AND A.TRD_DT=C.TRD_DT
        	AND B.TRD_DT=D.TRD_DT
        	AND A.FUND_CD= C.FUND_CD
        	AND A.FUND_CD = D.FUND_CD) A  left OUTER JOIN 
        	(SELECT
        	A.FUND_CD,B.STD_PRC,ROUND(10000*((B.STD_PRC/A.STD_PRC)-(isnull(convert(float,D.CLS_PRC),1)/isnull(C.CLS_PRC,1))),5) BP
        FROM
        	ES_FUND_PRC_V A,
        	ES_FUND_PRC_V B,
        	(SELECT '#{TRD_DT_YTD}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT='#{TRD_DT_YTD}') C,
        	(SELECT '#{TRD_DT}' TRD_DT,B.FUND_CD,A.CLS_PRC FROM ES_BM_IDX_V A RIGHT outer join  ES_FUND_MAP B on A.IDX_CD=B.BM_CD AND A.TRD_DT= '#{TRD_DT}') D
        WHERE A.FUND_CD = B.FUND_CD
        	AND A.TRD_DT=C.TRD_DT
        	AND B.TRD_DT=D.TRD_DT
        	AND A.FUND_CD= C.FUND_CD
        	AND A.FUND_CD = D.FUND_CD) B ON A.FUND_CD=B.FUND_CD) B ON A.FUND_CD=B.FUND_CD) B, ES_FUND_PRC_RAW C LEFT OUTER JOIN (SELECT A.FUND_CD, SUM(CU) CU FROM 
        (SELECT A.FUND_CD,CASE WHEN WORK_DS='환매' THEN -CLM_CU_CNT ELSE CLM_CU_CNT END CU FROM ES_FUND_MAP A, ETF_OPCL B WHERE B.CLM_DT='#{TRD_DT}' AND A.ISIN_CD=B.ETF_CD) A 
        GROUP BY A.FUND_CD) D ON C.FUND_CD=D.FUND_CD 
        	WHERE A.FUND_CD=B.FUND_CD
        	AND A.FUND_CD=C.FUND_CD
        	AND C.TRD_DT='#{TRD_DT}'
        	ORDER BY A.TYP ASC, FUND_NM ASC;"""
        	
        query1 = query1.replace('#{Start_DT}', self.start_dt)	
        query1 = query1.replace('#{TRD_DT}', df_date['TRD_DT'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_PDAY}', df_date['TRD_DT_PDAY'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_PWEEK}', df_date['TRD_DT_PWEEK'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_PMON1}', df_date['TRD_DT_PMON1'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_PMON3}', df_date['TRD_DT_PMON3'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_PMON6}', df_date['TRD_DT_PMON6'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_PYEAR}', df_date['TRD_DT_PYEAR'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_MTD}', df_date['TRD_DT_MTD'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_YTD}', df_date['TRD_DT_YTD'][0][0:8])	
        query1 = query1.replace('#{TRD_DT_PLAST}', df_date['TRD_DT_PLAST'][0][0:8])	


        df1=pd.read_sql(query1,conn)
        df1=df1.fillna("")
        
        return df1
    
    def df_overview(self): 
                      
        # 금일 AUM에 넣을 값
        query1 = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8)
        
            SET ANSI_WARNINGS OFF
            SET @TRD_DT_MAG ='#{Start_DT}'
            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
            SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        
            Select TR_YMD,ETF_CD,ETF_NM,AUM '기초AUM',ETF_NAV NAV,CASE WHEN B.ETF_AST_BIG NOT IN ('주식','채권') THEN '기타' ELSE B.ETF_AST_BIG END 'CLASS'  
            From etf.DBO.FN_ETFDATA A, ES_SECTOR_MASTER B WHERE A.ETF_CD=B.STK_CD and A.TR_YMD = @TRD_DT_PDAY
        """
        	
        query1 = query1.replace('#{Start_DT}', self.start_dt)	
        df_ov1=pd.read_sql(query1,conn)
        df_ov1=df_ov1.fillna("")        #전일
        
        # 전일 AUM에 넣을 값
        query2 = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8)
        
            SET ANSI_WARNINGS OFF
            SET @TRD_DT_MAG ='#{Start_DT}'
            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
            SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        
            Select TR_YMD,ETF_CD,ETF_NM,AUM '기초AUM',ETF_NAV NAV,CASE WHEN B.ETF_AST_BIG NOT IN ('주식','채권') THEN '기타' ELSE B.ETF_AST_BIG END 'CLASS'  
            From etf.DBO.FN_ETFDATA A, ES_SECTOR_MASTER B WHERE A.ETF_CD=B.STK_CD and A.TR_YMD = @TRD_DT
        """
        	
        query2 = query2.replace('#{Start_DT}', self.start_dt)	
        df_ov2=pd.read_sql(query2,conn)
        df_ov2=df_ov2.fillna("")        #금일

        df = pd.DataFrame()
        df['기초AUM(억)'] = round(df_ov1.groupby("CLASS")['기초AUM'].sum()/100000000,2)
        df['기말AUM(억)'] = round(df_ov2.groupby("CLASS")['기초AUM'].sum()/100000000,2)
        df['ΔAUM(억)'] = df['기말AUM(억)']-df['기초AUM(억)'].fillna(0)
        df=df.sort_values(by=['CLASS'],axis=0,ascending=False).reset_index()
        
        # print(df)
        
        return df
    
    def df_overview_ace(self): 
                      
        # 금일 AUM에 넣을 값
        query1 = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8)
        
            SET ANSI_WARNINGS OFF
            SET @TRD_DT_MAG ='#{Start_DT}'
            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
            SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        
            Select TR_YMD,ETF_CD,ETF_NM,AUM '기초AUM',ETF_NAV NAV,CASE WHEN B.ETF_AST_BIG NOT IN ('주식','채권') THEN '기타' ELSE B.ETF_AST_BIG END 'CLASS'  
            From etf.DBO.FN_ETFDATA A, ES_SECTOR_MASTER B WHERE A.ETF_CD=B.STK_CD and A.TR_YMD = @TRD_DT_PDAY and A.ETF_NM like 'ACE%'
        """
        	
        query1 = query1.replace('#{Start_DT}', self.start_dt)	
        df_ov1=pd.read_sql(query1,conn)
        df_ov1=df_ov1.fillna("")        #전일
        
        # 전일 AUM에 넣을 값
        query2 = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8)
        
            SET ANSI_WARNINGS OFF
            SET @TRD_DT_MAG ='#{Start_DT}'
            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
            SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        
            Select TR_YMD,ETF_CD,ETF_NM,AUM '기초AUM',ETF_NAV NAV,CASE WHEN B.ETF_AST_BIG NOT IN ('주식','채권') THEN '기타' ELSE B.ETF_AST_BIG END 'CLASS'  
            From etf.DBO.FN_ETFDATA A, ES_SECTOR_MASTER B WHERE A.ETF_CD=B.STK_CD and A.TR_YMD = @TRD_DT and A.ETF_NM like 'ACE%'
        """
        	
        query2 = query2.replace('#{Start_DT}', self.start_dt)	
        df_ov2=pd.read_sql(query2,conn)
        df_ov2=df_ov2.fillna("")        #금일

        df = pd.DataFrame()
        df['기초AUM(억)'] = round(df_ov1.groupby("CLASS")['기초AUM'].sum()/100000000,2)
        df['기말AUM(억)'] = round(df_ov2.groupby("CLASS")['기초AUM'].sum()/100000000,2)
        df['ΔAUM(억)'] = df['기말AUM(억)']-df['기초AUM(억)'].fillna(0)
        df=df.sort_values(by=['CLASS'],axis=0,ascending=False).reset_index()
        
        # print(df)
        
        return df
    
    def df_nav(self): 
                      
        query = """
            DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
        		@TRD_DT_PWEEK VARCHAR(8),
        		@TRD_DT_PMON1 VARCHAR(8),
        		@TRD_DT_PMON3 VARCHAR(8)
        
        SET @TRD_DT_MAG ='#{Start_DT}'
        SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)    -- 직전 영업일
        SET @TRD_DT_PWEEK =(select max(trd_dt) from ES_MAG_STATUS_N WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(WEEK,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))  --1주일
        SET @TRD_DT_PMON1 =(select max(trd_dt) from ES_MAG_STATUS_N WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112))) --1달
        SET @TRD_DT_PMON3 =(select max(trd_dt) from ES_MAG_STATUS_N WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-3, CONVERT(VARCHAR(8), @TRD_DT, 112)),112))) --3달
        
        SELECT A.FUND_CD, AA.NAV/POWER(10,6) NAV_1W, BB.NAV/POWER(10,6) NAV_1M, CC.NAV/POWER(10,6) NAV_3M, AB.typ TYP
            from (select IIF(FUND_CD = 'asiatop50', '9001H', FUND_CD) FUND_CD from ES_FUND_PRC_V where TRD_DT = @TRD_DT) A
            LEFT OUTER JOIN (SELECT FUND_CD ,FUND_NM FROM ES_FUND_MAP) M ON A.FUND_CD = M.FUND_CD
            left outer join (select TRD_DT, FUND_CD, typ from ES_MAG_STATUS_N where TRD_DT = @TRD_DT_MAG) AB on A.FUND_CD = AB.FUND_CD
            left outer join (select TRD_DT, FUND_CD, NAV, typ from ES_MAG_STATUS_N where TRD_DT = @TRD_DT_PWEEK) AA on A.FUND_CD = AA.FUND_CD
            left outer join (select TRD_DT, FUND_CD, NAV from ES_MAG_STATUS_N where TRD_DT = @TRD_DT_PMON1) BB on A.FUND_CD = BB.FUND_CD
            left outer join (select TRD_DT, FUND_CD, NAV from ES_MAG_STATUS_N where TRD_DT = @TRD_DT_PMON3) CC on A.FUND_CD = CC.FUND_CD
        GROUP BY A.FUND_CD, AA.NAV, BB.NAV, CC.NAV, AA.typ, AA.FUND_CD, M.FUND_NM, AB.typ
		ORDER BY AB.typ ASC, M.FUND_NM ASC;
        """
        	
        query = query.replace('#{Start_DT}', self.start_dt)	
        df_nav=pd.read_sql(query,conn)
        df_nav=df_nav.fillna("")
        
        return df_nav
    
    def df_csfw(self): 
                      
        # 금일 AUM에 넣을 값
        query1 = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8)
        
            SET ANSI_WARNINGS OFF
            SET @TRD_DT_MAG ='#{Start_DT}'
            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
            SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        
        
            select A.*,REPLACE(REPLACE(B.CO_NM, '신한비엔피파리바자산운용', '신한자산운용'),'메리츠자산운용','KCGI자산운용') CO_NM,B.ETF_AST_BIG from (select
            	A.GIJUN_YMD TRD_DT, B.ETF_CD,B.ETF_NM,A.CSFW_AMT,A.ACM_CSFW_AMT 
            from
            	FDTFN210 A,
            	(SELECT
            		A.FUND_CD,
            		A.ETF_CD,
            		B.ETF_NM
            	FROM
            		(
            		SELECT
            			FUND_CD,
            			'A' + SUBSTRING(KSD_ITEM_CD, 4, 6) ETF_CD
            		fROM
            			QUANT1.DBO.FDTFM001 A) A,
            		FN_ETFINFO B
            	WHERE
            		A.ETF_cD = B.ETF_CD AND B.TR_YMD=(
            	SELECT
            		MAX(TR_YMD)
            	FROM
            		FN_ETFINFO
            	WHERE
            		TR_YMD <= GETDATE())) B
            WHERE
            	A.FUND_CD = B.FUND_CD
            	--AND A.GIJUN_YMD >= '20230920' AND A.GIJUN_YMD=B.TR_yMD 
            	) A, (SELECT
            	B.ETF_CD,
            	CASE WHEN A.ETF_AST_BIG NOT IN ('주식','채권') THEN '기타' ELSE A.ETF_AST_BIG END ETF_AST_BIG,
            	B.ETF_NM,
            	B.CO_NM
            fROM
            	ES_SECTOR_MASTER A ,
            	FN_ETFINFO B
            WHERE
            	A.STK_CD = B.ETF_CD
            	AND B.TR_YMD =(
            	SELECT
            		MAX(TR_YMD)
            	FROM
            		FN_ETFINFO
            	WHERE
            		TR_YMD <= GETDATE())) B WHERE (A.ETF_CD=B.ETF_CD) and TRD_DT =@TRD_DT_PDAY
        """
        	
        query1 = query1.replace('#{Start_DT}', self.start_dt)	
        df_ov1=pd.read_sql(query1,conn)
        df_ov1=df_ov1.fillna("")        #전일
        
        # 전일 AUM에 넣을 값
        query2 = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8)
        
            SET ANSI_WARNINGS OFF
            SET @TRD_DT_MAG ='#{Start_DT}'
            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
            SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        
        
            select A.*,REPLACE(REPLACE(B.CO_NM, '신한비엔피파리바자산운용', '신한자산운용'),'메리츠자산운용','KCGI자산운용') CO_NM,B.ETF_AST_BIG from (select
            	A.GIJUN_YMD TRD_DT, B.ETF_CD,B.ETF_NM,A.CSFW_AMT,A.ACM_CSFW_AMT 
            from
            	FDTFN210 A,
            	(SELECT
            		A.FUND_CD,
            		A.ETF_CD,
            		B.ETF_NM
            	FROM
            		(
            		SELECT
            			FUND_CD,
            			'A' + SUBSTRING(KSD_ITEM_CD, 4, 6) ETF_CD
            		fROM
            			QUANT1.DBO.FDTFM001 A) A,
            		FN_ETFINFO B
            	WHERE
            		A.ETF_cD = B.ETF_CD AND B.TR_YMD=(
            	SELECT
            		MAX(TR_YMD)
            	FROM
            		FN_ETFINFO
            	WHERE
            		TR_YMD <= GETDATE())) B
            WHERE
            	A.FUND_CD = B.FUND_CD
            	--AND A.GIJUN_YMD >= '20230920' AND A.GIJUN_YMD=B.TR_yMD 
            	) A, (SELECT
            	B.ETF_CD,
            	CASE WHEN A.ETF_AST_BIG NOT IN ('주식','채권') THEN '기타' ELSE A.ETF_AST_BIG END ETF_AST_BIG,
            	B.ETF_NM,
            	B.CO_NM
            fROM
            	ES_SECTOR_MASTER A ,
            	FN_ETFINFO B
            WHERE
            	A.STK_CD = B.ETF_CD
            	AND B.TR_YMD =(
            	SELECT
            		MAX(TR_YMD)
            	FROM
            		FN_ETFINFO
            	WHERE
            		TR_YMD <= GETDATE())) B WHERE (A.ETF_CD=B.ETF_CD) and TRD_DT =@TRD_DT
        """
        	
        query2 = query2.replace('#{Start_DT}', self.start_dt)	
        df_ov2=pd.read_sql(query2,conn)
        df_ov2=df_ov2.fillna("")        #금일

        df = pd.DataFrame()
        df['기초설정액(억)'] = round(df_ov1.groupby("ETF_AST_BIG")['ACM_CSFW_AMT'].sum()/100000000,2)
        df['기말설정액(억)'] = round(df_ov2.groupby("ETF_AST_BIG")['ACM_CSFW_AMT'].sum()/100000000,2)
        df['Δ설정액(억)'] = df['기말설정액(억)']-df['기초설정액(억)'].fillna(0)
        df=df.sort_values(by=['ETF_AST_BIG'],axis=0,ascending=False).reset_index()
        
        # print(df)
        
        return df
    
    def df_csfw_ace(self): 
                      
        # 금일 AUM에 넣을 값
        query1 = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8)
        
            SET ANSI_WARNINGS OFF
            SET @TRD_DT_MAG ='#{Start_DT}'
            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
            SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        
        
            select A.*,REPLACE(REPLACE(B.CO_NM, '신한비엔피파리바자산운용', '신한자산운용'),'메리츠자산운용','KCGI자산운용') CO_NM,B.ETF_AST_BIG from (select
            	A.GIJUN_YMD TRD_DT, B.ETF_CD,B.ETF_NM,A.CSFW_AMT,A.ACM_CSFW_AMT 
            from
            	FDTFN210 A,
            	(SELECT
            		A.FUND_CD,
            		A.ETF_CD,
            		B.ETF_NM
            	FROM
            		(
            		SELECT
            			FUND_CD,
            			'A' + SUBSTRING(KSD_ITEM_CD, 4, 6) ETF_CD
            		fROM
            			QUANT1.DBO.FDTFM001 A) A,
            		FN_ETFINFO B
            	WHERE
            		A.ETF_cD = B.ETF_CD AND B.TR_YMD=(
            	SELECT
            		MAX(TR_YMD)
            	FROM
            		FN_ETFINFO
            	WHERE
            		TR_YMD <= GETDATE())) B
            WHERE
            	A.FUND_CD = B.FUND_CD
            	--AND A.GIJUN_YMD >= '20230920' AND A.GIJUN_YMD=B.TR_yMD 
            	) A, (SELECT
            	B.ETF_CD,
            	CASE WHEN A.ETF_AST_BIG NOT IN ('주식','채권') THEN '기타' ELSE A.ETF_AST_BIG END ETF_AST_BIG,
            	B.ETF_NM,
            	B.CO_NM
            fROM
            	ES_SECTOR_MASTER A ,
            	FN_ETFINFO B
            WHERE
            	A.STK_CD = B.ETF_CD
            	AND B.TR_YMD =(
            	SELECT
            		MAX(TR_YMD)
            	FROM
            		FN_ETFINFO
            	WHERE
            		TR_YMD <= GETDATE())) B WHERE (A.ETF_CD=B.ETF_CD) and TRD_DT =@TRD_DT_PDAY and B.ETF_NM like 'ACE%'
        """
        	
        query1 = query1.replace('#{Start_DT}', self.start_dt)	
        df_ov1=pd.read_sql(query1,conn)
        df_ov1=df_ov1.fillna("")        #전일
        
        # 전일 AUM에 넣을 값
        query2 = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
        		@TRD_DT VARCHAR(8),
           		@TRD_DT_PDAY VARCHAR(8)
        
            SET ANSI_WARNINGS OFF
            SET @TRD_DT_MAG ='#{Start_DT}'
            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
            SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        
        
            select A.*,REPLACE(REPLACE(B.CO_NM, '신한비엔피파리바자산운용', '신한자산운용'),'메리츠자산운용','KCGI자산운용') CO_NM,B.ETF_AST_BIG from (select
            	A.GIJUN_YMD TRD_DT, B.ETF_CD,B.ETF_NM,A.CSFW_AMT,A.ACM_CSFW_AMT 
            from
            	FDTFN210 A,
            	(SELECT
            		A.FUND_CD,
            		A.ETF_CD,
            		B.ETF_NM
            	FROM
            		(
            		SELECT
            			FUND_CD,
            			'A' + SUBSTRING(KSD_ITEM_CD, 4, 6) ETF_CD
            		fROM
            			QUANT1.DBO.FDTFM001 A) A,
            		FN_ETFINFO B
            	WHERE
            		A.ETF_cD = B.ETF_CD AND B.TR_YMD=(
            	SELECT
            		MAX(TR_YMD)
            	FROM
            		FN_ETFINFO
            	WHERE
            		TR_YMD <= GETDATE())) B
            WHERE
            	A.FUND_CD = B.FUND_CD
            	--AND A.GIJUN_YMD >= '20230920' AND A.GIJUN_YMD=B.TR_yMD 
            	) A, (SELECT
            	B.ETF_CD,
            	CASE WHEN A.ETF_AST_BIG NOT IN ('주식','채권') THEN '기타' ELSE A.ETF_AST_BIG END ETF_AST_BIG,
            	B.ETF_NM,
            	B.CO_NM
            fROM
            	ES_SECTOR_MASTER A ,
            	FN_ETFINFO B
            WHERE
            	A.STK_CD = B.ETF_CD
            	AND B.TR_YMD =(
            	SELECT
            		MAX(TR_YMD)
            	FROM
            		FN_ETFINFO
            	WHERE
            		TR_YMD <= GETDATE())) B WHERE (A.ETF_CD=B.ETF_CD) and TRD_DT =@TRD_DT and B.ETF_NM like 'ACE%'
        """
        	
        query2 = query2.replace('#{Start_DT}', self.start_dt)	
        df_ov2=pd.read_sql(query2,conn)
        df_ov2=df_ov2.fillna("")        #금일

        df = pd.DataFrame()
        df['기초설정액(억)'] = round(df_ov1.groupby("ETF_AST_BIG")['ACM_CSFW_AMT'].sum()/100000000,2)
        df['기말설정액(억)'] = round(df_ov2.groupby("ETF_AST_BIG")['ACM_CSFW_AMT'].sum()/100000000,2)
        df['Δ설정액(억)'] = df['기말설정액(억)']-df['기초설정액(억)'].fillna(0)
        df=df.sort_values(by=['ETF_AST_BIG'],axis=0,ascending=False).reset_index()
        
        # print(df)
        
        return df
    
    
    def df_yield(self): 
                      
        query = """
            DECLARE @TRD_DT_MAG VARCHAR(8),
            		@TRD_DT VARCHAR(8),
               		@TRD_DT_PDAY VARCHAR(8),
            		@TRD_DT_PWEEK VARCHAR(8),
            		@TRD_DT_PMON1 VARCHAR(8),
            		@TRD_DT_PMON3 VARCHAR(8),
            		@TRD_DT_PMON6 VARCHAR(8),
            		@TRD_DT_PYEAR VARCHAR(8),
            		@TRD_DT_MTD VARCHAR(8),
            		@TRD_DT_YTD VARCHAR(8),
                    @TRD_DT_PLAST VARCHAR(8)
        
        SET ANSI_WARNINGS OFF
        SET @TRD_DT_MAG ='#{Start_DT}'
        SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)																				-- 직전 영업일
        SET @TRD_DT_PDAY =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        SET @TRD_DT_PWEEK =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(WEEK,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))  	-- 1주일
        SET @TRD_DT_PMON1 =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112))) 	-- 1달
        SET @TRD_DT_PMON3 =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-3, CONVERT(VARCHAR(8), @TRD_DT, 112)),112))) 	-- 3달
        SET @TRD_DT_PMON6 =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(MONTH,-6, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_PYEAR =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT<=(SELECT CONVERT(VARCHAR(8),DATEADD(YEAR,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))
        SET @TRD_DT_MTD =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT LIKE (SELECT CONCAT(SUBSTRING(CONVERT(VARCHAR(8),DATEADD(MONTH,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112),1,6),'%'))) --전월말
        SET @TRD_DT_YTD =(select max(trd_dt) from ES_FUND_PRC_V WHERE FUND_CD='9000A' AND TRD_DT LIKE (SELECT CONCAT(SUBSTRING(CONVERT(VARCHAR(8),DATEADD(YEAR,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112),1,4),'12%'))); --전년말
        
        SELECT AA.FUND_CD, 
        	AB.STD_PRC STD_PRC_TD, 
        	AC.STD_PRC STD_PRC_PDAY, 
        	BB.STD_PRC STD_PRC_PWEEK, 
        	CC.STD_PRC STD_PRC_PMON1,
        	DD.STD_PRC STD_PRC_PMON3,
        	EE.STD_PRC STD_PRC_PMON6,
        	FF.STD_PRC STD_PRC_PYEAR,
        	GG.STD_PRC STD_PRC_MTD,
        	HH.STD_PRC STD_PRC_YTD,
        	AA.typ TYP
        from (select TRD_DT, FUND_CD, typ, SET_DT, FUND_NM from ES_MAG_STATUS_N where TRD_DT = @TRD_DT_MAG ) AA
        LEFT OUTER JOIN (SELECT FUND_CD, FUND_NM FROM ES_FUND_MAP) M ON AA.FUND_CD = M.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V  where TRD_DT = @TRD_DT) AB on AA.FUND_CD = AB.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V where TRD_DT = @TRD_DT_PDAY) AC on AA.FUND_CD = AC.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V where TRD_DT = @TRD_DT_PWEEK) BB on AA.FUND_CD = BB.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V where TRD_DT = @TRD_DT_PMON1) CC on AA.FUND_CD = CC.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V where TRD_DT = @TRD_DT_PMON3) DD on AA.FUND_CD = DD.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V where TRD_DT = @TRD_DT_PMON6) EE on AA.FUND_CD = EE.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V where TRD_DT = @TRD_DT_PYEAR) FF on AA.FUND_CD = FF.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V where TRD_DT = @TRD_DT_MTD) GG on AA.FUND_CD = GG.FUND_CD
        left outer join (select FUND_CD, STD_PRC from ES_FUND_PRC_V where TRD_DT = @TRD_DT_YTD) HH on AA.FUND_CD = HH.FUND_CD
        where AA.FUND_CD != '9003H' and AA.FUND_CD != '9002N'
        GROUP BY AA.FUND_CD, M.FUND_NM, AA.typ, AA.SET_DT, AB.STD_PRC, AC.STD_PRC, BB.STD_PRC, CC.STD_PRC, DD.STD_PRC, EE.STD_PRC, FF.STD_PRC, GG.STD_PRC, HH.STD_PRC
		ORDER BY AA.typ ASC, M.FUND_NM ASC;
        """
        # and FUND_CD != '9004S' and FUND_CD != '9004R' and FUND_CD != '9004Q'
        	
        query = query.replace('#{Start_DT}', self.start_dt)	
        df=pd.read_sql(query,conn)
        df=df.fillna("")
        # print(df.head)
        
        return df
    
    
    
    def NAV(self):
        
        naav = """
        DECLARE @TRD_DT VARCHAR(8),
                @TRD_DT_PDAY VARCHAR(8),
                @TRD_DT_WDAY VARCHAR(8)
                SET @TRD_DT ='#{Start_DT}'
                SET @TRD_DT_WDAY =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<@TRD_DT)
                SET @TRD_DT_PDAY =(select max(trd_dt) from ES_MAG_STATUS_N WHERE FUND_CD='9000A' AND TRD_DT<@TRD_DT_WDAY)    -- 직전 영업일
        SELECT DISTINCT TRD_DT, TYP,SUM(NAV/POWER(10,6)) OVER (PARTITION BY TYP) VAL,'NAV' NM 
        	FROM ES_MAG_STATUS_N WHERE TRD_DT=@TRD_DT
        	UNION
        SELECT DISTINCT TRD_DT,TYP,SUM(NAV/POWER(10,6)) OVER (PARTITION BY TYP) VAL,'NAV' NM 
        	FROM ES_MAG_STATUS_N WHERE TRD_DT=@TRD_DT_PDAY
                UNION 
        SELECT DISTINCT TRD_DT,TYP,SUM(SET_AMT/POWER(10,6)) OVER (PARTITION BY TYP) VAL, 'SET_AMT' NM FROM ES_MAG_STATUS_N WHERE TRD_DT=@TRD_DT
                UNION 
        SELECT DISTINCT TRD_DT,TYP,SUM(SET_AMT/POWER(10,6)) OVER (PARTITION BY TYP) VAL, 'SET_AMT' NM FROM ES_MAG_STATUS_N WHERE TRD_DT=@TRD_DT_PDAY
                ORDER BY TRD_DT,TYP,NM	
        """
        
        naav = naav.replace('#{Start_DT}', self.start_dt)
        df_nav=pd.read_sql(naav,conn)
                            
        return df_nav
    
    #2022년상장된 ETF NAV 수정
    def NAV2(self):
        
        naav = """
        select SUM(NAV/POWER(10,6)) VAL FROM ES_MAG_STATUS_N 
        WHERE TRD_DT='#{Start_DT}' AND TYP='ETF' AND SET_DT>=SUBSTRING('20220101',1,4)"""
        
        naav = naav.replace('#{Start_DT}', self.start_dt)
        df_nav=pd.read_sql(naav,conn)
                            
        return df_nav
    
    def CA_kor(self):
        
        ca = """
        select STK_NM,CONVERT(VARCHAR(10),CONVERT(datetime,START_DT,1),120) START_DT,COMMENT,CASE WHEN STOP_START_DT='' THEN '' ELSE CONVERT(VARCHAR(10),CONVERT(datetime,STOP_START_DT,1),120) END STOP_START_DT,
        CASE WHEN STOP_END_DT='' THEN '' ELSE CONVERT(VARCHAR(10),CONVERT(datetime,STOP_END_DT,1),120) END STOP_END_DT from ES_DISCLOS_KOR WHERE isnull(START_DT,'99991231')>='#{Start_DT}'

          """
        
        ca = ca.replace('#{Start_DT}', self.start_dt)
        df_ca=pd.read_sql(ca,conn)
        df_ca=df_ca.fillna("")
                            
        return df_ca

    def CA_gbl(self):
        
        ca = """
        select * from ES_DISCLOS_GLOBAL WHERE START_DT>='#{Start_DT}' order by case when start_dt ='' then '99991231' else start_dt end"""
        
        ca = ca.replace('#{Start_DT}', self.start_dt)
        df_ca=pd.read_sql(ca,conn)
        df_ca=df_ca.fillna("")
                            
        return df_ca


    def df_fee(self):
    
        query = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
                @TRD_DT VARCHAR(8)
                SET @TRD_DT_MAG ='#{Start_DT}' --영업일 전일 (input값)
                SET @TRD_DT = (select max(TR_YMD) from FN_ETFINFO WHERE ETF_CD='A105190' AND TR_YMD<=@TRD_DT_MAG)    -- 최근영업일
        SELECT AA.FUND_CD [Code], M.FUND_NM [펀드명], AA.MANAGER [운용역], AA.SET_DT [설정일], AA.STL_DT [결산일], BB.TOT_FEE_RATE [총보수], BB.AMC_RATE [운용보수], BB.DISTB_RATE [판매보수], BB.CUSTODY_NM [수탁사], BB.CUSTODY_RATE [수탁보수], BB.ADMIN_NM [사무사], BB.ADMIN_RATE [사무보수], AA.NAV
                FROM (SELECT TRD_DT, FUND_CD, MANAGER, CONVERT(VARCHAR(10),CONVERT(datetime,SET_DT,1),120) SET_DT, CONVERT(VARCHAR(10),CONVERT(datetime,STL_DT,1),120) STL_DT, NAV from ES_MAG_STATUS_N where TRD_DT = @TRD_DT_MAG and TYP = 'ETF') AA
                LEFT OUTER JOIN (SELECT FUND_CD, FUND_NM FROM ES_FUND_MAP) M ON AA.FUND_CD = M.FUND_CD
                LEFT OUTER JOIN (SELECT FUND_ID, TOT_FEE_RATE, AMC_RATE, DISTB_RATE, ADMIN_NM, ADMIN_RATE, CUSTODY_NM, CUSTODY_RATE FROM BZ000101 where PR_DATE = @TRD_DT) BB on AA.FUND_CD = BB.FUND_ID
                where AA.FUND_CD != '9003H' and AA.FUND_CD != '9002N'
        ORDER BY M.FUND_NM ASC
        """
        #  and FUND_CD != '9004Q' and FUND_CD != '9004R' and FUND_CD != '9003H'
        
        query = query.replace('#{Start_DT}', self.start_dt)
        df_fee=pd.read_sql(query,conn)
        
        non_li = ['9003R', '9003B', '9003H', '9003I', '9003S', '9002H', '9003T', '9003U', '9002N', '9002W', '9003W', '9003D', '9003X', '9002T', '9002V', '9003F', '9003E', '9002U', '9002Y', '9001D', '9003G', '9002G', '9002Q', '9001X']
        
        # 운용보수, 판매보수, 수탁사, 수탁보수, 사무사, 사무보수, 총보수
        non_dict = {'9003R': [3.5, 0.5, '한국씨티은행', 0.5, '신한펀드파트너스', 0.5, 5] , '9003B': [3, 0.5, '한국씨티은행', 1, '신한펀드파트너스', 0.5, 5], 
                    '9003H': [3.5, 0.5, '한국씨티은행', 0.5, '신한펀드파트너스', 0.5, 5], '9003I': [3.5, 0.5, '한국씨티은행', 0.5, '신한펀드파트너스', 0.5, 5], 
                    '9003S': [3.5, 0.5, '한국씨티은행', 0.5, '신한펀드파트너스', 0.5, 5], '9002H': [26, 1, '신한은행', 1, '신한펀드파트너스', 1, 29], 
                    '9003T': [3.5, 0.5, '한국씨티은행', 0.5, '신한펀드파트너스', 0.5, 5], '9003U': [3.5, 0.5, '한국씨티은행', 0.5, '신한펀드파트너스', 0.5, 5], 
                    '9002N': [44, 2, '한국씨티은행', 2, '신한펀드파트너스', 2, 50], '9002W': [12, 1, '하나은행', 1, '신한펀드파트너스', 1, 15], 
                    '9003W': [3.5, 0.5, '홍콩상하이은행 (HSBC은행)', 0.5, '한국펀드파트너스', 0.5, 5], '9003D': [3.5, 0.5, '홍콩상하이은행 (HSBC은행)', 0.5, '한국펀드파트너스', 0.5, 5], 
                    '9003X': [13.5, 0.5, '홍콩상하이은행 (HSBC은행)', 0.5, '한국펀드파트너스', 0.5, 15], '9002T': [12, 1, '홍콩상하이은행 (HSBC은행)', 1, '한국펀드파트너스', 1, 15],
                    '9002V': [25, 2, '홍콩상하이은행 (HSBC은행)', 1, '한국펀드파트너스', 2, 30], '9003F': [3.5, 0.5, '홍콩상하이은행 (HSBC은행)', 0.5, '신한펀드파트너스', 0.5, 5],
                    '9003E': [21, 1, '홍콩상하이은행 (HSBC은행)', 1, '한국펀드파트너스', 1, 24], '9002U': [12, 1, '홍콩상하이은행 (HSBC은행)', 1, '한국펀드파트너스', 1, 15], 
                    '9002Y': [65, 2, '하나은행', 1.5, '신한펀드파트너스', 1.5, 70], '9001D': [5, 1, '하나은행', 1, '신한펀드파트너스', 1, 8], 
                    '9003G': [26, 1, '홍콩상하이은행 (HSBC은행)', 1, '한국펀드파트너스', 1, 29], '9002G': [46, 1, '신한은행', 2, '신한펀드파트너스', 1, 50], 
                    '9002Q': [23, 2, '한국씨티은행', 2, '신한펀드파트너스', 2, 29] , '9001X':[0.9, 0.1, '하나은행', 0.5, '신한펀드파트너스', 0.5, 2],
                    '9004D': [42, 1, '홍콩상하이은행 (HSBC은행)', 1, '신한펀드파트너스', 1, 45], '9004C': [42, 1, '홍콩상하이은행 (HSBC은행)', 1, '신한펀드파트너스', 1, 45],
                    '9004B': [42, 1, '홍콩상하이은행 (HSBC은행)', 1, '신한펀드파트너스', 1, 45], '9004E': [42, 1, '홍콩상하이은행 (HSBC은행)', 1, '신한펀드파트너스', 1, 45],
                    '9004H': [4, 0.2, '신한은행', 0.5, '신한펀드파트너스', 0.3, 5]
                    }
        
        for i in range(len(df_fee)):
            if df_fee['수탁사'][i] is None:
                code = df_fee['Code'][i]
                # print(code)
                df_fee.loc[i, '운용보수'] = non_dict[code][0]/10
                df_fee.loc[i, '판매보수'] = non_dict[code][1]/10
                df_fee.loc[i, '수탁사'] = non_dict[code][2]
                df_fee.loc[i, '수탁보수'] = non_dict[code][3]/10
                df_fee.loc[i, '사무사'] = non_dict[code][4]
                df_fee.loc[i, '사무보수'] = non_dict[code][5]/10
                df_fee.loc[i, '총보수'] = non_dict[code][6]/10
                
        
        df_fee['사무사'] = df_fee['사무사'].str.replace("펀드파트너스", "")
        # print(df_fee['사무사'])
                            
        return df_fee

    def df_AP(self):
        
        # df5.rename(columns={'기준년월':'TRD_DT', 'AP명':'LP', '자기분평잔': 'AP_CNT', 'ETF종목코드': 'ISIN_CD'}, inplace=True)
        
        # 전영업일 AP잔고 구하는 함수
        query = """
                    DECLARE @TRD_DT_MAG VARCHAR(8),
            				@TRD_DT VARCHAR(8),
                            @TRD_DT_KFP VARCHAR(8),
                            @TRD_DT_AITAS VARCHAR(8)
                            SET @TRD_DT_MAG ='#{Start_DT}' --영업일 전일 (input값)
                            SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)
                            SET @TRD_DT_KFP = (select max(STD_DT) from ETF_APAUM WHERE GUBN='K' and STD_DT<=@TRD_DT_MAG)    -- 최근영업일
                            SET @TRD_DT_AITAS = (select max(STD_DT) from ETF_APAUM WHERE GUBN='A' and STD_DT<=@TRD_DT_MAG)
                    SELECT BB.FUND_CD,
                    		AA.LP, 
                    		AA.AP_CNT,
                    		CC.STD_PRC,
                    		AA.AP_CNT * CC.STD_PRC as [잔고]
                            FROM ((SELECT STD_DT, KSD_FUND_CD as [ISIN_CD], AP_NM as [LP], HOLD_QTY as [AP_CNT] from ETF_APAUM where GUBN='K' and STD_DT=@TRD_DT_KFP) UNION ALL (SELECT STD_DT, ETF_CD as [ISIN_CD], AP_NM as [LP], HOLD_AMT as [AP_CNT] from ETF_APAUM where GUBN='A' and STD_DT=@TRD_DT_AITAS)) AA
                            LEFT OUTER JOIN (SELECT FUND_CD, ISIN_CD, FUND_NM from ES_FUND_MAP where FUND_NM like '%ACE%') BB on AA.ISIN_CD = BB.ISIN_CD
                    		LEFT OUTER JOIN (SELECT FUND_CD, STD_PRC from ES_FUND_PRC_RAW where TRD_DT = @TRD_DT) CC on BB.FUND_CD = CC.FUND_CD 
                            where BB.FUND_CD != '9001L' and BB.FUND_CD != '9003B' and BB.FUND_CD != '9003H' and BB.FUND_CD != '9002N'
                    ORDER BY BB.FUND_NM ASC
                """
                #  and BB.FUND_CD != '9004Q' and BB.FUND_CD != '9004R' and BB.FUND_CD != '9004S'
        
        # 상폐 있을 때 위 조건문 참조
        query = query.replace('#{Start_DT}', self.start_dt)
        
        df_AP=pd.read_sql(query,conn)
        
        df_AP.loc[:,'LP'] = df_AP['LP'].replace('iM증권', 'IM증권')


        # print(df_AP)
        return df_AP

    def df_AP_PDAY(self):
        
        # 전일대비 AP잔고와의 비교를 위해 구하는 함
        query = """
                DECLARE @TRD_DT_MAG VARCHAR(8),
        				@TRD_DT VARCHAR(8),
                        @TRD_DT_KFP VARCHAR(8),
                        @TRD_DT_AITAS VARCHAR(8),
                        @TRD_DT_PDAY_K VARCHAR(8),
                        @TRD_DT_PDAY_A VARCHAR(8),
                        @TRD_DT_PRC VARCHAR(8)
                        SET @TRD_DT_MAG ='#{Start_DT}' --영업일 전일 (input값)
                        SET @TRD_DT =(select max(trd_dt) from ES_FUND_PRC WHERE FUND_CD='asiatop50' AND TRD_DT<=@TRD_DT_MAG)
                        SET @TRD_DT_KFP = (select max(STD_DT) from ETF_APAUM WHERE GUBN='K' and STD_DT<=@TRD_DT_MAG)    -- 최근영업일
                		SET @TRD_DT_AITAS = (select max(STD_DT) from ETF_APAUM WHERE GUBN='A' and STD_DT<=@TRD_DT_MAG)
                        SET @TRD_DT_PDAY_K = (select max(STD_DT) from ETF_APAUM WHERE GUBN='K' and STD_DT<@TRD_DT_KFP)    -- 최근영업일 - 1
                        SET @TRD_DT_PDAY_A = (select max(STD_DT) from ETF_APAUM WHERE GUBN='A' and STD_DT<@TRD_DT_AITAS)    -- 최근영업일 - 1
                        SET @TRD_DT_PRC = (select max(TRD_DT) from ES_FUND_PRC WHERE TRD_DT<@TRD_DT)
                SELECT BB.FUND_CD, 
                		AA.LP, 
                		AA.AP_CNT,
                		CC.STD_PRC,
                		AA.AP_CNT * CC.STD_PRC as [잔고]
                        FROM ((SELECT STD_DT, KSD_FUND_CD as [ISIN_CD], AP_NM as [LP], HOLD_QTY as [AP_CNT] from ETF_APAUM where GUBN='K' and STD_DT=@TRD_DT_PDAY_K) UNION ALL (SELECT STD_DT, ETF_CD as [ISIN_CD], AP_NM as [LP], HOLD_AMT as [AP_CNT] from ETF_APAUM where GUBN='A' and STD_DT=@TRD_DT_PDAY_A)) AA
                        LEFT OUTER JOIN (SELECT FUND_CD, ISIN_CD, FUND_NM from ES_FUND_MAP where FUND_NM like '%ACE%') BB on AA.ISIN_CD = BB.ISIN_CD
                		LEFT OUTER JOIN (SELECT FUND_CD, STD_PRC from ES_FUND_PRC_RAW where TRD_DT = @TRD_DT_PRC) CC on BB.FUND_CD = CC.FUND_CD 
                        where BB.FUND_CD != '9001L' and BB.FUND_CD != '9001K' and BB.FUND_CD != '9001F' and BB.FUND_CD != '9003H' and BB.FUND_CD != '9002N'
                ORDER BY BB.FUND_NM ASC
        """
        #  and BB.FUND_CD != '9004Q' and BB.FUND_CD != '9004R' and BB.FUND_CD != '9004S'
        
        query = query.replace('#{Start_DT}', self.start_dt)
        df_AP_PDAY=pd.read_sql(query,conn)
        
        df_AP_PDAY.loc[:,'LP'] = df_AP_PDAY['LP'].replace('iM증권', 'IM증권')

        # print(df_AP_PDAY)
        return df_AP_PDAY
    

    def df_p_amt(self):
        
        query = """
        DECLARE @TRD_DT_MAG VARCHAR(8),
                @TRD_DT VARCHAR(8),
                @TRD_DT_PDAY VARCHAR(8)
                SET @TRD_DT_MAG ='#{Start_DT}' --영업일 전일 (input값)
                SET @TRD_DT = (select max(TR_YMD) from FN_ETFINFO WHERE ETF_CD='A105190' AND TR_YMD<=@TRD_DT_MAG)    -- 최근영업일
                SET @TRD_DT_PDAY =(select max(TR_YMD) from FN_ETFINFO WHERE ETF_CD='A105190' AND TR_YMD<=(SELECT CONVERT(VARCHAR(8),DATEADD(DAY,-1, CONVERT(VARCHAR(8), @TRD_DT, 112)),112)))		-- 1일 전
        SELECT AA.FUND_CD [Code], BB.FUND_NM [펀드명], BB.STK_CD, CC.SUM_QTY, DD.STD_PRC, CC.SUM_QTY*DD.STD_PRC [개인잔고], EE.SUM_QTY_PDAY, FF.STD_PRC_PDAY, EE.SUM_QTY_PDAY*FF.STD_PRC_PDAY [개인잔고_PDAY]  
                FROM (SELECT TRD_DT, FUND_CD from ES_MAG_STATUS_N where TRD_DT = @TRD_DT_MAG and TYP = 'ETF' and FUND_CD != '9001L' and FUND_CD != '9001K' and FUND_CD != '9003H' and FUND_CD != '9002N') AA
                LEFT OUTER JOIN (SELECT FUND_CD, FUND_NM, STK_CD from ES_FUND_MAP where FUND_NM like '%ACE%') BB on AA.FUND_CD = BB.FUND_CD
                LEFT OUTER JOIN (SELECT ETF_CD, sum(NET_QTY) [SUM_QTY] from FN_ETFINV where INVEST_GB = 8 group by ETF_CD) CC on BB.STK_CD = CC.ETF_CD
                LEFT OUTER JOIN (SELECT ETF_CD, sum(NET_QTY) [SUM_QTY_PDAY] from FN_ETFINV where INVEST_GB = 8 and TR_YMD < @TRD_DT group by ETF_CD) EE on BB.STK_CD = EE.ETF_CD
                LEFT OUTER JOIN (SELECT FUND_CD, STD_PRC from ES_FUND_PRC_RAW where TRD_DT = @TRD_DT) DD on AA.FUND_CD = DD.FUND_CD
                LEFT OUTER JOIN (SELECT FUND_CD, STD_PRC [STD_PRC_PDAY] from ES_FUND_PRC_RAW where TRD_DT = @TRD_DT_PDAY) FF on AA.FUND_CD = FF.FUND_CD
        ORDER BY BB.FUND_NM ASC
        """
        # and FUND_CD != '9004Q' and FUND_CD != '9004R' and FUND_CD != '9004S'
        query = query.replace('#{Start_DT}', self.start_dt)
        df=pd.read_sql(query,conn)
        
        return df
    
    def df_lp_sum(self):
        
        #AITAS 11408 배분율 조회
        df1 = pd.read_excel(f'//Etf_통계용_pc/ETF/JaeHee/데이터(기타자료)/AITAS_LP배분율.xlsx',engine='openpyxl') 
            
        # 2) 한국펀드파트너스 2554 분배내역 - 유동성기여보수 
        df2 = pd.read_excel(f'//Etf_통계용_pc/ETF/JaeHee/데이터(기타자료)/KFP_LP배분율.xlsx',engine='openpyxl') 
        df2 = df2.iloc[:-1]

        df1_ = df1[['펀드명', 'AP명', '배분보수금액']]
        df1_.loc[:,'AP명'] = df1_['AP명'].replace('메리츠종금증권', '메리츠증권')
        df1_.loc[:,'AP명'] = df1_['AP명'].replace('현대차투자증권(구.HMC)', '현대차증권')
        df1_.loc[:,'AP명'] = df1_['AP명'].replace('DB금융투자(구.동부)', 'DB금융투자')
        df1_.loc[:,'AP명'] = df1_['AP명'].replace('이베스트증권', 'LS증권')
        df1_.loc[:,'AP명'] = df1_['AP명'].replace('iM증권', 'IM증권')

        df2_ = df2[['펀드명', '판매사명', '유동성기여보수']]
        df2_ = df2_.rename(columns={'판매사명': 'AP명', '유동성기여보수': '배분보수금액'})


        df = pd.concat([df1_,df2_], ignore_index=True)

        df_sum = df.groupby('AP명')['배분보수금액'].sum().reset_index()
        df_sum.columns = ['AP명', '보수합']
        df_sum.loc[:,'AP명'] = df_sum['AP명'].replace('유진증권', '유진투자증권')
        df_sum['보수합'] = df_sum['보수합']
        
        return df_sum


## 계산된 데이터를 바탕으로 데이터 Write 수행.
class status_generation():

    
    # 엑셀 생성 메인 파트
    def __init__(self, start_dt):     
        global path
        
        self.start_dt =start_dt
        self.set_file_path()
        self.set_format()

        #데이터 호출
        self.df = generate_data(start_dt)
        #self.set_profile()

        #시트 작성
        self.Manage_info()       #운용현황 시트 생성


        self.workbook.close()
        print('\n\n' + ' Jobs Done '.center(50, '-'))
        path=self.file_name
        
        # os.startfile(self.file_name)

    #File Path 설정, 기초 Workbook 객체 생성(self.workbook)
    def set_file_path(self):
        if global_file_path != None:
            self.file_path = 'D:'
        else:
            self.file_path = global_file_path

        if not os.path.exists(self.file_path):
            self.file_path = ''
        self.file_name = '운용현황' + '_' + str(date.today()).replace("-", "")+ '.xlsx'

        num = 0
        while os.path.isfile(self.file_name):
            num += 1
            self.file_name = '운용현황'   + '_' + str(date.today()).replace("-", "")+ '(TEST)_' + str(num) + '.xlsx'
        self.workbook = xlsxwriter.Workbook(self.file_name, {'nan_inf_to_errors': True})

    #Format/Style 정의(for self.workbook) 
    def set_format(self):
        self.bold_bottomline = self.workbook.add_format({'bold': True, 'bottom': 6, 'align': 'center', 'font_size': 10})
        self.bold_bottomline2 = self.workbook.add_format({'bold': True, 'bottom': 6, 'font_size': 10})
        self.bold = self.workbook.add_format({'bold': True, 'font_size': 18})
        self.bold2 = self.workbook.add_format({'bold': True, 'font_size': 14,'align': 'center','valign':'vcenter','right':7,'top': 7})
        self.bold7 = self.workbook.add_format({'bold': True, 'font_size': 14,'align': 'center','valign':'vcenter'})
        self.bold3 = self.workbook.add_format({'bold': True, 'font_size': 16,'align': 'center','valign':'vcenter'})
        self.bold4 = self.workbook.add_format({'bold': True,'top': 2, 'font_size': 16,'align': 'center','valign':'vcenter'})
        self.bold5 = self.workbook.add_format({'bold': True, 'font_size': 14,'align': 'left'})
        self.bold6 = self.workbook.add_format({'bold': True, 'font_size': 18,'align': 'right'})
        self.bold8 = self.workbook.add_format({'bold': True,'bottom': 2, 'font_size': 16,'align': 'center','valign':'vcenter'})
        self.bold_upline = self.workbook.add_format({'bold': True,'top': 2,'bottom': 2,'left': 7,'right': 7, 'font_size': 14,'align': 'center','valign':'vcenter'})
        self.bold_upline2 = self.workbook.add_format({'bold': True,'top': 2,'bottom': 7,'left': 2,'right': 2, 'font_size': 14,'align': 'center','valign':'vcenter'})
        self.bold_upline3 = self.workbook.add_format({'bold': True,'top': 2, 'font_size': 14,'align': 'center','valign':'vcenter'})
        #self.bold_upline = self.workbook.add_format({'bold': True, 'top': 6, 'align': 'center', 'num_format': '0.00%', 'font_size': 10})
        self.text = self.workbook.add_format({'align': 'center', 'font_size': 14,'bottom': 7,'left': 7,'right': 7})
        self.text4 = self.workbook.add_format({'align': 'center', 'font_size': 14,'top': 1,'left': 1,'right': 1,'bottom':1})
        self.text5 = self.workbook.add_format({'align': 'left', 'font_size': 14,'top': 1,'left': 1,'right': 1,'bottom':1})
        self.text1 = self.workbook.add_format({'align': 'center', 'font_size': 12})
        self.text2 = self.workbook.add_format({'align': 'center', 'font_size': 18,'num_format':'@','bottom': 7,'left': 7,'right': 7})
        self.text3 = self.workbook.add_format({'align': 'left', 'font_size': 14,'bottom': 7,'left': 7,'right': 7})
        self.text_right = self.workbook.add_format({'align': 'right', 'font_size': 12})
        self.text_wrap1 = self.workbook.add_format({'text_wrap':'center','top': 2,'right': 2,'bottom': 2,'valign':'vcenter','align': 'center', 'font_size': 14,'bold': True,'bg_color':'#d9d9d9'})
        self.text_wrap2 = self.workbook.add_format({'text_wrap':'center','top': 2,'right': 2,'bottom': 2,'left':2,'valign':'vcenter','align': 'center', 'font_size': 14,'bold': True})
        self.number = self.workbook.add_format({'num_format': '#,##0.00', 'font_size': 10})
        self.percent = self.workbook.add_format({'num_format': '0.00%', 'font_size': 16,'bottom': 7,'left': 7,'right': 7})
        self.percent_red = self.workbook.add_format({'num_format': '0.00%', 'font_size': 10, 'font_color': 'red'})
        self.float_num = self.workbook.add_format({'num_format': '0.00000', 'font_size': 10})
        self.center = self.workbook.add_format({'align':'center','valign':'vcenter','bottom': 7,'left': 7,'right': 7})
        self.number_1 = self.workbook.add_format({'num_format': '#,##0.00', 'font_size': 16,'align':'right','bg_color':'#d9d9d9','left': 7,'right': 7})
        self.number_2 = self.workbook.add_format({'num_format': '0.0000_ ', 'font_size': 10})
        self.number_bold = self.workbook.add_format({'bold': True,'num_format': '#,##0', 'font_size': 18,'align':'center'})
        self.number_int = self.workbook.add_format({'num_format': '0', 'font_size': 16,'align':'center','valign':'vcenter'})
        self.number_int2 = self.workbook.add_format({'num_format': '#,##0', 'font_size': 16,'align':'right','bottom': 7,'left': 7,'right': 7})
        self.number_int3 = self.workbook.add_format({'num_format': '#,##0;△ #,##0;', 'font_size': 16,'align':'right','bottom': 7,'left': 7,'right': 7})
        self.number_int4 = self.workbook.add_format({'num_format': '0;-0;;@', 'font_size': 16,'align':'center','bottom': 7,'left': 7,'right': 7})
        self.number_int5 = self.workbook.add_format({'num_format': '#,##0', 'align': 'center', 'valign':'vcenter', 'font_size': 14,'bottom': 7,'left': 7,'right': 7})
        
        self.num = self.workbook.add_format({'align': 'center', 'font_size': 14,'bottom': 7,'left': 7,'right': 7, 'num_format': '0.00', 'font_size': 14})
        #self.bold_upline2 = self.workbook.add_format({'bold': True, 'top': 6, 'align': 'center', 'num_format': '0', 'font_size': 10})
        self.bold_upline3 = self.workbook.add_format({'bold': True, 'top': 6, 'align': 'right', 'num_format': '0.00%', 'font_size': 10})
        self.bold_upline4 = self.workbook.add_format({'bold': True, 'top': 6, 'align': 'right', 'num_format': '0.00', 'font_size': 10})
        self.bold_left = self.workbook.add_format({'left': 2,'bottom': 7,'right': 7})
        self.bold_left2 = self.workbook.add_format({'left': 2,'top': 2})
        self.bold_left3 = self.workbook.add_format({'left': 2})
        self.bold_left4 = self.workbook.add_format({'left': 2,'bottom':7})
        self.bold_right = self.workbook.add_format({'right': 2,'bottom': 7,'left': 7})
        self.bold_top = self.workbook.add_format({'top': 1,'bottom': 7,'right': 7})
        self.bold_top2 = self.workbook.add_format({'top': 2,'bottom': 7,'right': 7})
        self.bold_top3 = self.workbook.add_format({'bold': True,'left':1,'right':1,'top': 2, 'font_size': 14,'align': 'center','valign':'vcenter'})
        self.bold_top4 = self.workbook.add_format({'top': 2})
        self.bold_top5 = self.workbook.add_format({'bottom': 7,'left':2})
        self.bold_RT = self.workbook.add_format({'top': 2, 'bottom': 7,'left':7, 'right':2})
        self.bold_bot = self.workbook.add_format({'bold': True,'bottom': 2,'right':7,'top': 7, 'font_size': 14,'align': 'center','valign':'vcenter'})
        self.bold_bot2 = self.workbook.add_format({'bottom': 1,'left': 7,'top': 7})
        self.bold_bot3 = self.workbook.add_format({'bottom': 2,'left': 7,'top': 7,'right':7})
        self.bold_LU = self.workbook.add_format({'left': 2,'top': 1,'bottom': 7,'right':7})
        self.bold_LU2 = self.workbook.add_format({'left': 2,'top': 2,'bottom': 7})
        self.bold_RU = self.workbook.add_format({'right': 2,'top': 1,'bottom': 7,'left':7})
        self.bold_RU2 = self.workbook.add_format({'right': 2,'top': 2})
        self.bold_RU3 = self.workbook.add_format({'right': 2,'top': 7,'bottom':2})
        self.bold_LR = self.workbook.add_format({'left': 2,'right': 2,'bottom': 7})
        self.bold_LR2 = self.workbook.add_format({'left': 2,'right': 2})
        self.bold_LB = self.workbook.add_format({'left': 2,'bottom': 2,'top':7,'right': 7,'align':'center','valign':'vcenter'})
        self.bold_LB2 = self.workbook.add_format({'left': 2,'bottom': 2,'top':7,'right': 7})
        self.bold_RB = self.workbook.add_format({'right': 2,'bottom': 2,'top':7,'left': 7,'align':'center','valign':'vcenter'})
        self.bold_RB2 = self.workbook.add_format({'right': 2,'bottom': 2,'top':7,'left': 7})
        self.bold_LRB = self.workbook.add_format({'left': 2,'right': 2,'bottom': 1})
        self.bold_LRB2 = self.workbook.add_format({'left': 2,'right': 2,'bottom': 2})
        self.bold_LRB3 = self.workbook.add_format({'left': 2,'right': 2,'bottom':2,'align': 'center','valign':'vcenter', 'font_size': 16})
        self.bold_LRB4 = self.workbook.add_format({'left': 2,'right': 2,'bottom':2,'top':7})
        self.bold_LRU = self.workbook.add_format({'bold': True,'left': 2,'right': 2,'bottom':7,'top':2,'align': 'center','valign':'vcenter', 'font_size': 16})
        self.bold_LRU2 = self.workbook.add_format({'bold': True,'left': 2,'right': 2,'top':1,'align': 'center','valign':'vcenter', 'font_size': 16})
        self.bold_LRU4 = self.workbook.add_format({'left': 2,'right': 2,'bottom': 7})
        self.bold_LRU5 = self.workbook.add_format({'left': 2,'right': 2,'bottom': 7, 'top': 1})
        
        self.bold_all = self.workbook.add_format({'bold': True,'num_format': '#,##0','left': 2,'right': 2,'top': 2,'bottom': 2,'align': 'center','valign':'vcenter', 'font_size': 18})
        self.bold_col = self.workbook.add_format({'bold': True, 'font_size': 14,'right':7,'align': 'center','valign':'vcenter','bg_color':'#ddebf7'})
        self.bold_red = self.workbook.add_format({'bold': True,'num_format': '+ #,##0;- #,##0;','left': 2,'right': 2,'top': 2,'bottom': 2,'align': 'center','valign':'vcenter', 'font_size': 18,'font_color': 'red'})
        self.bold_all2 = self.workbook.add_format({'bold': True,'left': 2,'right': 2,'top': 2,'bottom': 2,'align': 'center','valign':'vcenter', 'font_size': 14})
        self.bold_exleft = self.workbook.add_format({'bold': True, 'left': 7,'right': 2,'bottom': 2, 'top': 2, 'font_size': 14,'align': 'center','valign':'vcenter'})
        self.number_lp = self.workbook.add_format({'num_format': '#,##0.00', 'align': 'center', 'font_size': 14,'bottom': 7,'left': 7,'right': 7})
        
        
        
        
    # 운용현황시트 생성 (#04.09)
    def Manage_info(self):
        global nall
        df_date= self.df.date()
        #rint(df_date)
        df1= self.df.df1
        #rint(df1)
        df_yield= self.df.df_yield
        #rint(df_yield)
        df_overview = self.df.df_overview
        df_overview_ace = self.df.df_overview_ace
        df_csfw = self.df.df_csfw
        df_csfw_ace = self.df.df_csfw_ace
        df_nav = self.df.df_nav
        # df2= self.df.df2
        nav1= self.df.nav1
        nav2= self.df.nav2
        ca_kor= self.df.ca_kor
        ca_gbl= self.df.ca_gbl
        df_fee= self.df.df_fee
        df_AP= self.df.df_AP
        df_AP_PDAY = self.df.df_AP_PDAY
        df_p_amt = self.df.df_p_amt
        df_lp_sum = self.df.df_lp_sum
        #rint(df_lp_sum)/





        global p_last
        global last
        global c_last
        global netf
        global sum_cell1
        global sum_cell2        
        global perc_cell1
        global perc_cell2
        
        ##헤드부분
        worksheet_portfolio = self.workbook.add_worksheet('운용현황')
        
        worksheet_portfolio.write('AD14','(단위 : 백만원)',self.text1)
        worksheet_portfolio.write('L14','(단위 : 백만원)',self.text1)
        worksheet_portfolio.write('AG2',str(date.today()),self.bold7)
        worksheet_portfolio.write('I17','총',self.bold_bot)
        worksheet_portfolio.write('J17','1W',self.bold_bot)
        worksheet_portfolio.write('K17','1M',self.bold_bot)
        worksheet_portfolio.write('L17','3M',self.bold_bot)
        worksheet_portfolio.write('M17','편입비(%)',self.bold_bot)

        worksheet_portfolio.write('N16','1Day',self.bold2)
        worksheet_portfolio.write('O16','1W',self.bold2)
        worksheet_portfolio.write('P16','1M',self.bold2)
        worksheet_portfolio.write('Q16','3M',self.bold2)
        worksheet_portfolio.write('R16','6M',self.bold2)
        worksheet_portfolio.write('S16','1Y',self.bold2)
        worksheet_portfolio.write('T16','MTD',self.bold2)
        worksheet_portfolio.write('U16','YTD',self.bold2)
        worksheet_portfolio.write('V16','1Day',self.bold2)
        worksheet_portfolio.write('W16','1W',self.bold2)
        worksheet_portfolio.write('X16','1M',self.bold2)
        worksheet_portfolio.write('Y16','3M',self.bold2)
        worksheet_portfolio.write('Z16','6M',self.bold2)
        worksheet_portfolio.write('AA16','1Y',self.bold2)
        worksheet_portfolio.write('AB16','MTD',self.bold2)
        worksheet_portfolio.write('AC16','YTD',self.bold2)
        
        worksheet_portfolio.write('AD17','총',self.bold_bot)
        worksheet_portfolio.write('AE17','설정/해지',self.bold_bot)
        
        worksheet_portfolio.merge_range('C15:C17','구분',self.bold_all2)
        worksheet_portfolio.merge_range('D15:D17','Code',self.bold_upline)
        worksheet_portfolio.merge_range('E15:E17','펀    드    명',self.bold_upline)
        worksheet_portfolio.merge_range('F15:F17','운용역',self.bold_upline)
        worksheet_portfolio.merge_range('G15:G17','설정일',self.bold_upline)
        worksheet_portfolio.merge_range('H15:H17','결산일',self.bold_upline)
        worksheet_portfolio.merge_range('I15:M15','N A V',self.bold_upline)
        worksheet_portfolio.merge_range('J16:L16','대비',self.bold_upline)
        worksheet_portfolio.conditional_format('J16:L17',{'type': 'no_blanks','format':self.bold_all})
        worksheet_portfolio.merge_range('N15:U15','BM 대비 수익률(BP)',self.bold2)
        
        worksheet_portfolio.merge_range('V15:AC15','수익률(%)',self.bold2)
        
        worksheet_portfolio.merge_range('AD15:AE16','설      정      고',self.bold_upline)
        worksheet_portfolio.conditional_format('AD15:AE16',{'type': 'no_blanks','format':self.bold_upline2})
        worksheet_portfolio.merge_range('AF15:AF17','수정기준가       현재 BM',self.text_wrap1)
        worksheet_portfolio.conditional_format('AF15:AF17',{'type': 'no_blanks','format':self.bold_all})
        worksheet_portfolio.merge_range('AG15:AG17','NAV 증감     (22년말 대비)',self.text_wrap2)
        worksheet_portfolio.conditional_format('AG15:AG17',{'type': 'no_blanks','format':self.bold_all})
        
        ##수익률부분
        netf=len(df1[df1['typ']=='ETF'])
        nall=len(df1)
        # nbm=len(df2)
        
        worksheet_portfolio.write('W7',' ')
        

        # Column,row width 정의
        worksheet_portfolio.set_column('A:A', 3.25)
        worksheet_portfolio.set_column('B:B', 2.5)
        worksheet_portfolio.set_column('C:C', 17.5)
        worksheet_portfolio.set_column('D:D', 14.13)
        worksheet_portfolio.set_column('E:E', 43.5)
        worksheet_portfolio.set_column('F:H', 14.13)
        worksheet_portfolio.set_column('I:L', 16)
        worksheet_portfolio.set_column('M:M', 15.5)
        worksheet_portfolio.set_column('N:AC', 15.25)
        worksheet_portfolio.set_column('AD:AD', 14.88)
        worksheet_portfolio.set_column('AE:AE', 10)
        worksheet_portfolio.set_column('AF:AF', 15.75)
        worksheet_portfolio.set_column('AG:AG', 16.63)
        worksheet_portfolio.set_row(0,21.75)
        worksheet_portfolio.set_row(1,21.75)
        worksheet_portfolio.set_row(2,21.75)
        worksheet_portfolio.set_row(3,21.75)
        worksheet_portfolio.set_row(4,21.75)
        worksheet_portfolio.set_row(5,21.75)
        worksheet_portfolio.set_row(6,21.75)
        worksheet_portfolio.set_row(7,21.75)
        worksheet_portfolio.set_row(8,21.75)
        worksheet_portfolio.set_row(9,21.75)
        worksheet_portfolio.set_row(10,21.75)
        worksheet_portfolio.set_row(11,21.75)
        worksheet_portfolio.set_row(12,21.75)
        worksheet_portfolio.set_row(13,21.75)
        worksheet_portfolio.set_row(14,21.75)
        worksheet_portfolio.set_row(15,21.75)
        worksheet_portfolio.set_row(16,21.75)
        worksheet_portfolio.set_row(17,21.75)
        worksheet_portfolio.set_row(18,21.75)
        worksheet_portfolio.set_row(19,21.75)
        worksheet_portfolio.set_row(20,21.75)
        worksheet_portfolio.set_row(21,21.75)
        worksheet_portfolio.set_row(22,21.75)
        worksheet_portfolio.set_row(23,21.75)
        worksheet_portfolio.set_row(24,21.75)
        worksheet_portfolio.set_row(25,21.75)
        worksheet_portfolio.set_row(26,21.75)
        worksheet_portfolio.set_row(27,21.75)
        worksheet_portfolio.set_row(28,21.75)
        worksheet_portfolio.set_row(29,21.75)
        worksheet_portfolio.set_row(30,21.75)
        worksheet_portfolio.set_row(31,21.75)
        worksheet_portfolio.set_row(32,21.75)
        worksheet_portfolio.set_row(33,21.75)
        worksheet_portfolio.set_row(34,21.75)
        worksheet_portfolio.set_row(35,21.75)
        worksheet_portfolio.set_row(36,21.75)
        worksheet_portfolio.set_row(37,21.75)
        worksheet_portfolio.set_row(38,21.75)
        worksheet_portfolio.set_row(39,21.75)
        worksheet_portfolio.set_row(40,21.75)
        worksheet_portfolio.set_row(41,21.75)
        worksheet_portfolio.set_row(42,21.75)
        worksheet_portfolio.set_row(43,21.75)
        worksheet_portfolio.set_row(44,21.75)
        worksheet_portfolio.set_row(45,21.75)
        worksheet_portfolio.set_row(46,21.75)
        worksheet_portfolio.set_row(47,21.75)
        worksheet_portfolio.set_row(48,21.75)
        worksheet_portfolio.set_row(49,21.75)
        worksheet_portfolio.set_row(50,21.75)
        worksheet_portfolio.set_row(51,21.75)
        worksheet_portfolio.set_row(52,21.75)
        worksheet_portfolio.set_row(53,21.75)
        worksheet_portfolio.set_row(54,21.75)
        worksheet_portfolio.set_row(55,21.75)
        worksheet_portfolio.set_row(56,21.75)
        worksheet_portfolio.set_row(57,21.75)
        worksheet_portfolio.set_row(58,21.75)
        worksheet_portfolio.set_row(59,21.75)
        worksheet_portfolio.set_row(60,21.75)
        worksheet_portfolio.set_row(61,21.75)
        worksheet_portfolio.set_row(62,21.75)
        worksheet_portfolio.set_row(63,21.75)
        worksheet_portfolio.set_row(64,21.75)
        worksheet_portfolio.set_row(65,21.75)
        worksheet_portfolio.set_row(66,21.75)
        worksheet_portfolio.set_row(67,21.75)
        worksheet_portfolio.set_row(68,21.75)
        worksheet_portfolio.set_row(69,21.75)
        worksheet_portfolio.set_row(70,21.75)
        worksheet_portfolio.set_row(71,21.75)
        worksheet_portfolio.set_row(72,21.75)
        worksheet_portfolio.set_row(73,21.75)
        worksheet_portfolio.set_row(74,21.75)
        worksheet_portfolio.set_row(75,21.75)
        worksheet_portfolio.set_row(76,21.75)
        worksheet_portfolio.set_row(77,21.75)
        worksheet_portfolio.set_row(78,21.75)
        worksheet_portfolio.set_row(79,21.75)
        worksheet_portfolio.set_row(80,21.75)
        worksheet_portfolio.set_row(81,21.75)
        worksheet_portfolio.set_row(82,21.75)
        worksheet_portfolio.set_row(83,21.75)
        worksheet_portfolio.set_row(84,21.75)
        worksheet_portfolio.set_row(85,21.75)
        worksheet_portfolio.set_row(86,21.75)
        worksheet_portfolio.set_row(87,21.75)
        worksheet_portfolio.set_row(88,21.75)
        worksheet_portfolio.set_row(89,21.75)
        worksheet_portfolio.set_row(90,21.75)
        worksheet_portfolio.set_row(91,21.75)
        worksheet_portfolio.set_row(92,21.75)
        worksheet_portfolio.set_row(93,21.75)
        worksheet_portfolio.set_row(94,21.75)
        worksheet_portfolio.set_row(95,21.75)
        worksheet_portfolio.set_row(96,21.75)
        worksheet_portfolio.set_row(97,21.75)
        worksheet_portfolio.set_row(98,21.75)
        worksheet_portfolio.set_row(99,21.75)
        worksheet_portfolio.set_row(100,21.75)
        worksheet_portfolio.set_row(101,21.75)
        worksheet_portfolio.set_row(102,21.75)
        worksheet_portfolio.set_row(103,21.75)
        worksheet_portfolio.set_row(104,21.75)
        worksheet_portfolio.set_row(105,21.75)
        worksheet_portfolio.set_row(106,21.75)
        worksheet_portfolio.set_row(107,21.75)
        worksheet_portfolio.set_row(108,21.75)
        worksheet_portfolio.set_row(109,21.75)
        worksheet_portfolio.set_row(110,21.75)
        worksheet_portfolio.set_row(111,21.75)
        worksheet_portfolio.set_row(112,21.75)
        worksheet_portfolio.set_row(113,21.75)
        worksheet_portfolio.set_row(114,21.75)
        worksheet_portfolio.set_row(115,21.75)
        worksheet_portfolio.set_row(116,21.75)
        worksheet_portfolio.set_row(117,21.75)
        worksheet_portfolio.set_row(118,21.75)
        worksheet_portfolio.set_row(119,21.75)
        worksheet_portfolio.set_row(120,21.75)
        worksheet_portfolio.set_row(121,21.75)
        worksheet_portfolio.set_row(122,21.75)
        worksheet_portfolio.set_row(123,21.75)
        worksheet_portfolio.set_row(124,21.75)
        worksheet_portfolio.set_row(125,21.75)
        worksheet_portfolio.set_row(126,21.75)
        worksheet_portfolio.set_row(127,21.75)
        worksheet_portfolio.set_row(128,21.75)
        worksheet_portfolio.set_row(129,21.75)
        worksheet_portfolio.set_row(130,21.75)
        worksheet_portfolio.set_row(131,21.75)
        worksheet_portfolio.set_row(132,21.75)
        worksheet_portfolio.set_row(133,21.75)
        worksheet_portfolio.set_row(134,21.75)
        worksheet_portfolio.set_row(135,21.75)
        worksheet_portfolio.set_row(136,21.75)
        worksheet_portfolio.set_row(137,21.75)
        worksheet_portfolio.set_row(138,21.75)
        worksheet_portfolio.set_row(139,21.75)
        worksheet_portfolio.set_row(140,21.75)
        worksheet_portfolio.set_row(141,21.75)
        worksheet_portfolio.set_row(142,21.75)
        worksheet_portfolio.set_row(143,21.75)
        worksheet_portfolio.set_row(144,21.75)
        worksheet_portfolio.set_row(145,21.75)
        worksheet_portfolio.set_row(146,21.75)
        worksheet_portfolio.set_row(147,21.75)
        worksheet_portfolio.set_row(148,21.75)
        worksheet_portfolio.set_row(149,21.75)
        worksheet_portfolio.set_row(150,21.75)
        
        



        #엑셀 서식
        worksheet_portfolio.conditional_format('C19:C'+str(16+nall),{'type': 'no_blanks','format':self.bold_LR2})
        worksheet_portfolio.conditional_format('C19:C'+str(16+nall),{'type': 'blanks','format':self.bold_LR2})
        
        worksheet_portfolio.conditional_format('C'+str(18+netf)+':C'+str(18+netf),{'type': 'no_blanks','format':self.bold_top4})
        worksheet_portfolio.conditional_format('C'+str(18+netf)+':C'+str(18+netf),{'type': 'blanks','format':self.bold_top4})
        worksheet_portfolio.conditional_format('C'+str(17+nall)+':C'+str(nall+17),{'type': 'blanks','format':self.bold_LRB3})
        worksheet_portfolio.conditional_format('C'+str(17+nall)+':C'+str(nall+17),{'type': 'no_blanks','format':self.bold_LRB3})
        
        worksheet_portfolio.conditional_format('D'+str(18+nall)+':D'+str(18+nall),{'type': 'no_blanks','format':self.bold_LU})
        worksheet_portfolio.conditional_format('D'+str(17+nall)+':D'+str(nall+17),{'type': 'no_blanks','format':self.bold_LB2})
        
        worksheet_portfolio.conditional_format('E'+str(17+nall)+':G'+str(nall+17),{'type': 'no_blanks','format':self.bold_bot3})
        
        worksheet_portfolio.conditional_format('H'+str(18+netf)+':H'+str(18+netf),{'type': 'no_blanks','format':self.bold_RU})
        worksheet_portfolio.conditional_format('H'+str(17+nall)+':H'+str(17+nall),{'type': 'no_blanks','format':self.bold_RB2})
        
        worksheet_portfolio.conditional_format('I'+str(17+nall)+':I'+str(nall+17),{'type': 'no_blanks','format':self.bold_LB2})
        
        worksheet_portfolio.conditional_format('J'+str(17+nall)+':L'+str(nall+17),{'type': 'blanks','format':self.bold_bot3})
        worksheet_portfolio.conditional_format('J'+str(17+nall)+':L'+str(nall+17),{'type': 'no_blanks','format':self.bold_bot3})        
        
        worksheet_portfolio.conditional_format('M'+str(17+nall)+':M'+str(17+nall),{'type': 'no_blanks','format':self.bold_LRB2})
        worksheet_portfolio.conditional_format('M'+str(17+nall)+':M'+str(17+nall),{'type': 'blanks','format':self.bold_LRB2})
        worksheet_portfolio.conditional_format('M'+str(18+netf)+':M'+str(18+netf),{'type': 'no_blanks','format':self.bold_LRU5})
        worksheet_portfolio.conditional_format('M'+str(18+netf)+':M'+str(18+netf),{'type': 'blanks','format':self.bold_LRU5})
        
        worksheet_portfolio.conditional_format('N'+str(17+nall)+':N'+str(17+nall),{'type': 'no_blanks','format':self.bold_LB2})
        worksheet_portfolio.conditional_format('N'+str(17+nall)+':N'+str(17+nall),{'type': 'blanks','format':self.bold_LB2})
        worksheet_portfolio.conditional_format('N'+str(18+netf)+':N'+str(18+netf),{'type': 'no_blanks','format':self.bold_LU})
        worksheet_portfolio.conditional_format('N'+str(18+netf)+':N'+str(18+netf),{'type': 'blanks','format':self.bold_LU})
        
        worksheet_portfolio.conditional_format('O'+str(17+nall)+':T'+str(nall+17),{'type': 'no_blanks','format':self.bold_bot3})
        worksheet_portfolio.conditional_format('O'+str(17+nall)+':T'+str(nall+17),{'type': 'blanks','format':self.bold_bot3})
        
        worksheet_portfolio.conditional_format('U'+str(17+nall)+':U'+str(17+nall),{'type': 'no_blanks','format':self.bold_RU3})
        worksheet_portfolio.conditional_format('U'+str(17+nall)+':U'+str(17+nall),{'type': 'blanks','format':self.bold_RU3})
        worksheet_portfolio.conditional_format('U'+str(18+netf)+':U'+str(18+netf),{'type': 'no_blanks','format':self.bold_RU})
        worksheet_portfolio.conditional_format('U'+str(18+netf)+':U'+str(18+netf),{'type': 'blanks','format':self.bold_RU})
        
        worksheet_portfolio.conditional_format('V'+str(17+nall)+':V'+str(nall+17),{'type': 'no_blanks','format':self.bold_LB2})
        
        worksheet_portfolio.conditional_format('W'+str(17+nall)+':AB'+str(nall+17),{'type': 'no_blanks','format':self.bold_bot3})
        worksheet_portfolio.conditional_format('W'+str(17+nall)+':AB'+str(nall+17),{'type': 'blanks','format':self.bold_bot3})
        
        worksheet_portfolio.conditional_format('AC'+str(17+nall)+':AC'+str(17+nall),{'type': 'no_blanks','format':self.bold_RU3})
        worksheet_portfolio.conditional_format('AC'+str(17+nall)+':AC'+str(17+nall),{'type': 'blanks','format':self.bold_RU3})
        worksheet_portfolio.conditional_format('AC'+str(18+netf)+':AC'+str(18+netf),{'type': 'no_blanks','format':self.bold_RU})
        worksheet_portfolio.conditional_format('AC'+str(18+netf)+':AC'+str(18+netf),{'type': 'blanks','format':self.bold_RU})
        
        worksheet_portfolio.conditional_format('AD'+str(17+nall)+':AD'+str(nall+17),{'type': 'no_blanks','format':self.bold_LB2})
        
        worksheet_portfolio.conditional_format('AE'+str(17+nall)+':AE'+str(nall+17),{'type': 'blanks','format':self.bold_RB2})
        worksheet_portfolio.conditional_format('AE'+str(17+nall)+':AE'+str(nall+17),{'type': 'no_blanks','format':self.bold_RB2})
        worksheet_portfolio.conditional_format('AE'+str(18+netf)+':AE'+str(18+netf),{'type': 'no_blanks','format':self.bold_RU})
        worksheet_portfolio.conditional_format('AE'+str(18+netf)+':AE'+str(18+netf),{'type': 'blanks','format':self.bold_RU})
        
        worksheet_portfolio.conditional_format('AF'+str(17+nall)+':AF'+str(17+nall),{'type': 'no_blanks','format':self.bold_RU3})
        worksheet_portfolio.conditional_format('AF'+str(17+nall)+':AF'+str(17+nall),{'type': 'blanks','format':self.bold_RU3})
        worksheet_portfolio.conditional_format('AF'+str(18+netf)+':AF'+str(18+netf),{'type': 'no_blanks','format':self.bold_RU})
        worksheet_portfolio.conditional_format('AF'+str(18+netf)+':AF'+str(18+netf),{'type': 'blanks','format':self.bold_RU})
        
        worksheet_portfolio.conditional_format('AG'+str(17+nall)+':AG'+str(17+nall),{'type': 'no_blanks','format':self.bold_RU3})
        worksheet_portfolio.conditional_format('AG'+str(17+nall)+':AG'+str(17+nall),{'type': 'blanks','format':self.bold_RU3})
        worksheet_portfolio.conditional_format('AG'+str(18+netf)+':AG'+str(18+netf),{'type': 'no_blanks','format':self.bold_RU})
        worksheet_portfolio.conditional_format('AG'+str(18+netf)+':AG'+str(18+netf),{'type': 'blanks','format':self.bold_RU})
        
        
        #예외
        
        # worksheet_portfolio.conditional_format('AF'+str(18+netf)+':AF'+str(18+netf),{'type': 'no_blanks','format':self.bold_RU})
        # worksheet_portfolio.conditional_format('AF'+str(17+nall)+':AF'+str(17+nall),{'type': 'no_blanks','format':self.bold_LRB3})
        
        
        worksheet_portfolio.conditional_format('N15:U15',{'type': 'no_blanks','format':self.bold_LRU})
        worksheet_portfolio.conditional_format('N17:U17',{'type': 'no_blanks','format':self.bold_bot})
        worksheet_portfolio.conditional_format('I15:M15',{'type': 'no_blanks','format':self.bold_LRU})
        
        worksheet_portfolio.conditional_format('V15:AC15',{'type': 'no_blanks','format':self.bold_LRU})
        worksheet_portfolio.conditional_format('V17:AC17',{'type': 'no_blanks','format':self.bold_bot})
        
        worksheet_portfolio.conditional_format('I17:I17',{'type': 'no_blanks','format':self.bold_LB})
        worksheet_portfolio.conditional_format('M17:M17',{'type': 'no_blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format('AD17:AD17',{'type': 'no_blanks','format':self.bold_LB})
        worksheet_portfolio.conditional_format('AE17:AE17',{'type': 'no_blanks','format':self.bold_RB})
        
        
        worksheet_portfolio.conditional_format('AF18:AF18',{'type': 'blanks','format':self.bold_LU2})
        worksheet_portfolio.conditional_format('AF18:AF18',{'type': 'no_blanks','format':self.bold_LU2})
        
        worksheet_portfolio.conditional_format('AG18:AG18',{'type': 'blanks','format':self.bold_LR2})
        worksheet_portfolio.conditional_format('AG18:AG18',{'type': 'no_blanks','format':self.bold_LR2})
        
        
        worksheet_portfolio.conditional_format('C'+str(18+netf)+':AG'+str(18+netf),{'type': 'no_blanks','format':self.bold_top})
        worksheet_portfolio.conditional_format('C'+str(18+netf)+':AG'+str(18+netf),{'type': 'blanks','format':self.bold_top})
        
        
        worksheet_portfolio.conditional_format('I'+str(18+nall)+':I'+str(18+nall),{'type': 'no_blanks','format':self.bold_top5})
        worksheet_portfolio.conditional_format('AF'+str(18+nall)+':AF'+str(18+nall),{'type': 'no_blanks','format':self.bold_LRU4})
        
        worksheet_portfolio.conditional_format('I15'+':I'+str(16+nall),{'type': 'no_blanks','format':self.bold_left})
        worksheet_portfolio.conditional_format('I15'+':I'+str(16+nall),{'type': 'blanks','format':self.bold_left})
        worksheet_portfolio.conditional_format('M15'+':M'+str(16+nall),{'type': 'no_blanks','format':self.bold_left})
        worksheet_portfolio.conditional_format('M15'+':M'+str(16+nall),{'type': 'blanks','format':self.bold_left})
        worksheet_portfolio.conditional_format('N15'+':N'+str(16+nall),{'type': 'no_blanks','format':self.bold_left})
        worksheet_portfolio.conditional_format('N15'+':N'+str(16+nall),{'type': 'blanks','format':self.bold_left})
        worksheet_portfolio.conditional_format('V15'+':V'+str(16+nall),{'type': 'no_blanks','format':self.bold_left})
        worksheet_portfolio.conditional_format('V15'+':V'+str(16+nall),{'type': 'blanks','format':self.bold_left})
        worksheet_portfolio.conditional_format('AC15'+':AC'+str(16+nall),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format('AC15'+':AC'+str(16+nall),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format('AE15'+':AE'+str(16+nall),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format('AE15'+':AE'+str(16+nall),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format('AF15'+':AF'+str(16+nall),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format('AF15'+':AF'+str(16+nall),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format('AG18'+':AG'+str(16+nall),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format('AG18'+':AG'+str(16+nall),{'type': 'no_blanks','format':self.bold_right})        

        ## Column 제목 입력 (04.09)
        header_name = ['ETF 수익률 현황']
        header_name2 = [df_date['TRD_DT_PDAY'][0][0:10],df_date['TRD_DT_PWEEK'][0][0:10],df_date['TRD_DT_PMON1'][0][0:10],df_date['TRD_DT_PMON3'][0][0:10],df_date['TRD_DT_PMON6'][0][0:10],df_date['TRD_DT_PYEAR'][0][0:10],df_date['TRD_DT_MTD'][0][0:10],df_date['TRD_DT_YTD'][0][0:10]]
        worksheet_portfolio.write_row(1, 2, header_name, self.bold)
        worksheet_portfolio.write_row('N17', header_name2, self.bold_col)
        worksheet_portfolio.write_row('V17', header_name2, self.bold_col)
        worksheet_portfolio.write('C18','ETF',self.bold_LRU)
        worksheet_portfolio.write('C'+str(17+netf),'',self.bold_LRB)
        worksheet_portfolio.write('C'+str(18+netf),'FUND',self.bold_LRU2)
        worksheet_portfolio.write('C19',int(netf),self.bold3)
        worksheet_portfolio.write('C'+str(19+netf),int(nall-netf),self.bold8)


        ## NAV 표 입력 (04.09)
        worksheet_portfolio.merge_range('C5:C8','ETF',self.bold_all)
        worksheet_portfolio.merge_range('C9:C12','FUND',self.bold_all)
        
        worksheet_portfolio.merge_range('D5:D6','NAV',self.bold_all)
        worksheet_portfolio.merge_range('D7:D8','설정액',self.bold_all)
        
        worksheet_portfolio.merge_range('D9:D10','NAV',self.bold_all)
        worksheet_portfolio.merge_range('D11:D12','설정액',self.bold_all)

        worksheet_portfolio.merge_range('E5:E6',nav1['VAL'][4],self.bold_all)
        worksheet_portfolio.merge_range('E7:E8',nav1['VAL'][5],self.bold_all)
        worksheet_portfolio.merge_range('E9:E10',nav1['VAL'][6],self.bold_all)
        worksheet_portfolio.merge_range('E11:E12',nav1['VAL'][7],self.bold_all)
        
        worksheet_portfolio.write('I4','(단위 : 백만원)',self.text1)
        worksheet_portfolio.write('F4','전일 대비',self.text1)
        worksheet_portfolio.write('H4','연초 대비',self.text1)
        worksheet_portfolio.merge_range('F5:G6',nav1['VAL'][0],self.bold_all) ## 전일 ETF NAV
        
        
        worksheet_portfolio.merge_range('F7:G8', nav1['VAL'][4]-nav1['VAL'][0],self.bold_red) ##하루 사이 NAV 증감
        
        worksheet_portfolio.merge_range('F9:G10',nav1['VAL'][3],self.bold_all) ## 전일 FUND 설정액
        worksheet_portfolio.merge_range('F11:G12',nav1['VAL'][7]-nav1['VAL'][3],self.bold_red) ##하루 사이 설정액 증
        
        worksheet_portfolio.merge_range('H5:I6', 13125624.60, self.bold_all) ##연초에 값 바꿔줘야함  -- 연초 ETF NAV  13125624.60
        
        worksheet_portfolio.merge_range('H7:I8',nav1['VAL'][4]-13125624.60,self.bold_red) ##연초에 값 바꿔줘야함
        worksheet_portfolio.merge_range('H9:I10', 30226.233,self.bold_all) ##연초에 값 바꿔줘야함  -- 연초 FUND 설정액 30226.233
        #
        worksheet_portfolio.merge_range('H11:I12',nav1['VAL'][7]-30226.233,self.bold_red) ##연초에 값 바꿔줘야함
        
        # worksheet_portfolio.conditional_format('C5:I12',{'type': 'no_blanks','format':self.bold_all})
        
        
        ## 전체시장현황 표 입력 (04.09)
        header_name_all = ['전체 시장 현황']
        worksheet_portfolio.write_row(2, 10, header_name_all, self.bold)
        worksheet_portfolio.write('L4','전일 AUM(억)',self.text1)
        worksheet_portfolio.write('M4','금일 AUM(억)',self.text1)
        worksheet_portfolio.write('N4','ΔAUM(억)',self.text1)
        worksheet_portfolio.write('O4','Δ설정액(억)',self.text1)
        
        worksheet_portfolio.merge_range('K5:K6','주식',self.bold_all)
        worksheet_portfolio.merge_range('K7:K8','채권',self.bold_all)
        worksheet_portfolio.merge_range('K9:K10','기타',self.bold_all)
        worksheet_portfolio.merge_range('K11:K12','합계',self.bold_all)
        
            # 데이터 넣을 부분
        worksheet_portfolio.merge_range('L5:L6', df_overview['기초AUM(억)'][1],self.bold_all)   # 주식 전일 AUM
        worksheet_portfolio.merge_range('L7:L8',df_overview['기초AUM(억)'][0],self.bold_all)   # 채권 전일 AUM
        worksheet_portfolio.merge_range('L9:L10',df_overview['기초AUM(억)'][2],self.bold_all)  # 기타 전일 AUM
        worksheet_portfolio.merge_range('L11:L12',df_overview['기초AUM(억)'][0]+df_overview['기초AUM(억)'][1]+df_overview['기초AUM(억)'][2],self.bold_all)
        worksheet_portfolio.merge_range('M5:M6',df_overview['기말AUM(억)'][1],self.bold_all)   # 주식 금일 AUM
        worksheet_portfolio.merge_range('M7:M8',df_overview['기말AUM(억)'][0],self.bold_all)   # 채권 금일 AUM
        worksheet_portfolio.merge_range('M9:M10',df_overview['기말AUM(억)'][2],self.bold_all)  # 기타 금일 AUM
        worksheet_portfolio.merge_range('M11:M12',df_overview['기말AUM(억)'][0]+df_overview['기말AUM(억)'][1]+df_overview['기말AUM(억)'][2],self.bold_all)  # 기타 금일 AUM
        
        
        worksheet_portfolio.merge_range('N5:N6',df_overview['ΔAUM(억)'][1],self.bold_all)   # 주식 AUM 변화
        worksheet_portfolio.merge_range('N7:N8',df_overview['ΔAUM(억)'][0],self.bold_all)   # 채권 AUM 변화
        worksheet_portfolio.merge_range('N9:N10',df_overview['ΔAUM(억)'][2],self.bold_all)  # 기타 AUM 변화
        worksheet_portfolio.merge_range('N11:N12',df_overview['ΔAUM(억)'][0]+df_overview['ΔAUM(억)'][1]+df_overview['ΔAUM(억)'][2],self.bold_all)  # 기타 AUM 변화
        worksheet_portfolio.merge_range('O5:O6',df_csfw['Δ설정액(억)'][1],self.bold_all)   # 주식 설정액 변화
        worksheet_portfolio.merge_range('O7:O8',df_csfw['Δ설정액(억)'][0],self.bold_all)   # 채권 설정액 변화
        worksheet_portfolio.merge_range('O9:O10',df_csfw['Δ설정액(억)'][2],self.bold_all)  # 기타 설정액 변화
        worksheet_portfolio.merge_range('O11:O12',df_csfw['Δ설정액(억)'][0]+df_csfw['Δ설정액(억)'][1]+df_csfw['Δ설정액(억)'][2],self.bold_all)  # 기타 설정액 변화
        # worksheet_portfolio.conditional_format('I5:M10',{'type': 'no_blanks','format':self.bold_double})
        
        
        
        ## ACE현황 표 입력 (04.09)
        header_name_ace = ['ACE 현황']
        worksheet_portfolio.write_row(2, 16, header_name_ace, self.bold)
        worksheet_portfolio.write('R4','전일 AUM(억)',self.text1)
        worksheet_portfolio.write('S4','금일 AUM(억)',self.text1)
        worksheet_portfolio.write('T4','ΔAUM(억)',self.text1)
        worksheet_portfolio.write('U4','Δ설정액(억)',self.text1)
        
        worksheet_portfolio.merge_range('Q5:Q6','주식',self.bold_all)
        worksheet_portfolio.merge_range('Q7:Q8','채권',self.bold_all)
        worksheet_portfolio.merge_range('Q9:Q10','기타',self.bold_all)
        worksheet_portfolio.merge_range('Q11:Q12','합계',self.bold_all)
        
        
            # 데이터 넣을 부분 (아직X)
        worksheet_portfolio.merge_range('R5:R6',df_overview_ace['기초AUM(억)'][1],self.bold_all)   # 주식 전일 AUM
        worksheet_portfolio.merge_range('R7:R8',df_overview_ace['기초AUM(억)'][0],self.bold_all)   # 채권 전일 AUM
        worksheet_portfolio.merge_range('R9:R10',df_overview_ace['기초AUM(억)'][2],self.bold_all)  # 기타 전일 AUM
        worksheet_portfolio.merge_range('R11:R12',df_overview_ace['기초AUM(억)'][0]+df_overview_ace['기초AUM(억)'][1]+df_overview_ace['기초AUM(억)'][2],self.bold_all)  # 기타 전일 AUM        
        worksheet_portfolio.merge_range('S5:S6',df_overview_ace['기말AUM(억)'][1],self.bold_all)   # 주식 금일 AUM
        worksheet_portfolio.merge_range('S7:S8',df_overview_ace['기말AUM(억)'][0],self.bold_all)   # 채권 금일 AUM
        worksheet_portfolio.merge_range('S9:S10',df_overview_ace['기말AUM(억)'][2],self.bold_all)  # 기타 금일 AUM
        worksheet_portfolio.merge_range('S11:S12',df_overview_ace['기말AUM(억)'][0]+df_overview_ace['기말AUM(억)'][1]+df_overview_ace['기말AUM(억)'][2],self.bold_all)  # 기타 금일 AUM        
        worksheet_portfolio.merge_range('T5:T6',df_overview_ace['ΔAUM(억)'][1],self.bold_all)   # 주식 AUM 변화
        worksheet_portfolio.merge_range('T7:T8',df_overview_ace['ΔAUM(억)'][0],self.bold_all)   # 채권 AUM 변화
        worksheet_portfolio.merge_range('T9:T10',df_overview_ace['ΔAUM(억)'][2],self.bold_all)  # 기타 AUM 변화
        worksheet_portfolio.merge_range('T11:T12',df_overview_ace['ΔAUM(억)'][0]+df_overview_ace['ΔAUM(억)'][1]+df_overview_ace['ΔAUM(억)'][2],self.bold_all)  # 기타 AUM 변화        
        worksheet_portfolio.merge_range('U5:U6',df_csfw_ace['Δ설정액(억)'][1],self.bold_all)   # 주식 설정액 변화
        worksheet_portfolio.merge_range('U7:U8',df_csfw_ace['Δ설정액(억)'][0],self.bold_all)   # 채권 설정액 변화
        worksheet_portfolio.merge_range('U9:U10',df_csfw_ace['Δ설정액(억)'][2],self.bold_all)  # 기타 설정액 변화
        worksheet_portfolio.merge_range('U11:U12',df_csfw_ace['Δ설정액(억)'][0]+df_csfw_ace['Δ설정액(억)'][1]+df_csfw_ace['Δ설정액(억)'][2],self.bold_all)  # 기타 설정액 변화        
        # worksheet_portfolio.conditional_format('O5:S10',{'type': 'no_blanks','format':self.bold_double})
        
        
        
        #현황자료 입력
        worksheet_portfolio.write_column('D18', df1['FUND_CD'], self.text2)
        worksheet_portfolio.write_column('E18', df1['FUND_NM'], self.text3)
        worksheet_portfolio.write_column('F18', df1['MANAGER'], self.text)
        worksheet_portfolio.write_column('G18', df1['SET_DT'], self.text)
        worksheet_portfolio.write_column('H18', df1['STL_DT'], self.text)
        worksheet_portfolio.write_column('I18', df1['NAV'], self.number_int2)       # 총NAV
        
        print(df_nav)
        
        df_nav_1w = df_nav['NAV_1W'].replace('',0).astype(float)
        # print(df_nav_1w)
        df_1w = df1['NAV'] - df_nav_1w
        # print(df_1w)
        df_1w_dif = []
        # print(len(df_1w))       # 신규상장된 ETF 바로 반영 가능
        # print(len(df1))         # df1은 신규상장 이틀 뒤부터 반영
        for i in range(len(df_1w)):
            if df_1w[i] == df1['NAV'][i]: df_1w_dif.append("")
            else: df_1w_dif.append(df_1w[i]) 
        
        df_nav_1m = df_nav['NAV_1M'].replace('',0).astype(float)
        
        df_1m = df1['NAV'] - df_nav_1m
        df_1m_dif = []
        for i in range(len(df_1m)):
            if df_1m[i] == df1['NAV'][i]: df_1m_dif.append("")
            else: df_1m_dif.append(df_1m[i]) 
        
        df_nav_3m = df_nav['NAV_3M'].replace('',0).astype(float)
        df_3m = df1['NAV'] - df_nav_3m
        df_3m_dif = []
        for i in range(len(df_3m)):
            if df_3m[i] == df1['NAV'][i]: df_3m_dif.append("")
            else: df_3m_dif.append(df_3m[i])    
        
        worksheet_portfolio.write_column('J18', df_1w_dif, self.number_int2)    # NAV 대비 1W
        worksheet_portfolio.write_column('K18', df_1m_dif, self.number_int2)    # NAV 대비 1M
        worksheet_portfolio.write_column('L18', df_3m_dif, self.number_int2)    # NAV 대비 3M
        worksheet_portfolio.write_column('M18', df1['RT'], self.percent)            # 편입비
        
        

        yield1, yield2, yield3, yield4, yield5, yield6, yield7, yield8 = [], [], [], [], [], [], [], []
        for i in range(len(df_yield['STD_PRC_TD'])):
            if df_yield['STD_PRC_PDAY'][i] != "":
                yield1.append(df_yield['STD_PRC_TD'][i] / df_yield['STD_PRC_PDAY'][i] - 1)
            else: yield1.append("")
            if df_yield['STD_PRC_PWEEK'][i] != "":
                yield2.append(df_yield['STD_PRC_TD'][i]/df_yield['STD_PRC_PWEEK'][i]-1)
            else: yield2.append("")
            if df_yield['STD_PRC_PMON1'][i] != "":
                yield3.append(df_yield['STD_PRC_TD'][i]/df_yield['STD_PRC_PMON1'][i]-1)
            else: yield3.append("")
            if df_yield['STD_PRC_PMON3'][i] != "":
                yield4.append(df_yield['STD_PRC_TD'][i]/df_yield['STD_PRC_PMON3'][i]-1)
            else: yield4.append("")
            if df_yield['STD_PRC_PMON6'][i] != "":
                yield5.append(df_yield['STD_PRC_TD'][i]/df_yield['STD_PRC_PMON6'][i]-1)
            else: yield5.append("")
            if df_yield['STD_PRC_PYEAR'][i] != "":
                yield6.append(df_yield['STD_PRC_TD'][i]/df_yield['STD_PRC_PYEAR'][i]-1)
            else: yield6.append("")
            if df_yield['STD_PRC_MTD'][i] != "":
                yield7.append(df_yield['STD_PRC_TD'][i]/df_yield['STD_PRC_MTD'][i]-1)
            else: yield7.append("")
            if df_yield['STD_PRC_YTD'][i] != "":
                yield8.append(df_yield['STD_PRC_TD'][i]/df_yield['STD_PRC_YTD'][i]-1)
            else: yield8.append("")
        
        worksheet_portfolio.write_column('V18', yield1, self.percent)
        worksheet_portfolio.write_column('W18', yield2, self.percent)
        worksheet_portfolio.write_column('X18', yield3, self.percent)
        worksheet_portfolio.write_column('Y18', yield4, self.percent)
        worksheet_portfolio.write_column('Z18', yield5, self.percent)
        worksheet_portfolio.write_column('AA18', yield6, self.percent)
        worksheet_portfolio.write_column('AB18', yield7, self.percent)
        worksheet_portfolio.write_column('AC18', yield8, self.percent)
        
        worksheet_portfolio.write_column('N18', df1['BP1'], self.number_int2)
        worksheet_portfolio.write_column('O18', df1['BP2'], self.number_int2)
        worksheet_portfolio.write_column('P18', df1['BP3'], self.number_int2)
        worksheet_portfolio.write_column('Q18', df1['BP4'], self.number_int2)
        worksheet_portfolio.write_column('R18', df1['BP5'], self.number_int2)
        worksheet_portfolio.write_column('S18', df1['BP6'], self.number_int2)
        worksheet_portfolio.write_column('T18', df1['BP7'], self.number_int2)
        worksheet_portfolio.write_column('U18', df1['BP8'], self.number_int2)
        
        worksheet_portfolio.write_column('AD18', df1['SET_AMT'], self.number_int2)  # 설정고
        worksheet_portfolio.write_column('AE18', df1['CU'], self.number_int4)         # 설정/해지 CU
        worksheet_portfolio.write_column('AF18', df1['STD_PRC'], self.number_1)
        worksheet_portfolio.write_column('AG18', df1['NAV_DIF'], self.number_int3)
        

        #페이지설정
        worksheet_portfolio.freeze_panes(17,0)
        worksheet_portfolio.fit_to_pages(1,1)
        #worksheet_portfolio.print_area('A1:W76')
        #worksheet_portfolio.set_h_pagebreaks([7+nall])
        worksheet_portfolio.set_margins(left=0,right=0,top=0.25, bottom=0.25) 
        worksheet_portfolio.set_header(margin=0.45)
        worksheet_portfolio.set_footer(margin=0.2)
        worksheet_portfolio.center_horizontally()
        
        
        
        worksheet_portfolio = self.workbook.add_worksheet('LP현황')
        
        worksheet_portfolio.write('E4','(단위 : 백만원)',self.text_right)
        worksheet_portfolio.merge_range('C5:C10','ETF',self.bold_all2)
        worksheet_portfolio.merge_range('D5:D6','LP잔고합',self.bold_all2)
        worksheet_portfolio.merge_range('D7:D8','개인잔고합',self.bold_all2)  
        worksheet_portfolio.merge_range('D9:D10','설정액',self.bold_all2) 
        worksheet_portfolio.write('G4','전일 대비',self.text_right)
        worksheet_portfolio.write('I4','연초 대비',self.text_right)
        
        worksheet_portfolio.merge_range('C15:C17','구분',self.bold_all2)
        worksheet_portfolio.merge_range('D15:D17','Code',self.bold_upline)
        worksheet_portfolio.merge_range('E15:E17','펀    드    명',self.bold_upline)
        worksheet_portfolio.merge_range('F15:F17','운용역',self.bold_upline)
        worksheet_portfolio.merge_range('G15:G17','설정일',self.bold_upline)
        worksheet_portfolio.merge_range('H15:H17','결산일',self.bold_exleft)
        # worksheet_portfolio.write('F4','전일 대비',self.text1)
        
        
        worksheet_portfolio.merge_range('I15:O16','사무수탁 정보 (사무수탁, 보수(BP))',self.bold_all2)
        worksheet_portfolio.write('I17','총보수',self.bold_all2) 
        worksheet_portfolio.write('J17','운용보수',self.bold_all2)
        worksheet_portfolio.write('K17','AP/LP보수',self.bold_all2)
        worksheet_portfolio.write('L17','수탁사',self.bold_all2)
        worksheet_portfolio.write('M17','수탁보수',self.bold_all2)
        worksheet_portfolio.write('N17','사무사',self.bold_all2)
        worksheet_portfolio.write('O17','사무보수',self.bold_all2)
        
        # worksheet_portfolio.merge_range('F7:G8', nav1['VAL'][4]-nav1['VAL'][0],self.bold_red) ##하루 사이 NAV 증감
        
        ##수익률부분
        netf=len(df_fee)
        
        worksheet_portfolio.write('O'+str(18+netf),'잔고합(억 원)',self.bold_all2)
        worksheet_portfolio.write('O'+str(19+netf),'LP보수합      (1Y, 원)',self.text_wrap2)
        
        

        # Column,row width 정의
        worksheet_portfolio.set_column('A:A', 3.25)
        worksheet_portfolio.set_column('B:B', 2.5)
        worksheet_portfolio.set_column('C:C', 17.5)
        worksheet_portfolio.set_column('D:D', 14.13)
        worksheet_portfolio.set_column('E:E', 43.5)
        worksheet_portfolio.set_column('F:H', 14.13)
        worksheet_portfolio.set_column('I:K', 12.00)
        worksheet_portfolio.set_column('L:L', 17.50)        
        worksheet_portfolio.set_column('M:N', 12.00)        
        worksheet_portfolio.set_column('O:O', 14.50)
        worksheet_portfolio.set_column('P:AF', 18.50)
        worksheet_portfolio.set_column('AG:BW', 13.00)
        worksheet_portfolio.set_row(0,21.75)
        worksheet_portfolio.set_row(1,21.75)
        worksheet_portfolio.set_row(2,21.75)
        worksheet_portfolio.set_row(3,21.75)
        worksheet_portfolio.set_row(4,21.75)
        worksheet_portfolio.set_row(5,21.75)
        worksheet_portfolio.set_row(6,21.75)
        worksheet_portfolio.set_row(7,21.75)
        worksheet_portfolio.set_row(8,21.75)
        worksheet_portfolio.set_row(9,21.75)
        worksheet_portfolio.set_row(10,21.75)
        worksheet_portfolio.set_row(11,21.75)
        worksheet_portfolio.set_row(12,21.75)
        worksheet_portfolio.set_row(13,21.75)
        worksheet_portfolio.set_row(14,21.75)
        worksheet_portfolio.set_row(15,21.75)
        worksheet_portfolio.set_row(16,21.75)
        worksheet_portfolio.set_row(17,22.50)
        worksheet_portfolio.set_row(18,22.50)
        worksheet_portfolio.set_row(19,22.50)
        worksheet_portfolio.set_row(20,22.50)
        worksheet_portfolio.set_row(21,22.50)
        worksheet_portfolio.set_row(22,22.50)
        worksheet_portfolio.set_row(23,22.50)
        worksheet_portfolio.set_row(24,22.50)
        worksheet_portfolio.set_row(25,22.50)
        worksheet_portfolio.set_row(26,22.50)
        worksheet_portfolio.set_row(27,22.50)
        worksheet_portfolio.set_row(28,22.50)
        worksheet_portfolio.set_row(29,22.50)
        worksheet_portfolio.set_row(30,22.50)
        worksheet_portfolio.set_row(31,22.50)
        worksheet_portfolio.set_row(32,22.50)
        worksheet_portfolio.set_row(33,22.50)
        worksheet_portfolio.set_row(34,22.50)
        worksheet_portfolio.set_row(35,22.50)
        worksheet_portfolio.set_row(36,22.50)
        worksheet_portfolio.set_row(37,22.50)
        worksheet_portfolio.set_row(38,22.50)
        worksheet_portfolio.set_row(39,22.50)
        worksheet_portfolio.set_row(40,22.50)
        worksheet_portfolio.set_row(41,22.50)
        worksheet_portfolio.set_row(42,22.50)
        worksheet_portfolio.set_row(43,22.50)
        worksheet_portfolio.set_row(44,22.50)
        worksheet_portfolio.set_row(45,22.50)
        worksheet_portfolio.set_row(46,22.50)
        worksheet_portfolio.set_row(47,22.50)
        worksheet_portfolio.set_row(48,22.50)
        worksheet_portfolio.set_row(49,22.50)
        worksheet_portfolio.set_row(50,22.50)
        worksheet_portfolio.set_row(51,22.50)
        worksheet_portfolio.set_row(52,22.50)
        worksheet_portfolio.set_row(53,22.50)
        worksheet_portfolio.set_row(54,22.50)
        worksheet_portfolio.set_row(55,22.50)
        worksheet_portfolio.set_row(56,22.50)
        worksheet_portfolio.set_row(57,22.50)
        worksheet_portfolio.set_row(58,22.50)
        worksheet_portfolio.set_row(59,22.50)
        worksheet_portfolio.set_row(60,22.50)
        worksheet_portfolio.set_row(61,22.50)
        worksheet_portfolio.set_row(62,22.50)
        worksheet_portfolio.set_row(63,22.50)
        worksheet_portfolio.set_row(64,22.50)
        worksheet_portfolio.set_row(65,22.50)
        worksheet_portfolio.set_row(66,22.50)
        worksheet_portfolio.set_row(67,22.50)
        worksheet_portfolio.set_row(68,22.50)
        worksheet_portfolio.set_row(69,22.50)
        worksheet_portfolio.set_row(70,22.50)
        worksheet_portfolio.set_row(71,22.50)
        worksheet_portfolio.set_row(72,22.50)
        worksheet_portfolio.set_row(73,22.50)
        worksheet_portfolio.set_row(74,22.50)
        worksheet_portfolio.set_row(75,22.50)
        worksheet_portfolio.set_row(76,22.50)
        worksheet_portfolio.set_row(77,22.50)
        worksheet_portfolio.set_row(78,22.50)
        worksheet_portfolio.set_row(79,22.50)
        worksheet_portfolio.set_row(80,22.50)
        worksheet_portfolio.set_row(81,22.50)
        worksheet_portfolio.set_row(82,22.50)
        worksheet_portfolio.set_row(83,22.50)
        worksheet_portfolio.set_row(84,22.50)
        worksheet_portfolio.set_row(85,22.50)
        worksheet_portfolio.set_row(86,22.50)
        worksheet_portfolio.set_row(87,22.50)
        worksheet_portfolio.set_row(88,22.50)
        worksheet_portfolio.set_row(89,22.50)
        worksheet_portfolio.set_row(90,22.50)
        worksheet_portfolio.set_row(91,22.50)
        worksheet_portfolio.set_row(92,22.50)
        worksheet_portfolio.set_row(93,22.50)
        worksheet_portfolio.set_row(94,22.50)
        worksheet_portfolio.set_row(95,22.50)
        worksheet_portfolio.set_row(96,22.50)
        worksheet_portfolio.set_row(97,22.50)
        worksheet_portfolio.set_row(98,22.50)
        worksheet_portfolio.set_row(99,22.50)
        worksheet_portfolio.set_row(100,22.50)
        worksheet_portfolio.set_row(101,22.50)
        worksheet_portfolio.set_row(102,22.50)
        worksheet_portfolio.set_row(103,22.50)
        worksheet_portfolio.set_row(104,22.50)
        worksheet_portfolio.set_row(105,22.50)
        worksheet_portfolio.set_row(106,22.50)  
        worksheet_portfolio.set_row(107,22.50)  
        worksheet_portfolio.set_row(108,22.50)
        worksheet_portfolio.set_row(109,22.50)
        worksheet_portfolio.set_row(110,22.50)
        worksheet_portfolio.set_row(111,22.50)  
        worksheet_portfolio.set_row(112,22.50)
        worksheet_portfolio.set_row(113,22.50)
        worksheet_portfolio.set_row(114,22.50) # LP보수합 행 (신규상장)
        worksheet_portfolio.set_row(115,22.50)
        worksheet_portfolio.set_row(116,22.50)
        worksheet_portfolio.set_row(117,41.25)
        worksheet_portfolio.set_row(118,22.50)
        worksheet_portfolio.set_row(119,22.50)
        worksheet_portfolio.set_row(120,22.50)
        worksheet_portfolio.set_row(121,22.50)
        worksheet_portfolio.set_row(122,22.50)
        worksheet_portfolio.set_row(123,22.50)
        worksheet_portfolio.set_row(124,22.50)
        worksheet_portfolio.set_row(125,22.50)
        worksheet_portfolio.set_row(126,22.50)
        worksheet_portfolio.set_row(127,22.50)
        worksheet_portfolio.set_row(128,22.50)
        worksheet_portfolio.set_row(129,22.50)
        worksheet_portfolio.set_row(130,22.50)
        worksheet_portfolio.set_row(131,22.50)
        worksheet_portfolio.set_row(132,22.50)
        worksheet_portfolio.set_row(133,22.50)
        worksheet_portfolio.set_row(134,22.50)
        worksheet_portfolio.set_row(135,22.50)
        worksheet_portfolio.set_row(136,22.50)
        worksheet_portfolio.set_row(137,22.50)
        worksheet_portfolio.set_row(138,22.50)
        worksheet_portfolio.set_row(139,22.50)
        worksheet_portfolio.set_row(140,22.50)
        worksheet_portfolio.set_row(141,22.50)
        worksheet_portfolio.set_row(142,22.50)
        worksheet_portfolio.set_row(143,22.50)
        worksheet_portfolio.set_row(144,22.50)
        worksheet_portfolio.set_row(145,22.50)
        worksheet_portfolio.set_row(146,22.50)
        worksheet_portfolio.set_row(147,22.50)
        worksheet_portfolio.set_row(148,22.50)
        worksheet_portfolio.set_row(149,22.50)
        worksheet_portfolio.set_row(150,22.50)
        


        #엑셀 서식
        worksheet_portfolio.conditional_format('C19:C'+str(16+netf),{'type': 'no_blanks','format':self.bold_LR2})  # |  |
        worksheet_portfolio.conditional_format('C19:C'+str(16+netf),{'type': 'blanks','format':self.bold_LR2})
        
        
        
        ## Column 제목 입력 (04.09)
        header_name = ['LP 잔고 현황']
        worksheet_portfolio.write_row(1, 2, header_name, self.bold)
        worksheet_portfolio.write('C18','ETF',self.bold_LRU)
        worksheet_portfolio.write('C19',int(netf),self.bold3)
        worksheet_portfolio.conditional_format('C'+str(17+netf),{'type': 'blanks', 'format': self.bold_LRB2})
        
        
        worksheet_portfolio.conditional_format('D'+str(17+netf)+":G"+str(17+netf),{'type': 'no_blanks','format':self.bold_bot3})
        worksheet_portfolio.conditional_format("H"+str(17+netf),{'type': 'no_blanks','format':self.bold_RB2})   
        worksheet_portfolio.conditional_format("H18",{'type': 'blanks','format':self.bold_RT})   
        worksheet_portfolio.conditional_format("H18",{'type': 'no_blanks','format':self.bold_RT}) 
        worksheet_portfolio.conditional_format("H19:H"+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format("H19:H"+str(16+netf),{'type': 'blanks','format':self.bold_right})
        
        worksheet_portfolio.conditional_format('J'+str(17+netf)+":N"+str(17+netf),{'type': 'no_blanks','format':self.bold_bot3})
        worksheet_portfolio.conditional_format("I"+str(17+netf),{'type': 'no_blanks','format':self.bold_LRB4})     
        worksheet_portfolio.conditional_format("O19:O"+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format("O19:O"+str(16+netf),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format("O18",{'type': 'blanks','format':self.bold_RT})   
        worksheet_portfolio.conditional_format("O18",{'type': 'no_blanks','format':self.bold_RT})  
        worksheet_portfolio.conditional_format("O"+str(17+netf),{'type': 'no_blanks','format':self.bold_RB}) 
        worksheet_portfolio.conditional_format("O"+str(17+netf),{'type': 'blanks','format':self.bold_RB})         
        
        worksheet_portfolio.conditional_format("I19:I"+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format("I19:I"+str(16+netf),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format("I18",{'type': 'blanks','format':self.bold_RT})   
        worksheet_portfolio.conditional_format("I18",{'type': 'no_blanks','format':self.bold_RT}) 
        
        
        

        #현황자료 입력 (LP)
        worksheet_portfolio.write_column('D18', df_fee['Code'], self.text2)
        worksheet_portfolio.write_column('E18', df_fee['펀드명'], self.text3)
        worksheet_portfolio.write_column('F18', df_fee['운용역'], self.text)
        worksheet_portfolio.write_column('G18', df_fee['설정일'], self.text)
        worksheet_portfolio.write_column('H18', df_fee['결산일'], self.text)      
        worksheet_portfolio.write_column('I18', df_fee['총보수']*10, self.text)
        worksheet_portfolio.write_column('J18', df_fee['운용보수']*10, self.text)
        worksheet_portfolio.write_column('K18', df_fee['판매보수']*10, self.text)
        worksheet_portfolio.write_column('L18', df_fee['수탁사'], self.text)
        worksheet_portfolio.write_column('M18', df_fee['수탁보수']*10, self.text)
        worksheet_portfolio.write_column('N18', df_fee['사무사'], self.text)
        worksheet_portfolio.write_column('O18', df_fee['사무보수']*10, self.text)
 
        
        # LP별 잔고 데이터 처리 및 엑셀 삽입
        ap_list = df_AP.drop_duplicates(subset=['LP'], inplace=False, ignore_index=True)['LP'].values.tolist()
        ap_list.sort()
        
        # print(ap_list)
        AP_table = pd.DataFrame('',columns=ap_list, index=df_fee['Code'])
        for index, row in df_AP.iterrows():
            fund_cd = row['FUND_CD']
            lp = row['LP']
            balance = float(row['잔고'])
            # LP열 값이 AP_table의 column명과 일치할 때, 해당 잔고 값을 넣어줌
            AP_table.loc[fund_cd, lp] = round(balance/100000000, 2)
        flg = False
        for col in AP_table.columns:
            for i in AP_table[col]:
                if (i != 0 and i != ''):
                   flg = True    # 제대로 된 값이 들어있으면
                   break
            if flg == False:
                AP_table.drop(col, axis=1, inplace=True)
            flg = False           
        AP_table_0 = AP_table.replace('', 0, inplace=False)
        
        # print(AP_table)
        
        # 전일 LP별 잔고 데이터 처리 및 엑셀 삽입
        ap_list1 = df_AP_PDAY.drop_duplicates(subset=['LP'], inplace=False, ignore_index=True)['LP'].values.tolist()
        ap_list1.sort()
        # print(ap_list)
        AP_table1 = pd.DataFrame('',columns=ap_list1, index=df_fee['Code'])
        for index, row in df_AP_PDAY.iterrows():
            fund_cd = row['FUND_CD']
            lp = row['LP']
            balance = float(row['잔고'])
            # LP열 값이 AP_table의 column명과 일치할 때, 해당 잔고 값을 넣어줌
            AP_table1.loc[fund_cd, lp] = round(balance/100000000, 2)
        flg = False
        for col in AP_table1.columns:
            for i in AP_table1[col]:
                if (i != 0 and i != ''):
                   flg = True    # 제대로 된 값이 들어있으면
                   break
            if flg == False:
                AP_table1.drop(col, axis=1, inplace=True)
            flg = False           
        AP_table_PDAY_0 = AP_table1.replace('', 0, inplace=False)
        
        
        
        
        # 그전영업일 LP잔고 데이터 처리
        df_new = pd.merge(df_AP, df_AP_PDAY, on =['FUND_CD','LP'], suffixes=('_tday', '_pday'))
        df_new['AP_CNT'] = df_new['AP_CNT_tday'] - df_new['AP_CNT_pday']
        df_new['잔고'] = df_new['AP_CNT'] * df_new['STD_PRC_tday']
        
        df_diff = df_new[['FUND_CD', 'LP', 'AP_CNT', '잔고']]
        
        ap_list2 = df_diff.drop_duplicates(subset=['LP'], inplace=False, ignore_index=True)['LP'].values.tolist()
        ap_list2.sort()
        AP_table2 = pd.DataFrame('',columns=ap_list2, index=df_fee['Code'])
        for index, row in df_diff.iterrows():
            fund_cd = row['FUND_CD']
            lp = row['LP']
            balance = float(row['잔고'])
            # LP열 값이 AP_table의 column명과 일치할 때, 해당 잔고 값을 넣어줌
            AP_table2.loc[fund_cd, lp] = round(balance/100000000, 2)
        flg = False
        for col in AP_table2.columns:
            for i in AP_table2[col]:
                if (i != 0 and i != ''):
                   flg = True    # 제대로 된 값이 들어있으면
                   break
            if flg == False:
                AP_table2.drop(col, axis=1, inplace=True)
            flg = False           
        AP_diff = AP_table2.replace('', 0, inplace=False)
        
        # print(AP_diff)
        
        # 전영업일과 잔고 주수가 달라지면 이를 반영하여 차이를 LP잔고금액 옆에 반영 
        for row in AP_diff.index:
            for col in AP_diff.columns:
                if AP_diff.at[row, col] != 0:
                    if AP_diff.at[row,col] > 0: AP_table.at[row, col] = str(AP_table.at[row, col]) + f" / (+{AP_diff.at[row, col]})"
                    else: AP_table.at[row, col] = str(AP_table.at[row, col]) + f" / ({AP_diff.at[row, col]})"
                    
        
        alps = ['P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU','AV','AW','AX', 'AY', 'AZ']
        i=0
        for lp, cols in AP_table.items():
            last = alps[i]
            cell = last + str(18)
            name_cell = last + str(17)
            sum_cell = last + str(18+netf)
            LP_cell = last + str(19+netf)
            worksheet_portfolio.write(name_cell, lp, self.bold_all2)
            worksheet_portfolio.write_column(cell, AP_table[lp], self.number_lp)
            worksheet_portfolio.write(sum_cell, AP_table_0[lp].sum(), self.number_lp)
            
            lp_row = df_lp_sum[df_lp_sum['AP명'] == lp]
            if not lp_row.empty: lp_sum = lp_row.iloc[0]['보수합']
            else: lp_sum = 0
            # print(lp_sum)
            worksheet_portfolio.write(LP_cell, lp_sum, self.number_int5)   # LP 보수합 (연 환산)
            
            
            worksheet_portfolio.conditional_format(last+"19:"+last+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
            worksheet_portfolio.conditional_format(last+"19:"+last+str(16+netf),{'type': 'blanks','format':self.bold_right})
            worksheet_portfolio.conditional_format(last+"18",{'type': 'blanks','format':self.bold_RT})   
            worksheet_portfolio.conditional_format(last+"18",{'type': 'no_blanks','format':self.bold_RT})
            
            i+=1
            
        
        worksheet_portfolio.merge_range('P15:'+last+str(16),'LP별 잔고(억 원)',self.bold_all2)
        worksheet_portfolio.merge_range('E5:E6',AP_table_0.values.sum()*100,self.bold_all)
        worksheet_portfolio.merge_range('E7:E8', df_p_amt['개인잔고'].sum()/1000000, self.bold_all)
        worksheet_portfolio.merge_range('E9:E10',nav1['VAL'][5],self.bold_all)

        worksheet_portfolio.merge_range('F5:G6', AP_table_0.values.sum()*100 - (df_AP_PDAY['잔고'].sum()/1000000),self.bold_red) ##하루 사이 NAV 증감
        worksheet_portfolio.merge_range('F7:G8', (df_p_amt['개인잔고'].sum()-df_p_amt['개인잔고_PDAY'].sum())/1000000,self.bold_red) ##하루 사이 NAV 증감
        worksheet_portfolio.merge_range('F9:G10', nav1['VAL'][4]-nav1['VAL'][0],self.bold_red) ##하루 사이 NAV 증감

        worksheet_portfolio.merge_range('H5:I6', AP_table_0.values.sum()*100 - (777165131842/1000000), self.bold_red)  ##연초에 값 바꿔줘야함    -- 연초 AP잔고  777165131842 
        worksheet_portfolio.merge_range('H7:I8', (df_p_amt['개인잔고'].sum()-5530919999331)/1000000, self.bold_red)  ##연초에 값 바꿔줘야함    -- 연초 개인잔고  5530919999331 
        worksheet_portfolio.merge_range('H9:I10',nav1['VAL'][4]-13125624.60,self.bold_red) ##연초에 값 바꿔줘야함                                  -- 연초 NAV
        
        worksheet_portfolio.conditional_format('P'+str(17+netf)+":"+last+str(17+netf),{'type': 'no_blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format('P'+str(17+netf)+":"+last+str(17+netf),{'type': 'blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format('P'+str(18+netf)+":"+last+str(18+netf),{'type': 'no_blanks','format':self.bold_all2})
        worksheet_portfolio.conditional_format('P'+str(18+netf)+":"+last+str(18+netf),{'type': 'blanks','format':self.bold_all2})   
        worksheet_portfolio.conditional_format('P'+str(19+netf)+":"+last+str(19+netf),{'type': 'no_blanks','format':self.bold_all2})
        worksheet_portfolio.conditional_format('P'+str(19+netf)+":"+last+str(19+netf),{'type': 'blanks','format':self.bold_all2})   
        
        c_last = alps[i]
        worksheet_portfolio.merge_range(c_last+'15:'+c_last+'17','LP잔고      (억 원)',self.text_wrap1)
        sum1 = AP_table_0.sum(axis=1)
        sum2 = AP_table_PDAY_0.sum(axis=1)
        
        row_sum = sum1.tolist()
        
        worksheet_portfolio.write_column(c_last+'18', row_sum, self.number_lp)
        worksheet_portfolio.write(c_last+str(18+netf), sum(row_sum), self.number_lp)
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'blanks','format':self.bold_RT})   
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'no_blanks','format':self.bold_RT})  
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'no_blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format(c_last+str(18+netf),{'type': 'no_blanks','format':self.bold_all2})
        worksheet_portfolio.conditional_format(c_last+str(18+netf),{'type': 'blanks','format':self.bold_all2})
        sum_cell1 = c_last
        
        
        
        diff = sum1 - sum2
        diff_sum = diff.tolist()
        
        c_last = alps[i+1]
        worksheet_portfolio.merge_range(c_last+'15:'+c_last+'17','LP잔고         전일대비        (억 원)',self.text_wrap1)
        worksheet_portfolio.write_column(c_last+'18', diff_sum, self.number_lp)
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'blanks','format':self.bold_RT})   
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'no_blanks','format':self.bold_RT})  
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'no_blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'blanks','format':self.bold_RB})
        
        
        c_last = alps[i+2]
        worksheet_portfolio.merge_range(c_last+'15:'+c_last+'17','LP잔고         비율(%)',self.text_wrap1)
        worksheet_portfolio.write_column(c_last+'18', row_sum/(df_fee['NAV']/100000000)*100, self.number_lp)
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'blanks','format':self.bold_RT})   
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'no_blanks','format':self.bold_RT})  
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'no_blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'blanks','format':self.bold_RB})
        perc_cell1 = c_last
        
        c_last = alps[i+3]
        worksheet_portfolio.merge_range(c_last+'15:'+c_last+'17','개인잔고     (억 원)',self.text_wrap1)
        worksheet_portfolio.write_column(c_last+'18', df_p_amt['개인잔고']/100000000, self.number_lp)
        worksheet_portfolio.write(c_last+str(18+netf), df_p_amt['개인잔고'].sum()/100000000, self.number_lp)
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'blanks','format':self.bold_RT})   
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'no_blanks','format':self.bold_RT})  
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'no_blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format(c_last+str(18+netf),{'type': 'no_blanks','format':self.bold_all2})
        worksheet_portfolio.conditional_format(c_last+str(18+netf),{'type': 'blanks','format':self.bold_all2})
        sum_cell2 = c_last
        
        c_last = alps[i+4]
        worksheet_portfolio.merge_range(c_last+'15:'+c_last+'17','개인잔고      비율(%)',self.text_wrap1)
        worksheet_portfolio.write_column(c_last+'18', df_p_amt['개인잔고']/df_fee['NAV']*100, self.number_lp)
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'no_blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"19:"+c_last+str(16+netf),{'type': 'blanks','format':self.bold_right})
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'blanks','format':self.bold_RT})   
        worksheet_portfolio.conditional_format(c_last+"18",{'type': 'no_blanks','format':self.bold_RT})  
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'no_blanks','format':self.bold_RB})
        worksheet_portfolio.conditional_format(c_last+str(17+netf),{'type': 'blanks','format':self.bold_RB})
        perc_cell2 = c_last
        
        
        # 프린트할 마지막 column
        p_last = alps[i+5]
        
        #페이지설정
        worksheet_portfolio.freeze_panes(17,0)
        worksheet_portfolio.fit_to_pages(1,1)
        #worksheet_portfolio.print_area('A1:W76')
        #worksheet_portfolio.set_h_pagebreaks([7+nall])
        worksheet_portfolio.set_margins(left=0,right=0,top=0.25, bottom=0.25) 
        worksheet_portfolio.set_header(margin=0.45)
        worksheet_portfolio.set_footer(margin=0.2)
        worksheet_portfolio.center_horizontally()
        

        pass

    
def execute_tool():
    
    def send_mail():
        global start_dt
        global path
        
        f='//192.168.194.12/data/ETF/Woosung/업무/Daily/db화작업용/'+str(path)
        to = "k0wsws@koreainvestment.com"
        subject = str(start_dt)+' '+'운용현황'
        content = """
        안녕하세요 ETF운용부 김우성입니다.
        <p>오늘 아침 작성한 운용현황 파일 첨부드립니다.</p>
        <p>감사합니다.</p>
        <p>김우성 드림</p>
        """
        # Outlook Object Model 불러오기
        new_Mail = win32com.client.Dispatch("Outlook.Application").CreateItem(0)
        
        # 메일 수신자
        new_Mail.To = to
        # 메일 참조
        # new_Mail.CC = "mail-add-for-cc@testadd.com"    
        # 메일 제목
        new_Mail.Subject = subject
        # 메일 내용
        new_Mail.HTMLBody = content
    
        # 첨부파일 추가
    
        new_Mail.Attachments.Add(f)
    
        # 메일 발송
        new_Mail.Send()
        
        #info_mail()
        
    def print_excel():
        global start_dt
        global path
        global nall
        
        
        path2=os.getcwd().replace('\'','\\')+'\\'
        excel_path=os.path.abspath(path2+str(path))
        
        excel2 = win32com.client.Dispatch("Excel.Application")
        excel2.Visible = 0 
        wb1 = excel2.Workbooks.Open(excel_path)
        ws1 = wb1.Worksheets['운용현황']
        
        #ws.PageSetup.Range(Start=0, End=10)
        ws1.PageSetup.Orientation = 2  # 1 이면 세로 2면 가로
        ws1.PageSetup.PaperSize = 8
        ws1.PageSetup.PrintArea = 'A1:AH'+str(18+nall)
        
        # 인쇄
        for i in range(int(entry2.get())):
            ws1.PrintOut()
        
        info_print()
        
    
    def info():
        messagebox.showinfo("완료","파일작성 완료")
    
    def info_print():
        messagebox.showinfo("완료","인쇄 완료")
            
      
    def generate():
            global start_dt
            global path
            global last
            global c_last
            global sum_cell1
            global sum_cell2
            global perc_cell1
            global perc_cell2
            global netf
        
            start_dt=entry1.get()

        
            start_time = time.time()
        
            status = status_generation(start_dt)
             
            end_time = time.time()
            
            path2=os.getcwd().replace('\'','\\')+'\\'
            excel_path=os.path.abspath(path2+str(path))
            
            
            ### 조건부 서식 추가
            wb = op.load_workbook(excel_path, data_only=True)
            ws = wb['운용현황']
            max_row = ws.max_row
            
            cells = ['D','E','F','G','H','I', 'J','K','L','M','N', 'O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AG']
            for row_index in range(18, max_row+1):
                if row_index % 2 == 0:  ## 홀수줄이면색칠하기
                    for c in cells:
                        cell = c+str(row_index)
                        ws[cell].fill = PatternFill(fill_type='solid', fgColor="E5E5E5")
                        # ws[cell].border = Border(bottom = Side(border_style="dashDot", color='F20000'))
            
            
            li = ['N','O','P','Q','R','S','T','U']
            for row_index in range(18, max_row+1):
                for col_index in li:
                    cell = col_index+str(row_index)
                    val = ws[cell].value
                    if val is None: pass
                    elif float(val) > 0:
                        ws[cell].font = Font(size=16, color='FF0000')
                        if float(val) > 20:
                            ws[cell].fill = PatternFill(fill_type='solid', fgColor="FFFF00")
                    elif float(val) < 0:
                        ws[cell].font = Font(size=16, color="0000FF")
                        if float(val) < -20:
                            ws[cell].fill = PatternFill(fill_type='solid', fgColor="FFFF00")
                        
            li2 = ['V','W','X','Y','Z','AA','AB','AC']
            for row_index in range(18, max_row+1):
                for col_index in li2:
                    cell = col_index+str(row_index)
                    val = ws[cell].value
                    if val is None: pass
                    elif float(val) > 0:
                        ws[cell].font = Font(size=16, color='FF0000')
                    elif float(val) < 0:
                        ws[cell].font = Font(size=16, color="0000FF")
                  
                    
            ws2 = wb['LP현황']
            max_row = ws2.max_row
           
            cells = ['D','E','F','G','H','I', 'J','K','L','M','N', 'O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ',]
            max_cell = ['O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ',]
            for row_index in range(18, max_row+1):
                if row_index == max_row-1:
                    for mc in max_cell:
                        mcell = mc+str(row_index)       ## max_row-1번째 row
                        ws2[mcell].fill = PatternFill(fill_type='solid', fgColor="FFF1B7")
                        mcell2 = mc+str(row_index+1)     ## max_row번째 row
                        ws2[mcell2].fill = PatternFill(fill_type='solid', fgColor="FFF1B7")
                        if mc == last: break        #last = 'AF' 
                    break
                if row_index % 2 == 1:  ## 홀수줄이면색칠하기
                    for c in cells:
                        cell = c+str(row_index)
                        ws2[cell].fill = PatternFill(fill_type='solid', fgColor="E7E7E7")
                        if c == c_last: break
            
            c1 = sum_cell1 + str(18+netf)
            ws2[c1].fill = PatternFill(fill_type='solid', fgColor="FFFF00")
            c2 = sum_cell2 + str(18+netf)                        
            ws2[c2].fill = PatternFill(fill_type='solid', fgColor="FFFF00")
            
            
            for row_index in range(18, 18+netf):
                cell = perc_cell1+str(row_index)
                val = ws2[cell].value
                if val is None: pass
                elif float(val) >= 40:
                    ws2[cell].fill = PatternFill(fill_type='solid', fgColor="FFE1E1")
                                          
                        
            wb.save(excel_path)
            wb.close()
            
            print('\n\nThe execution time in seconds: ', end_time - start_time)
            
            excel2 = win32com.client.Dispatch("Excel.Application")
            excel2.Visible = 1 
            wb1 = excel2.Workbooks.Open(excel_path)
            
            info()
            
      
    tk = Tk()
    tk.title('운용현황')
  
    
    label1 = Label(tk,text='운용현황날짜',relief="ridge").grid(row=0,column=1,columnspan=1)
    label2 = Label(tk,text='인쇄매수',relief="ridge").grid(row=0,column=2,columnspan=1)
    
    # 각 단위 입력받는 부분 만들기
    entry1 = Entry(tk)
    entry1.grid(row=1,column=1)
    entry2 = Entry(tk)
    entry2.grid(row=1,column=2)
 
    btn1 = Button(tk,text='파일생성',bg='black',fg='white',command=generate).grid(row=2,column=1)
    btn2 = Button(tk,text='인쇄하기',bg='black',fg='white',command=print_excel).grid(row=2,column=2)
    
    tk.mainloop()    
    

def main():
    execute_tool()
    
    conn.close()

if __name__ == "__main__":
    main()