# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 19:53:31 2024

@author: USER
"""

from dash import html
import dash_bootstrap_components as dbc
from datetime import datetime, timedelta


today = datetime.now()
 
# 미리 정의된 일정
schedule_data = {
    4: ["일본"]
}


# 주중 캘린더 생성 (토, 일 제외, 지정된 일정 추가)
def generate_week_calendar(start_date):
    days = []
    current_day = start_date
    weekdays_count = 0

    # 월 이름 표시
    month_name = current_day.strftime("%B")  # October 같은 형식으로 월 표시
    days.append(
        dbc.Col([
            html.Div(month_name, style={
                "textAlign": "center", 
                "fontSize": "24px", 
                "fontWeight": "bold", 
                "marginBottom": "20px"})  # 상단에 월 표시
        ], width=12)
    )
    
    # 주말을 제외하고 5일간의 일정 생성
    while weekdays_count < 5:
        if current_day.weekday() < 5:  # 월=0, 화=1, ..., 금=4
            day_name = current_day.strftime("%a")  # 요일 형식으로 변환 (Mon, Tue 등)
            day_number = int(current_day.strftime("%d"))  # 날짜 형식을 정수로 변환
            day_label = f"{day_number:02d} ({day_name})"  # 날짜 형식 "14 (Mon)"처럼 변환
            
            # 오늘 날짜는 강조된 색상 처리
            day_color = "#ffebcc" if current_day == today else "#f9f9f9"
            border_color = "#ffcc80" if current_day == today else "#ddd"
            
            # 일정 데이터가 있는지 확인
            schedule = schedule_data.get(day_number, [])
            schedule_display = [html.Div(country, style={"marginTop": "5px"}) for country in schedule]  # 일정 표시
            
            days.append(
                dbc.Col([
                    html.Div(
                        [
                            html.Div(day_label, style={"textAlign": "center", "fontWeight": "bold", "fontSize": "18px"}),  # 날짜
                            html.Div(schedule_display, style={"textAlign": "center", "fontSize": "16px", "marginTop": "15px"}),  # 일정
                        ],
                        style={
                            "border": f"2px solid {border_color}", 
                            "borderRadius": "10px",
                            "padding": "10px",
                            "minHeight": "120px",  # 높이 유지
                            "backgroundColor": day_color,
                            "boxShadow": "2px 2px 10px rgba(0,0,0,0.1)",  # 음영 추가
                            "margin": "5px"
                        }
                    )
                ], width=2, style={"marginBottom": "20px"})  # 일정 간 간격 추가
            )
            
            weekdays_count += 1
        
        # 다음 날로 이동
        current_day += timedelta(days=1)
    
    return dbc.Row(days, justify="center")