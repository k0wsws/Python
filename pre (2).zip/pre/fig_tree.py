# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 18:52:00 2024

@author: USER
"""
import plotly.graph_objs as go
import pandas as pd
from plotly.subplots import make_subplots
from pre.get_data import etf_sector


etf_sector = etf_sector()
finviz_colorscale = [
    [0.0, '#ec413f'],  # 매우 낮은 값 (음수)
    [0.5, '#4f4554'],  # 중간 값 (0%)
    [1.0, '#46ad57']   # 매우 높은 값 (양수)
]

finviz_colorscale = [
    [0.0, '#ec413f'],  # 매우 낮은 값 (음수)
    [0.5, '#4f4554'],  # 중간 값 (0%)
    [1.0, 'blue']   # 매우 높은 값 (양수)
]


def fig_tree(df_kr,df_gl,df_krstk,list_us_stk):
    
    # diff 컬럼의 최소값과 최대값을 계산
    diff_min = -3
    
    diff_max = 3
    tickvals = [diff_min, 0, diff_max]
    ticktext = [f'{diff_min:.1f}%', '0%', f'{diff_max:.1f}%']
    # 서브플롯 생성 (1행 2열) - 'domain' 타입 사용
    fig = make_subplots(rows=2, cols=2, vertical_spacing=0.05, subplot_titles=("국내 ETF 트리맵", "글로벌 ETF 트리맵","국내 주식 트리맵", "미국 주식 트리맵"), 
                        specs=[[{'type': 'domain'}, {'type': 'domain'}], [{'type': 'domain'}, {'type': 'domain'}]])
    
    
    df_kr=pd.merge(df_kr,etf_sector,on='ETF_CD',how='inner')
    labels = df_kr['SECTOR'].unique().tolist() + df_kr['ETF_NM'].tolist()  # 카테고리와 하위 항목 레이블 결합
    parents = [''] * len(df_kr['SECTOR'].unique()) + df_kr['SECTOR'].tolist()  # 카테고리는 부모가 없고, 하위 항목은 카테고리가 부모
    
    # values와 colors 데이터 준비 (카테고리에는 0 값 할당)
    values = [0] * len(df_kr['SECTOR'].unique()) + df_kr['AUM'].tolist()
    colors = [0] * len(df_kr['SECTOR'].unique()) + df_kr['diff'].tolist()
    texts=  [''] * len(df_kr['SECTOR'].unique()) + df_kr['diff'].fillna(0).astype(str).tolist()
    
    fig.add_trace(
        go.Treemap(
            labels=labels,
            parents=parents,  # 최상위 노드 (부모가 없는 노드)
            values=values,
            marker=dict(
            colors=colors,
            colorscale=finviz_colorscale,  # 빨강-파랑 색상 스케일
            cmin=diff_min,  # 색상 범위 최소값을 diff 최소값으로 설정
        cmax=diff_max,  # 색상 범위 최대값을 diff 최대값으로 설정
        colorbar=dict(
            titleside="bottom",  # 타이틀 위치
            ticks="outside",  # 틱을 컬러바 밖으로 설정
            tickvals=tickvals,  # 동적으로 계산된 틱 값 사용
            ticktext=ticktext,  # 동적으로 계산된 틱 텍스트 사용
            tickmode="array",  # 틱 모드를 'array'로 설정하여 맞춤형 틱 값 사용
            lenmode="fraction",  # 컬러바의 길이 비율로 설정
            #len=0.75,  # 컬러바의 길이를 전체 크기의 75%로 설정
            thickness=10,     # 컬러바의 두께(픽셀)
             len=0.3,          # 컬러바의 길이 (비율)
             orientation="h",  # 수평 방향으로 컬러바 설정
             xanchor="center",  # 컬러바의 위치를 중앙으로 설정
             x=0.5,            # x 좌표에서 컬러바 위치 (0.5는 중앙)
             y=-0.1            # y 좌표에서 컬러바를 아래쪽으로 내림 (0.0보다 작은 값)
        
        )
    ),
            text=texts,  # 텍스트로 diff 데이터를 사용
            texttemplate="<b>%{label}</b><br> %{text:.2f}%",  # 텍스트 형식 설정: label과 diff 표시
            textposition="middle center",  # 텍스트를 중앙에 위치
        ),
        row=1, col=1
    )
    
    
    # 두 번째 트리맵 생성
    
    df_gl=pd.merge(df_gl,etf_sector,on='ETF_CD',how='inner')
    labels = df_gl['SECTOR'].unique().tolist() + df_gl['ETF_NM'].tolist()  # 카테고리와 하위 항목 레이블 결합
    parents = [''] * len(df_gl['SECTOR'].unique()) + df_gl['SECTOR'].tolist()  # 카테고리는 부모가 없고, 하위 항목은 카테고리가 부모
    
    # values와 colors 데이터 준비 (카테고리에는 0 값 할당)
    values = [0] * len(df_gl['SECTOR'].unique()) + df_gl['AUM'].tolist()
    colors = [0] * len(df_gl['SECTOR'].unique()) + df_gl['diff'].tolist()
    texts=  [''] * len(df_gl['SECTOR'].unique()) + df_gl['diff'].fillna(0).astype(str).tolist()
    
    fig.add_trace(
        go.Treemap(
            labels=labels,
            parents=parents,  # 최상위 노드 (부모가 없는 노드)
            values=values,
            marker=dict(
            colors=colors,
            colorscale=finviz_colorscale,  # 빨강-파랑 색상 스케일
            cmin=diff_min,  # 색상 범위 최소값을 diff 최소값으로 설정
        cmax=diff_max,  # 색상 범위 최대값을 diff 최대값으로 설정
        colorbar=dict(
            titleside="bottom",  # 타이틀 위치
            ticks="outside",  # 틱을 컬러바 밖으로 설정
            tickvals=tickvals,  # 동적으로 계산된 틱 값 사용
            ticktext=ticktext,  # 동적으로 계산된 틱 텍스트 사용
            tickmode="array",  # 틱 모드를 'array'로 설정하여 맞춤형 틱 값 사용
            lenmode="fraction",  # 컬러바의 길이 비율로 설정
            #len=0.75,  # 컬러바의 길이를 전체 크기의 75%로 설정
            thickness=10,     # 컬러바의 두께(픽셀)
             len=0.3,          # 컬러바의 길이 (비율)
             orientation="h",  # 수평 방향으로 컬러바 설정
             xanchor="center",  # 컬러바의 위치를 중앙으로 설정
             x=0.5,            # x 좌표에서 컬러바 위치 (0.5는 중앙)
             y=-0.1            # y 좌표에서 컬러바를 아래쪽으로 내림 (0.0보다 작은 값)
        
        )
    ),
            text=texts,  # 텍스트로 diff 데이터를 사용
            texttemplate="<b>%{label}</b><br> %{text:.2f}%",  # 텍스트 형식 설정: label과 diff 표시
            textposition="middle center",  # 텍스트를 중앙에 위치
        ),
        row=1, col=2
    )
    
    # 세 번째 트리맵 생성
    
    labels = df_krstk['SECTOR'].unique().tolist() + df_krstk['JM_NM'].tolist()  # 카테고리와 하위 항목 레이블 결합
    parents = [''] * len(df_krstk['SECTOR'].unique()) + df_krstk['SECTOR'].tolist()  # 카테고리는 부모가 없고, 하위 항목은 카테고리가 부모
    
    # values와 colors 데이터 준비 (카테고리에는 0 값 할당)
    values = [0] * len(df_krstk['SECTOR'].unique()) + df_krstk['TM_AMT'].tolist()
    colors = [0] * len(df_krstk['SECTOR'].unique()) + df_krstk['diff'].tolist()
    texts=  [''] * len(df_krstk['SECTOR'].unique()) + df_krstk['diff'].fillna(0).astype(str).tolist()
    
    fig.add_trace(
        go.Treemap(
            labels=labels,
            parents=parents,  # 최상위 노드 (부모가 없는 노드)
            values=values,
            marker=dict(
            colors=colors,
            colorscale=finviz_colorscale,  # 빨강-파랑 색상 스케일
            cmin=diff_min,  # 색상 범위 최소값을 diff 최소값으로 설정
        cmax=diff_max,  # 색상 범위 최대값을 diff 최대값으로 설정
        colorbar=dict(
            titleside="bottom",  # 타이틀 위치
            ticks="outside",  # 틱을 컬러바 밖으로 설정
            tickvals=tickvals,  # 동적으로 계산된 틱 값 사용
            ticktext=ticktext,  # 동적으로 계산된 틱 텍스트 사용
            tickmode="array",  # 틱 모드를 'array'로 설정하여 맞춤형 틱 값 사용
            lenmode="fraction",  # 컬러바의 길이 비율로 설정
            #len=0.75,  # 컬러바의 길이를 전체 크기의 75%로 설정
            thickness=10,     # 컬러바의 두께(픽셀)
             len=0.3,          # 컬러바의 길이 (비율)
             orientation="h",  # 수평 방향으로 컬러바 설정
             xanchor="center",  # 컬러바의 위치를 중앙으로 설정
             x=0.5,            # x 좌표에서 컬러바 위치 (0.5는 중앙)
             y=-0.1            # y 좌표에서 컬러바를 아래쪽으로 내림 (0.0보다 작은 값)
        
        )
    ),
            text=texts,  # 텍스트로 diff 데이터를 사용
            texttemplate="<b>%{label}</b><br> %{text:.2f}%",  # 텍스트 형식 설정: label과 diff 표시
            textposition="middle center",  # 텍스트를 중앙에 위치
        ),
        row=2, col=1
    )
    
    # 네 번째 트리맵 생성
    labels = list_us_stk['SECTOR'].unique().tolist() + list_us_stk['JM_NM'].tolist()  # 카테고리와 하위 항목 레이블 결합
    parents = [''] * len(list_us_stk['SECTOR'].unique()) + list_us_stk['SECTOR'].tolist()  # 카테고리는 부모가 없고, 하위 항목은 카테고리가 부모
    
    # values와 colors 데이터 준비 (카테고리에는 0 값 할당)
    values = [0] * len(list_us_stk['SECTOR'].unique()) + list_us_stk['MV'].tolist()
    colors = [0] * len(list_us_stk['SECTOR'].unique()) + list_us_stk['diff'].tolist()
    texts=  [''] * len(list_us_stk['SECTOR'].unique()) + list_us_stk['diff'].fillna(0).astype(str).tolist()
    
    fig.add_trace(
        go.Treemap(
            labels=labels,
            parents=parents,  # 최상위 노드 (부모가 없는 노드)
            values=values,
            marker=dict(
            colors=colors,
            colorscale=finviz_colorscale,  # 빨강-파랑 색상 스케일
            cmin=diff_min,  # 색상 범위 최소값을 diff 최소값으로 설정
        cmax=diff_max,  # 색상 범위 최대값을 diff 최대값으로 설정
        colorbar=dict(
            titleside="bottom",  # 타이틀 위치
            ticks="outside",  # 틱을 컬러바 밖으로 설정
            tickvals=tickvals,  # 동적으로 계산된 틱 값 사용
            ticktext=ticktext,  # 동적으로 계산된 틱 텍스트 사용
            tickmode="array",  # 틱 모드를 'array'로 설정하여 맞춤형 틱 값 사용
            lenmode="fraction",  # 컬러바의 길이 비율로 설정
            #len=0.75,  # 컬러바의 길이를 전체 크기의 75%로 설정
            thickness=10,     # 컬러바의 두께(픽셀)
             len=0.3,          # 컬러바의 길이 (비율)
             orientation="h",  # 수평 방향으로 컬러바 설정
             xanchor="center",  # 컬러바의 위치를 중앙으로 설정
             x=0.5,            # x 좌표에서 컬러바 위치 (0.5는 중앙)
             y=-0.1            # y 좌표에서 컬러바를 아래쪽으로 내림 (0.0보다 작은 값)
        
        )
    ),
            text = texts,  # 텍스트로 diff 데이터를 사용
            texttemplate="<b>%{label}</b><br> %{text:.2f}%",  # 텍스트 형식 설정: label과 diff 표시
            textposition="middle center",  # 텍스트를 중앙에 위치
        ),
        row=2, col=2
    )
    
    return fig