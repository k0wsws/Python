# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 18:52:00 2024

@author: USER
"""

from dash import dcc, html, Input, Output, State, ALL
import pickle


##### DataFrame -> pickle file (호가 알람)
def save_dataframe_to_pickle(df, filename):
    with open(filename, "wb") as f:
        pickle.dump(df, f)  # DataFrame을 pickle 형식으로 저장
   
    

# 'Value' 컬럼의 데이터를 백분율(%) 형식으로 변환
def convert_to_percentage(value):
    try:
        value_float = float(value)
        return f'{value_float:.2f}%'
    except ValueError:
        return value


# 데이터에서 제목 부분만 Bold 처리하기 위한 함수
def format_data(data):
    lines = data.split("\n")
    formatted_content = []
    
    for line in lines:
        if line.startswith("국내 주요지수") or line.startswith("국내 시황") or line.startswith("글로벌 주요지수") or line.startswith("FICC시장동향") or line.startswith("글로벌 시황"):
            formatted_content.append(html.B(line))  # 제목 부분을 굵게 표시
        else:
            formatted_content.append(line)
        formatted_content.append(html.Br())  # 줄바꿈 추가
    
    return formatted_content


def format_text_with_newlines(text):
    return text.replace(".", ".\n")  # 마침표 뒤에 줄바꿈을 삽입


# 마침표마다 줄바꿈하고 키워드 전까지만 적용하는 함수
def apply_pre_wrap_before_keyword(text, keyword):
    def add_line_breaks(text_part):
        """마침표를 기준으로 줄바꿈을 추가하는 함수"""
        return text_part.replace(".", ".\n")
    
    if keyword in text:
        # 키워드를 기준으로 텍스트를 분리
        before_keyword, after_keyword = text.split(keyword, 1)
        # 키워드 이전 부분에 마침표 기준 줄바꿈 적용
        before_keyword = add_line_breaks(before_keyword)
        return html.Div([
            html.P(before_keyword, style={"whiteSpace": "pre-line","font-weight": "bold","font-size": "14px", "color": "#6c757d"}),  # 키워드 이전 부분에 pre-wrap 적용
            html.Span(keyword + after_keyword)  # 키워드 이후 부분은 기본 스타일 적용
        ])
    else:
        # 키워드가 없으면 전체 텍스트에 마침표 기준 줄바꿈 적용
        return html.P(add_line_breaks(text), style={"whiteSpace": "pre-wrap"})
