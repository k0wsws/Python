# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 19:58:58 2024

@author: USER
"""

from dash import dcc, html, Input, Output, State, ALL
import dash_bootstrap_components as dbc
import pandas as pd


# 테이블 만드는 함수
def generate_table(dataframe, title="Table Title"):
    return html.Div([  # Div to wrap title and table
        # Title
        html.H3(title, className="text-center my-4", style={"font-family": "Pretendard, sans-serif"}),  # Title with some margin and centered text

        # Table
        html.Table(
            # Table Header
            [
                html.Thead(
                    html.Tr([html.Th(col, className="text-left", style={"font-family": "Pretendard, sans-serif"}) for col in dataframe.columns])
                ),
                # Table Body
                html.Tbody([
                    html.Tr([
                        html.Td(dataframe.iloc[i][col], className="text-left align-middle", style={"font-family": "Pretendard, sans-serif"}) for col in dataframe.columns
                    ]) for i in range(len(dataframe))
                ])
            ],
            className="table table-striped table-bordered table-hover"  # Additional Bootstrap styling classes
        )
    ])



# 뉴스 요약 키워드 박스 만드는 함수
def create_keyword_boxes(keywords):
    keyword_boxes = []
    for keyword in keywords:
        keyword_boxes.append(
            html.Span(
                keyword,
                style={
                    "background-color": "#6390bf",  # 파란색 배경
                    "color": "white",  # 글자 색상은 흰색
                    "border-radius": "15px",  # 둥근 모서리
                    "padding": "5px 10px",  # 내부 여백
                    "margin-right": "5px",  # 오른쪽 여백
                    "display": "inline-block"  # 인라인 블록으로 표시
                }
            )
        )
    return keyword_boxes


# LP 집중도 테이블 생성 
def generate_lp_tb(df_lp1, df_lp_amt, percentage):   #    10.16# 
    
    merged_df = pd.merge(df_lp_amt, df_lp1[['STK_CD', 'ETF_NM']], on='STK_CD', how='inner')

    merged_df['LP_NUM'] = merged_df.groupby('STK_CD')['STK_CD'].transform('count')
    

    filtered_df = merged_df[merged_df['AP_PCT']>percentage][['ETF_NM', 'LP_NUM', 'LP', 'AP_PCT']]
    filtered_df = filtered_df.sort_values(by='AP_PCT', ascending=False)
    
    table_header = [html.Tr([html.Th("ETF명"), html.Th("# LP사"), html.Th("LP"), html.Th("LP 집중도 (잔고기준, %)")])]  
    table_rows = [
        html.Tr([
            html.Td(f"{row['ETF_NM']}"),
            html.Td(f"{row['LP_NUM']}"),
            html.Td(f"{row['LP']}"),
            html.Td(f"{row['AP_PCT']}"),
        ]) for i, (_, row) in enumerate(filtered_df.iterrows())
    ]
    
    table = dbc.Table(table_header + table_rows, bordered=True, hover=True, striped=True)
    
    
    return html.Div(table, style={"maxHeight": "300px",  "overflowY": "auto"})
