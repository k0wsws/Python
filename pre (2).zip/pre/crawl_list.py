# -*- coding: utf-8 -*-
"""
Created on Sun Oct 13 13:26:36 2024

@author: USER
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import pre.DB_ETF as DB


# 종목리스트 불러오기
def crawl_list(date):
    
    conn = DB.conn()
    date_kr=f"""SELECT MAX(TR_YMD) TR_YMD FROM FN_ETFINFO WHERE TR_YMD<='{date}'"""  
    date_kr = pd.read_sql(date_kr, conn)['TR_YMD'][0]
    date_us=f"""SELECT MAX(TR_YMD) TR_YMD FROM QUANT1.DBO.EOD0JG WHERE TR_YMD<'{date_kr}'AND JM_NM='APPLE'"""
    date_us = pd.read_sql(date_us, conn)['TR_YMD'][0]
    
    kr_list = f"""
    SELECT distinct SUBSTRING(JM_KSD_CD,2,6) JM_KSD_CD,JM_NM fROM (SELECT JM_KSD_CD,JM_NM fROM (
    SELECT A.*,RANK() OVER (PARTITION BY FUND_NM ORDER BY CT_RT DESC) RK1,RANK() OVER (PARTITION BY FUND_NM ORDER BY CT_RT ASC) RK2  FROM (
    SELECT KSD_FUND_CD,FUND_NM,'A'+A.JM_KSD_CD JM_KSD_CD,A.JM_NM,A.JM_WT,A.JM_WT*B.RT/100 CT_RT fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.FN_STOCK B 
    WHERE A.JM_KSD_CD =SUBSTRING(B.JM_CD,2,6) AND A.TR_YMD=B.TR_YMD AND A.TR_YMD='{date_kr}' AND FUND_NM LIKE 'ACE%') A) A WHERE RK1 IN (1,2) OR RK2 IN (1,2)) A WHERE JM_KSD_CD LIKE 'A______'
    """

    gl_list =f"""SELECT DISTINCT REPLACE(JM_KSD_CD,' ','') JM_KSD_CD fROM (SELECT JM_KSD_CD fROM (
    SELECT A.*,RANK() OVER (PARTITION BY FUND_NM ORDER BY CT_RT DESC) RK1,RANK() OVER (PARTITION BY FUND_NM ORDER BY CT_RT ASC) RK2  FROM (
    SELECT KSD_FUND_CD,FUND_NM,'A'+A.JM_KSD_CD JM_KSD_CD,A.JM_NM,A.JM_WT,A.JM_WT*B.RT/100 CT_RT fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.FN_STOCK B 
    WHERE A.JM_KSD_CD =SUBSTRING(B.JM_CD,2,6) AND A.TR_YMD=B.TR_YMD AND A.TR_YMD='{date_kr}' AND FUND_NM LIKE 'ACE%'
    UNION
    SELECT KSD_FUND_CD,FUND_NM,TICKER_ID,A.JM_NM,A.JM_WT, A.JM_WT*(ROUND((B.JONGGA /B.BF_JONGGA-1),4)) CT_RT  
    fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.EOD0JG  B , (select DISTINCT LEFT(TICKER_ID, CHARINDEX(' ', TICKER_ID) ) as TICKER_ID, JM_KSD_CD from (SELECT DISTINCT ISIN_ID, TICKER_ID FROM BFXA1000) A, QUANT1.DBO.FDTWB_ETFPDF B where A.ISIN_ID=B.JM_KSD_CD AND TR_YMD='{date_kr}') C
    WHERE A.JM_KSD_CD =B.JM_CD 
    AND A.JM_KSD_CD =C.JM_KSD_CD 
    AND A.TR_YMD='{date_kr}'
    AND B.TR_YMD='{date_us}'
    AND FUND_NM LIKE 'ACE%') A) A WHERE RK1 IN (1,2) OR RK2 IN (1,2)) A WHERE JM_KSD_CD not LIKE 'A______'"""

    etf_list=f"""SELECT A.*,B.NAV_CHG_1D ETF_RT FROM (SELECT FUND_NM,JM_KSD_CD TICKER,A.JM_NM,RT*100 RT,ROUND(CT_RT,3) CT_RT,SUMMARY FROM (SELECT * fROM (
    SELECT A.*,RANK() OVER (PARTITION BY FUND_NM ORDER BY CT_RT DESC) RK1,RANK() OVER (PARTITION BY FUND_NM ORDER BY CT_RT ASC) RK2  FROM (
    SELECT KSD_FUND_CD,FUND_NM,A.JM_KSD_CD,A.JM_NM,A.JM_WT,A.JM_WT*B.RT/100 CT_RT,B.RT/100 RT fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.FN_STOCK B 
    WHERE A.JM_KSD_CD =SUBSTRING(B.JM_CD,2,6) AND A.TR_YMD=B.TR_YMD AND A.TR_YMD='{date_kr}' AND FUND_NM LIKE 'ACE%'
    UNION
    SELECT KSD_FUND_CD,FUND_NM,TICKER_ID,A.JM_NM,A.JM_WT, A.JM_WT*(ROUND((B.JONGGA /B.BF_JONGGA-1),4)) CT_RT,ROUND((B.JONGGA /B.BF_JONGGA-1),4) RT  
    fROM QUANT1.DBO.FDTWB_ETFPDF A, QUANT1.DBO.EOD0JG  B , (select DISTINCT LEFT(TICKER_ID, CHARINDEX(' ', TICKER_ID) ) as TICKER_ID, JM_KSD_CD from (SELECT DISTINCT ISIN_ID, TICKER_ID FROM BFXA1000) A, QUANT1.DBO.FDTWB_ETFPDF B where A.ISIN_ID=B.JM_KSD_CD AND TR_YMD='{date_kr}') C
    WHERE A.JM_KSD_CD =B.JM_CD 
    AND A.JM_KSD_CD =C.JM_KSD_CD 
    AND A.TR_YMD='{date_kr}'
    AND B.TR_YMD='{date_us}'
    AND FUND_NM LIKE 'ACE%') A) A WHERE RK1 IN (1,2) OR RK2 IN (1,2)) A, STOCK_NEWS_SUMMARY B WHERE A.JM_KSD_CD=B.TICKER) A, (SELECT ETF_cD,ETF_NM,NAV_CHG_1D  fROM FN_ETFDATA WHERE TR_YMD='{date_kr}') B WHERE A.FUND_NM=B.ETF_NM"""
    
    kr_list = pd.read_sql(kr_list, conn)
    gl_list = pd.read_sql(gl_list, conn)
    etf_list = pd.read_sql(etf_list, conn)
    
    
    return kr_list,gl_list,etf_list

##실시간 상승 TOP10
def crawl_list_top5():
    
    ## 코스피
    url = 'https://finance.naver.com/sise/sise_rise.naver'


    response = requests.get(url,verify=False)
    response.encoding = 'euc-kr'  
    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table', class_='type_2')
    
    stocks  = []
    rows = table.find_all('tr')
    count = 0
    for row in rows:
        cols = row.find_all('td')
        if len(cols) > 1:  
            stock_code = cols[1].find('a')['href'].split('=')[-1]  
            stock_name = cols[1].get_text(strip=True)  
            change_rate = cols[4].get_text(strip=True)
            stocks.append({'name': stock_name, 'code': stock_code, 'change_rate': change_rate}) 
            count += 1
            if count == 10:
                break

    ## 코스닥
    url = 'https://finance.naver.com/sise/sise_rise.naver?sosok=1'
        
    response = requests.get(url,verify=False)
    response.encoding = 'euc-kr' 

    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table', class_='type_2')
    rows = table.find_all('tr')

    count = 0
    for row in rows:
        cols = row.find_all('td')
        if len(cols) > 1: 
            stock_code = cols[1].find('a')['href'].split('=')[-1] 
            stock_name = cols[1].get_text(strip=True) 
            change_rate = cols[4].get_text(strip=True)  
            stocks.append({'name': stock_name, 'code': stock_code, 'change_rate': change_rate}) 
            count += 1
            if count == 10:
                break

    df_stocks = pd.DataFrame(stocks)
    df_stocks['change_rate'] = df_stocks['change_rate'].str.replace('%', '').str.replace('+', '').astype(float)

    df_stocks = df_stocks.sort_values(by='change_rate',ascending=False)
    df_stocks = df_stocks.reset_index(drop=True)
    
            
    return df_stocks

##실시간 하락 TOP10
def crawl_list_bot5():
    
    ## 코스피
    url = 'https://finance.naver.com/sise/sise_fall.naver'


    response = requests.get(url,verify=False)
    response.encoding = 'euc-kr'

    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table', class_='type_2')
    
    stocks  = []
    rows = table.find_all('tr')


    count = 0
    for row in rows:
        cols = row.find_all('td')
        if len(cols) > 1: 
            stock_code = cols[1].find('a')['href'].split('=')[-1] 
            stock_name = cols[1].get_text(strip=True)  
            change_rate = cols[4].get_text(strip=True)  
            stocks.append({'name': stock_name, 'code': stock_code, 'change_rate': change_rate}) 
            count += 1
            if count == 10: 
                break



    ## 코스닥
    url = 'https://finance.naver.com/sise/sise_fall.naver?sosok=1'
        

    response = requests.get(url,verify=False)
    response.encoding = 'euc-kr'  

    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table', class_='type_2')

    rows = table.find_all('tr')

    count = 0
    for row in rows:
        cols = row.find_all('td')
        if len(cols) > 1:  
            stock_code = cols[1].find('a')['href'].split('=')[-1]  
            stock_name = cols[1].get_text(strip=True) 
            change_rate = cols[4].get_text(strip=True) 
            stocks.append({'name': stock_name, 'code': stock_code, 'change_rate': change_rate})  
            count += 1
            if count == 10: 
                break

    df_stocks = pd.DataFrame(stocks)
    df_stocks['change_rate'] = df_stocks['change_rate'].str.replace('%', '').str.replace('+', '').astype(float)

    df_stocks = df_stocks.sort_values(by='change_rate',ascending=True)
    df_stocks = df_stocks.reset_index(drop=True)
    
            
    return df_stocks