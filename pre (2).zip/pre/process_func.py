# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 19:54:12 2024

@author: USER
"""

from dash import dcc, html, Input, Output, State, ALL
from flask import Flask, session
import os
from datetime import datetime, timedelta
import subprocess
import threading

# 실행 확인
def read_output(process, name):
    """Read and print the output of the subprocess."""
    for line in process.stdout:
        print(f"[{name} STDOUT]: {line.strip()}")
    for line in process.stderr:
        print(f"[{name} STDERR]: {line.strip()}")  


##### 호가 알람 함수
def hoga_alarm(process1, process2):
    if process1 is None and process2 is None:
        # 실행중인 파일이 없음        
        print(f"Current Working Directory: {os.getcwd()}")
        process1 = subprocess.Popen(
            ["python", "utils_/호가모니터링알림(신고스프레드).py"],
            stdout=subprocess.PIPE,  # Capture standard output
            stderr=subprocess.PIPE,  # Capture standard error
            text=True  # Handle output as text
        )
        process2 = subprocess.Popen(
            ["python", "utils_/호가모니터링알림(LP).py"],
            stdout=subprocess.PIPE,  # Capture standard output
            stderr=subprocess.PIPE,  # Capture standard error
            text=True  # Handle output as text
        )
        
        # Start threads to read the output of each process
        threading.Thread(target=read_output, args=(process1, "Process 1")).start()
        threading.Thread(target=read_output, args=(process2, "Process 2")).start()
        
        if process1 is not None and process2 is not None: 
            print(" 호가 알람 켜짐 ")
        return process1, process2
        
    else:
        print("이미 호가 알람 실행중입니다.")
        return process1, process2


##### 뉴스 크롤링 함수
def news_crawl(process):
    if process is None:
        # 실행중인 파일이 없음 
        print(os.getcwd())            
        process = subprocess.Popen(
            ["python", "utils_/news_crawl_main.py"],
            stdout=subprocess.PIPE,  # 표준 출력을 캡처
            stderr=subprocess.PIPE,  # 표준 에러를 캡처
            text=True  # 출력 내용을 문자열로 처리
        )
        
        
        threading.Thread(target=read_output, args=(process, "Process C")).start()
        
        if process is not None: print(" 뉴스 크롤링 켜짐 ")
        return process
        
    else:
        print("이미 뉴스 크롤링 실행중입니다.")
        return process


##### 등락률 API 함수
def chg_rate_api(process):
    if process is None:
        # 실행중인 파일이 없음     
        print(os.getcwd())
        process = subprocess.Popen(
            ["python", "utils_/chg_rate_api.py"],
            stdout=subprocess.PIPE,  # 표준 출력을 캡처
            stderr=subprocess.PIPE,  # 표준 에러를 캡처
            text=True  # 출력 내용을 문자열로 처리
        )
        
        threading.Thread(target=read_output, args=(process, "Process 등락")).start()
        
        if process is not None: print(" 등락률 켜짐 ")
        return process
        
    else:
        print("이미 등락률 실행중입니다.")
        return process


##### VI API 함수
def vi_api(process):
    if process is None:
        # 실행중인 파일이 없음
        print(os.getcwd())
        process = subprocess.Popen(
            ["python", "utils_/vi_api.py"],
            stdout=subprocess.PIPE,  # 표준 출력을 캡처
            stderr=subprocess.PIPE,  # 표준 에러를 캡처
            text=True  # 출력 내용을 문자열로 처리
        )
        
        threading.Thread(target=read_output, args=(process, "Process VI")).start()
        
        if process is not None: print(" VI 켜짐 ")
        return process
    else:
        print("이미 VI 실행중입니다.")
 
        
##### 프로세스 종료 함수 
def stop_process(process):
    if process is not None:
        print(" 프로세스 종료 ")
        # 실행 중인 프로세스를 종료합니다.
        process.terminate()
        process = None
        return process
    else:
        print("실행 중인 프로세스가 없습니다.")
