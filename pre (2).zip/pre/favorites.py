# -*- coding: utf-8 -*-
"""
Created on Wed Oct 16 19:57:03 2024

@author: USER
"""

import json
import os
import path_set as ps

root=ps.path()


# 사용자별 즐겨찾기 파일 경로 설정
def get_favorites_file_path(user_name):
    return root+f"{user_name}_favorites.json"


# 사용자별 즐겨찾기 불러오기
def load_favorites(user_name):
    file_path = get_favorites_file_path(user_name)
    if os.path.exists(file_path):
        with open(file_path, "r") as file:
            return json.load(file)
        
    else:
        return {'checklist1': [], 'checklist2': [], 'checklist3': [], 'favorites': []}


# 사용자별 즐겨찾기 저장
def save_favorites(user_name, favorites):
    file_path = get_favorites_file_path(user_name)
    with open(file_path, "w") as file:
        json.dump(favorites, file)