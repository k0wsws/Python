#### app 실행 파일입니다
#### main.py 파일 실행시 모든 페이지 레이아웃이 보이게 됩니다.

import dash
from dash import dcc, html
import dash_bootstrap_components as dbc
from flask import Flask, session
import webbrowser
import path_set as ps

# Importing page layouts and callbacks
from page.page_login import layout as login_layout, register_callbacks as register_login_callbacks
from page.page_home import layout as home_layout
from page.page_market_monitor import layout as treemap_layout, register_callbacks as register_treemap_callbacks
from page.page_risk_monitor import layout as hoga_layout, register_callbacks as register_hoga_callbacks
from page.page_analysis import layout as analysis_layout, register_callbacks as register_analysis_callbacks
from page.page_analysis_m import layout as analysis_m_layout, register_callbacks as register_analysis_callbacks
from page.page_admin import layout as admin_layout, register_callbacks as register_admin_callbacks
from pre.get_data import read_update_time

# Flask 서버 초기화
server = Flask(__name__)
server.secret_key = 'supersecretkey'
app = dash.Dash(__name__, server=server, external_stylesheets=[dbc.themes.BOOTSTRAP], suppress_callback_exceptions=True)


# 사이드바 레이아웃
sidebar = dbc.Card(
    dbc.Nav(
        [   dbc.NavLink("HOME", href="/", active="exact", className="nav-link", style={"color": "#6390bf"}),
            dbc.NavLink("시장 모니터링", href="/treemap", active="exact", className="nav-link", style={"color": "#6390bf"}),
            dbc.NavLink("리스크 모니터링", href="/ho-ga", active="exact", className="nav-link", style={"color": "#6390bf"}),
            dbc.NavLink("성과 분석", href="/analysis", active="exact", className="nav-link", style={"color": "#6390bf"}),
            dbc.NavLink("성과 분석2", href="/analysis_m", active="exact", className="nav-link", style={"color": "#6390bf"}),
            dbc.NavLink("관리자 화면", href="/ho-ga-admin", active="exact", className="nav-link", style={"color": "#6390bf"}),
        ],
        vertical=True,
        pills=True,
    ),
    body=True,
    className="sidebar",
)

# 페이지 내용 정의
content = html.Div(id="page-content", className="content")

# 기본 레이아웃
app.layout = dbc.Container([
                dcc.Location(id="url"),  # 현재 페이지 URL을 추적
                dcc.Store(id='stored-click-data', data=None),  # 클릭된 데이터를 저장하는 Store
                dcc.Store(id='popup-visible', data=False),  # 팝업 상태 저장 (True/False)
                dbc.Row([
                            dbc.Col([sidebar], width=2),  # 사이드바
                            dbc.Col([content,
                            html.Div(id='popup-news', style={'display': 'none', 'position': 'absolute', 'padding': '20px', 'background-color': '#f9f9f9', 'border': '1px solid #ccc', 'box-shadow': '2px 2px 10px rgba(0, 0, 0, 0.1)'})
                        ], width=10)  # 메인 콘텐츠
                        ], style={'margin-top': '20px'})
                    
            ], fluid=True, style={'background-color': '#f8f9fa', 'padding': '20px', "fontFamily": "Pretendard"})


# 콜백을 통해 페이지 콘텐츠를 업데이트
@app.callback(
    dash.dependencies.Output('page-content', 'children'),
    [dash.dependencies.Input('url', 'pathname'),
     dash.dependencies.Input('url', 'search')]
)
def display_page(pathname, search):
    if 'logged_in' in session :
        
        if pathname == "/analysis":
            return analysis_layout
    
        elif pathname == "/ho-ga":
            return hoga_layout
        
        elif pathname == "/ho-ga-admin":
             return admin_layout
    
        elif pathname == "/treemap":
            read_update_time()
            return treemap_layout
        
        elif pathname == "/analysis_m":
            return analysis_m_layout
        
        if pathname == "/":
            # 여기에 /main 페이지의 레이아웃을 작성하면 됩니다.    
            return home_layout
    
        else:
            return html.Div([html.H2("404: 페이지를 찾을 수 없습니다.")])
    return login_layout



# 각 페이지에 쓰이는 콜백 호출
register_login_callbacks(app)
register_treemap_callbacks(app)
register_hoga_callbacks(app)
register_analysis_callbacks(app)
register_admin_callbacks(app)


# 앱 실행하기
if __name__ == '__main__':
    
    print(ps.path_host()[0])
    print(ps.path_host()[1])    
    
    app.run(debug=True, host=ps.path_host()[0], port=ps.path_host()[1])  # IP와 포트 지정
    # print(ps.path_host()[0])
    # print(ps.path_host()[1])    
    print("웹 실행 완료")
    
    # # 기본 브라우저에서 해당 URL 열기
    url = "http://"+ps.path_host()[0]+":"+str(ps.path_host()[1])  # 자동으로 열 URL (앱이 실행된 주소)
    webbrowser.open(url)