import time
import chainlit as cl
from langchain.callbacks.base import AsyncCallbackHandler
from typing import Any, Dict, List, Optional
from uuid import UUID

from langchain_core.messages import BaseMessage

from utils.visual.get_etf_preset import get_etf_preset


class LangchainAsyncCallbackHandler(AsyncCallbackHandler):
    def __init__(self, msg: Optional[cl.Message] = None, ask_user_msg: Optional[cl.AskUserMessage] = None) -> None:
        self.msg = msg
        self.ask_user_msg = ask_user_msg
        # print("after --> cl_msg :", self.msg)
        # print("after --> ask_user_msg :", self.ask_user_msg)

    async def on_chain_end(
            self,
            outputs: Dict[str, Any],
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            tags: Optional[List[str]] = None,
            **kwargs: Any,
    ) -> None:
        # 마지막 Chain 일 경우 에만 실행.
        try:
            if parent_run_id is None:
                start_time = float(0)
                human_msg = float(0)

                for tag in tags:
                    str_tmp_list = tag.split(":start_info:")
                    if str_tmp_list is not None and len(str_tmp_list) > 0:
                        start_time = float(str_tmp_list[1])
                        human_msg = str(str_tmp_list[2])

                        await get_etf_preset()

                # await get_etf_preset()
                if outputs is not None:
                    # for token in outputs:
                    #     await self.msg.stream_token(token)
                    newline_token_list = outputs.split('\n')
                    # 출력할 토큰이 많을 경우 개행 과 띄어쓰기 기준으로 뿌려주도록 제한
                    if len(newline_token_list) > 0:
                        for newline_str in newline_token_list:
                            newline_str += '\n'
                            for white_space_token in newline_str.split(' '):
                                await self.msg.stream_token(white_space_token + ' ')
                    else:
                        # 그 외 건에 대한 처리
                        for token in outputs:
                            await self.msg.stream_token(token)

                    if start_time > 0:
                        end_time = time.time()
                        elapsed_time = end_time - start_time
                        time_msg = f"\n(응답 시간: {elapsed_time:.2f} sec)"
                        await self.msg.stream_token(time_msg)
                    await self.msg.update()

                    memory = cl.user_session.get("memory")
                    memory.chat_memory.add_user_message(human_msg)
                    memory.chat_memory.add_ai_message(self.msg.content)

        except Exception as ex:
            print(ex)

    async def on_chain_error(
            self,
            error: BaseException,
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            tags: Optional[List[str]] = None,
            **kwargs: Any,
    ) -> None:
        print("\n")
        print("===============on_chain_error - S T A R T===============")
        print("error :", error)
        print("run_id :", run_id)
        print("parent_run_id :", parent_run_id)
        print("tags :", tags)
        print("===============on_chain_error - E  N  D===============")
        print("\n")

    async def on_chat_model_start(
            self,
            serialized: Dict[str, Any],
            messages: List[List[BaseMessage]],
            *,
            run_id: UUID,
            parent_run_id: Optional[UUID] = None,
            tags: Optional[List[str]] = None,
            metadata: Optional[Dict[str, Any]] = None,
            **kwargs: Any,
    ) -> Any:
        pass
