from typing import Any
import time
from langfuse.callback import CallbackHandler as LangfuseCallbackHandler
from langchain.schema.runnable.config import RunnableConfig
from utils.langfuse.get_username import _get_username_from_ps
from utils.langchain.callback_handler import LangchainAsyncCallbackHandler
import chainlit as cl


def setting_runnable_config(start_msg_info: str = None) -> RunnableConfig:
    chat_settings = cl.user_session.get("chat_settings")
    session_id = cl.user_session.get("id")
    user = cl.user_session.get("user")
    cl_msg = cl.Message(content="")
    config = RunnableConfig(
        callbacks=[
            cl.LangchainCallbackHandler(),
            LangfuseCallbackHandler(
                session_id=session_id,
                user_id=(
                    user.identifier
                    if user is not None
                    else _get_username_from_ps("unknown_user") + "_dev"
                ),
            ),
            LangchainAsyncCallbackHandler(msg=cl_msg),  # 메시지 처리는 Langchain Callback Handler를 통해 처리하도록 변경
        ],
        metadata=chat_settings,
        # tags=[start_msg_info]  # 응답 시간을 기록하기 위해 시작 시간(start_time), 사용자 질문을 태그로 전송
        # tags = ["chat", "history"] #TODO: add tags to langfuse
    )
    if start_msg_info is not None:
        config["tags"] = [start_msg_info]  # 응답 시간을 기록하기 위해 시작 시간(start_time), 사용자 질문을 태그로 전송

    return config


async def invoke_llm(invoke_message: str) -> None:
    runnable = cl.user_session.get("runnable")  ## type: Runnable
    topic_classifier = cl.user_session.get("topic_classifier")  ## type: Runnable
    config = setting_runnable_config()
    topic = topic_classifier.invoke({"input": invoke_message})
    await runnable.ainvoke({"input": invoke_message, "topic": topic}, config=config)

    # await msg.send()

    # outputs = await runnable.ainvoke({"input": content, "topic": topic}, config=config)
    # if outputs is not None:
    #     newline_token_list = outputs.split('\n')
    #     # 출력할 토큰이 많을 경우 개행 과 띄어쓰기 기준으로 뿌려주도록 제한
    #     if len(newline_token_list) > 0:
    #         for newline_str in newline_token_list:
    #             newline_str += '\n'
    #             for white_space_token in newline_str.split(' '):
    #                 await cl_msg.stream_token(white_space_token + ' ')
    #
    # await cl_msg.update()
