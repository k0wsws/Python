import re
import logging
import chainlit as cl

from typing import Tuple
from datetime import datetime
from dateutil.relativedelta import relativedelta

from chainlit.custom.database.postgres_connector import db_connector

from utils import json_utils
import requests
from urllib.parse import urlparse, parse_qs

# Disable warning for SSL
requests.packages.urllib3.disable_warnings()


def get_db_response_to_structured_dict(db_response: dict) -> dict:
    structured_dict_format: dict = {}
    for key in db_response.keys():
        if db_response[key]:
            if isinstance(db_response[key], datetime):
                structured_dict_format[key] = db_response[key].strftime("%Y%m%d")
            elif db_response[key] == 0:
                structured_dict_format[key] = '-'
            else:
                structured_dict_format[key] = db_response[key]
        else:
            structured_dict_format[key] = '-'

    return structured_dict_format


def get_recent_master_with_price_information(etf_ticker: str) -> list:
    structured_recent_master: list = []

    query = f"""select erm.etf_ticker
        , erm.etf_name
        , erm.isin as fund_code -- 펀드 코드
        , erm.tracking_index
        , erm.inception_date
        , erm.asset_under_management
        , erm.total_expense_ratio
        , erm.management_fee_ratio
        , erm.management_firm -- 운용사
        , erm.closing_price -- 전일 종가
        , erm.risk_level -- 위험등급
        , erm.personal_pension -- 개인 연금 여부
   	    , erm.retirement_pension -- 퇴직 연금 여부
        , COALESCE(erm.investment_points, '') as investment_points -- 투자 포인트
        , erm.sell_fee_ratio
        , erm.custody_fee_ratio
        , erm.back_fee_ratio
        , erm.market_class_1
        , erm.monthly_dividend
        , erm.recent_dividend_date
        , erm.recent_payment_date
        , erm.recent_dividend_amount
        , erm.recent_dividend_ratio::numeric as dividend_ratio
        , erm.annual_dividend_distribution_count as dividend_distribution_count
        , entr.nav_total_return_1week as total_return_1week
        , entr.nav_total_return_1month as total_return_1month
        , entr.nav_total_return_3month as total_return_3month
        , entr.nav_total_return_6month as total_return_6month
        , entr.nav_total_return_year_to_date as total_return_year_to_date
    from etf.etf_recent_master erm 
    left join etf.etf_nav_total_return entr on erm.etf_ticker = entr.etf_ticker 
    where erm.etf_ticker IN ({etf_ticker})
    """

    try:
        db_response = db_connector.execute(command=query)
        if db_response and len(db_response) > 0:
            structured_recent_master = db_response

    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO:

    return structured_recent_master


def get_etf_basic_information(etf_ticker: str) -> dict:
    structured_recent_master: dict = {}
    query = f"""
    select erm.etf_ticker
        , erm.etf_name 
        , erm.isin as fund_code -- 펀드 코드
    from etf.etf_recent_master erm 
    where erm.etf_ticker = '{etf_ticker}'
    """
    try:
        db_response = db_connector.execute(command=query)
        if db_response and len(db_response) > 0:
            structured_recent_master = db_response[0]

    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO:

    return structured_recent_master


def get_recent_master_with_addons_information(etf_ticker: str) -> dict:
    structured_addons: dict = {}
    blog_link = ""
    blog_image_link = ""
    youtube_link = ""
    youtube_image_link = ""
    instagram_link = ""

    query = f"""select 
        COALESCE(erm.blog_link, '') as blog_link, -- 네이버 블로그 링크
        COALESCE(erm.blog_image_link, '') as blog_image_link, -- 인스타그램 링크
        COALESCE(erm.youtube_link, '') as youtube_link, -- 유튜브 링크
        COALESCE(erm.instagram_link, '') as instagram_link -- 인스타그램 링크
    from etf.etf_recent_master erm
    where erm.etf_ticker = '{etf_ticker}'
    """
    try:
        db_response = db_connector.execute(command=query)
        if db_response and len(db_response) > 0:
            for obj in db_response:
                dict_data = dict(obj)
                blog_link = dict_data.get("blog_link")
                youtube_link = dict_data.get("youtube_link")
                if youtube_link != "":
                    url_parts = urlparse(youtube_link)
                    if url_parts.query is not None and url_parts.query != '':
                        youtube_id = parse_qs(url_parts.query).get("v")[0]
                        # youtube_image_link = f"https://img.youtube.com/vi/{youtube_id}/maxresdefault.jpg"
                        youtube_image_link = f"https://i.ytimg.com/vi/{youtube_id}/hqdefault.jpg"
                instagram_link = dict_data.get("instagram_link")
                blog_image_link = dict_data.get("blog_image_link")
    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO:

    structured_addons = {
        "instagram_link": instagram_link,
        "youtube_link": youtube_link,
        "youtube_image_link": youtube_image_link,
        "blog_link": blog_link,
        "blog_image_link": blog_image_link
    }
    return structured_addons


## 수익률 내역 프리셋
def get_close_price_with_nav_total_information(etf_ticker: str, is_basic_card: bool = False) -> dict:
    close_price_with_nav_total_data: list = []

    query = f"""
    (
        select 'nav_total_return' as kind,
            '기준 가격(NAV)' as kind_name,
            '분배금 재투자를 고려한 기간별 순자산가치(NAV) 수익률 정보, 일반적으로 사용하는 수익률 정보' as kind_description,
            nav_total_return_1week as one_week,
            nav_total_return_1month as one_month,
            nav_total_return_3month as three_month,
            nav_total_return_6month as six_month,
            nav_total_return_1year as one_year,
            nav_total_return_3year as three_year,
            nav_total_return_year_to_date as year_to_date,
            cumulative_nav_total_return as cumulative
        from etf.etf_nav_total_return
        where etf_ticker = '{etf_ticker}'
    )
    union all
    (
        select 'base_index' as kind,
            '기초 지수' as kind_name,
            '기초 지수' as kind_description,
            NULL as one_week,
            NULL as one_month,
            NULL as three_month,
            NULL as six_month,
            NULL as one_year,
            NULL as three_year,
            NULL as year_to_date,
            NULL as cumulative
    )
    union all
    (
        select 'close_price_return' as kind,
            '종가 기준 총수익률' as kind_name,
            '분배금 재투자를 고려하지 않은 기간별 종가 수익률 정보' as kind_description,
            price_return_1week as one_week,
            price_return_1month as one_month,
            price_return_3month as three_month,
            price_return_6month as six_month,
            price_return_1year as one_year,
            price_return_3year as three_year,
            price_return_year_to_date as year_to_date,
            cumulative_price_return as cumulative
        from etf.etf_close_price_return
        where etf_ticker = '{etf_ticker}'
    )
    union all
    (
        select 'close_price_total_return' as kind,
            '종가 기준 총수익률(TR)' as kind_name,
            '분배금 재투자를 고려한 기간별 종가 총수익률 정보' as kind_description,
            price_total_return_1week as one_week,
            price_total_return_1month as one_month,
            price_total_return_3month as three_month,
            price_total_return_6month as six_month,
            price_total_return_1year as one_year,
            price_total_return_3year as three_year,
            price_total_return_year_to_date as year_to_date,
            cumulative_price_total_return as cumulative
        from etf.etf_close_price_total_return
        where etf_ticker = '{etf_ticker}'
    )
    """

    return_data: dict = {}
    fund_code = ""
    try:
        db_response = db_connector.execute(command=query)
        if len(db_response) > 0:
            etf_basic: dict = get_etf_basic_information(
                etf_ticker=etf_ticker
            )
            if len(etf_basic.keys()) > 0:
                fund_code = etf_basic.get("fund_code")
                return_data = etf_basic
                return_data["data"] = db_response
                return_data["is_basic_card"] = is_basic_card
    except Exception as ex:
        print("[papi.aceetf.co.kr] get performance API Error :", ex)

    if len(return_data.keys()) > 0:
        try:
            res = requests.get(f"https://papi.aceetf.co.kr/api/funds/{fund_code}/performance?page=1&size=1", verify=False)
            if res.status_code == 200 and res.text != "":
                addons_res = res.json()
                # "wk1ErnRt": "1주 기준가격(NAV) 수익률",
                # "mm1ErnRt": "1달 기준가격(NAV) 수익률",
                # "mm3ErnRt": "3달 기준가격(NAV) 수익률",
                # "mm6ErnRt": "6달 기준가격(NAV) 수익률",
                # "yy1ErnRt": "1년 기준가격(NAV) 수익률",
                # "yy3ErnRt": "3년 기준가격(NAV) 수익률",
                # "yy5ErnRt": "5년 기준가격(NAV) 수익률",
                # "bgyrNextErnRt": "연초이후 기준가격(NAV) 수익률",
                # "opngNextErnRt": 128.24932232846047,
                # "listNextErnRt": "상장이후 펀드 수익률",
                # "wk1ErnRtBM": "1주 기초지수 수익률",
                # "mm1ErnRtBM": "1달 기초지수 수익률",
                # "mm3ErnRtBM": "3달 기초지수 수익률",
                # "mm6ErnRtBM": "6달 기초지수 수익률",
                # "yy1ErnRtBM": "1년 기초지수 수익률",
                # "yy3ErnRtBM": "3년 기초지수 수익률",
                # "yy5ErnRtBM": "5년 기초지수 수익률",
                # "bgyrNextErnRtBM": "연초이후 기초지수 수익률",
                # "opngNextErnRtBM": "83.630141005454",
                # "listNextErnRtBM": "상장이후 기초지수 수익률",
                base_index_data = dict(return_data.get("data")[1])
                if isinstance(addons_res.get("wk1ErnRtBM"), float):
                    base_index_data["one_week"] = round(float(addons_res['wk1ErnRtBM']), 2)
                if isinstance(addons_res.get("mm1ErnRtBM"), float):
                    base_index_data["one_month"] = round(float(addons_res['mm1ErnRtBM']), 2)
                if isinstance(addons_res.get("mm3ErnRtBM"), float):
                    base_index_data["three_month"] = round(float(addons_res['mm3ErnRtBM']), 2)
                if isinstance(addons_res.get("mm6ErnRtBM"), float):
                    base_index_data["six_month"] = round(float(addons_res['mm6ErnRtBM']), 2)
                if isinstance(addons_res.get("yy1ErnRtBM"), float):
                    base_index_data["one_year"] = round(float(addons_res['yy1ErnRtBM']), 2)
                if isinstance(addons_res.get("yy3ErnRtBM"), float):
                    base_index_data["three_year"] = round(float(addons_res['yy3ErnRtBM']), 2)
                # if isinstance(addons_res.get("yy5ErnRtBM"), float):
                #     base_index_data["five_year"] = round(float(addons_res['yy5ErnRtBM']), 2)
                if isinstance(addons_res.get("bgyrNextErnRtBM"), float):
                    if isinstance(addons_res.get("bgyrNextErnRt"), float):
                        # "bgyrNextErnRt - 연초이후 기준가격(NAV) 수익률" 이 None 일 경우 기초 지수가 나오는 이슈 때문에
                        # bgyrNextErnRt 데이터가 있을 경우에만 보여주도록 수정 -> 요청 사항.
                        base_index_data["year_to_date"] = round(float(addons_res['bgyrNextErnRtBM']), 2)
                # if isinstance(addons_res.get("opngNextErnRtBM"), float):
                #     base_index_data["????"] = round(float(addons_res['opngNextErnRtBM']), 2)
                if isinstance(addons_res.get("listNextErnRtBM"), float):
                    base_index_data["cumulative"] = round(float(addons_res['listNextErnRtBM']), 2)

                return_data["data"][1] = base_index_data

        except Exception as e:
            print("[papi.aceetf.co.kr] get performance API Error :", e)

    return return_data


## 분배급 지급 내역 프리셋
def get_cumulative_dividend(etf_ticker: str, is_basic_card: bool = False) -> dict:
    return_data: dict = {}

    query = f"""select dividend_date, payment_date, dividend_amount, dividend_ratio
    from etf.etf_historical_dividend ecd
    where ecd.etf_ticker = '{etf_ticker}'
    order by dividend_date desc
    """

    try:
        db_response = db_connector.execute(command=query)
        structured_cumulative_dividend: list = []
        if db_response:
            for obj in db_response:
                structured_cumulative_dividend.append(get_db_response_to_structured_dict(obj))

        etf_basic: dict = get_etf_basic_information(
            etf_ticker=etf_ticker
        )
        if len(etf_basic.keys()) > 0:
            return_data = etf_basic
            return_data["data"] = structured_cumulative_dividend
            return_data["is_basic_card"] = is_basic_card

    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO:

    return return_data


## 구성 정보 카드 프리셋
def get_portfolio_deposit_file(etf_ticker: str, is_basic_card: bool = False, is_single_card: bool = False) -> dict:
    result_data: dict = {}
    query: str = f"""
    select holding_ticker as key
        , holding_name as name
        , holding_weight as size
        , recorded_date
    from etf.etf_historical_constituent_holdings erch
    where erch.etf_ticker = '{etf_ticker}'
    and recorded_date = (
        select recorded_date
        from etf_historical_constituent_holdings
        order by recorded_date desc
        limit 1
    )
    order by rank_idx
    """
    try:
        db_response = db_connector.execute(command=query)
        if len(db_response) > 0:
            etf_basic: dict = get_etf_basic_information(
                etf_ticker=etf_ticker
            )
            if len(etf_basic.keys()) > 0:
                result_data = etf_basic
                result_data["data"] = db_response
                result_data["is_basic_card"] = is_basic_card
                result_data["is_single_card"] = is_single_card
                result_data["recorded_date"] = db_response[0]["recorded_date"].strftime("%Y-%m-%d")

    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO:

    return result_data


def get_historical_portfolio_deposit_file(etf_ticker: str, date: str, is_basic_card: bool = False, is_single_card: bool = False) -> dict:
    result_data: dict = {}
    # structured_portfolio_deposit_file: list = []

    query: str = f"""select holding_ticker as key, holding_name as name, holding_weight as size, recorded_date
    from etf.etf_historical_constituent_holdings erch 
    where recorded_date = (select distinct recorded_date 
                            from etf_historical_constituent_holdings ehch 
                            where ehch.etf_ticker = '{etf_ticker}' and ehch.recorded_date <= '{date}'
                            order by recorded_date desc
                            limit 1) and erch.etf_ticker = '{etf_ticker}'
    order by rank_idx
    """

    try:
        db_response = db_connector.execute(command=query)
        if len(db_response) > 0:
            etf_basic: dict = get_etf_basic_information(
                etf_ticker=etf_ticker
            )
            if len(etf_basic.keys()) > 0:
                result_data = etf_basic
                result_data["data"] = db_response
                result_data["is_basic_card"] = is_basic_card
                result_data["is_single_card"] = is_single_card
                result_data["recorded_date"] = db_response[0]["recorded_date"].strftime("%Y-%m-%d")
        # if db_response:
        #     for obj in db_response:
        #         structured_portfolio_deposit_file.append(obj)
    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO:

    return result_data


def get_changed_portfolio_deposit_file(etf_ticker: str, is_basic_card: bool = False, is_single_card: bool = False) -> dict:
    result_data: dict = {}

    query: str = f"""with recent as (select string_agg(recent.ticker, '') as key
                        from (select concat(erch.holding_ticker, erch.holding_weight, '') as ticker
                                from etf_recent_constituent_holdings erch 
                                where erch.etf_ticker = '{etf_ticker}'
                                order by erch.rank_idx
                        ) as recent),
                            past as (select history.recorded_date, string_agg(history.ticker, '') as key
                                    from (select ehch.recorded_date, concat(holding_ticker, holding_weight, '') as ticker
                                    from etf_historical_constituent_holdings ehch 
                                    where ehch.etf_ticker = '{etf_ticker}'
                                    order by ehch.recorded_date, ehch.rank_idx) as history
                            group by history.recorded_date)
                    select holding_ticker as key, holding_name as name, holding_weight as size, recorded_date
                    from etf_historical_constituent_holdings ehch 
                    where recorded_date = (
                                            select recorded_date 
                                            from past 
                                            where past.key != (select recent.key from recent)
                                            order by recorded_date desc 
                                            limit 1) and etf_ticker ='{etf_ticker}'
                    order by recorded_date, rank_idx;
    """

    try:
        db_response = db_connector.execute(command=query)
        if len(db_response) > 0:
            etf_basic: dict = get_etf_basic_information(
                etf_ticker=etf_ticker
            )
            if len(etf_basic.keys()) > 0:
                result_data = etf_basic
                result_data["data"] = db_response
                result_data["is_basic_card"] = is_basic_card
                result_data["is_single_card"] = is_single_card
                result_data["recorded_date"] = db_response[0]["recorded_date"].strftime("%Y-%m-%d")

    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO:

    return result_data


def get_closing_price_and_trade_volume(etf_ticker: str, start_point: int = 1) -> list[dict]:
    structured_closing_price_series: list[dict] = []

    query = f"""select recorded_date, closing_price, total_trade_volume
    from etf.etf_historical_statistics ecp 
    where ecp.etf_ticker = '{etf_ticker}' and recorded_date > current_date - interval '{start_point} year'
    order by recorded_date asc
    """

    try:
        db_response = db_connector.execute(command=query)
        if db_response:
            for item in db_response:
                if isinstance(item.get("recorded_date"), datetime):
                    structured_closing_price_series.append({
                        "recorded_date": item.get("recorded_date").strftime("%Y-%m-%d"),
                        "closing_price": item["closing_price"],
                        "total_trade_volume": item["total_trade_volume"],
                    })
    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO

    return structured_closing_price_series


def get_dividend_series(etf_ticker: str, start_point: int = 1) -> Tuple[dict, dict]:
    structured_dividend_amount_series: dict = {}
    structured_dividend_ratio_series: dict = {}

    query = f"""select payment_date, dividend_amount, dividend_ratio
    from etf.etf_historical_dividend ecd 
    where ecd.etf_ticker = '{etf_ticker}' and payment_date >= current_date - interval '{start_point} year'
    order by payment_date asc
    """

    try:
        db_response = db_connector.execute(command=query)
        if db_response:
            for item in db_response:
                if isinstance(item.get("payment_date"), datetime):
                    structured_dividend_amount_series[item.get("payment_date").strftime("%Y%m%d")] = item["dividend_amount"]
                    structured_dividend_ratio_series[item.get("payment_date").strftime("%Y%m%d")] = item["dividend_ratio"]
    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO

    return structured_dividend_amount_series, structured_dividend_ratio_series


def get_average_trading_volume(etf_ticker: str, start_point: int = 1, date_type: str = "month") -> int:
    query = f"""select COALESCE(ROUND(AVG(total_trade_volume)), 0) as average_trading_volume
    from etf.etf_historical_statistics ecp
    where ecp.etf_ticker = '{etf_ticker}' 
    and recorded_date > current_date - interval '{start_point} {date_type}'
    """
    average_trading_volume = 0
    try:
        db_response = db_connector.execute(command=query)
        if db_response:
            for item in db_response:
                if item.get("average_trading_volume"):
                    average_trading_volume = int(item.get("average_trading_volume"))
    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO

    return average_trading_volume


def get_recommended_products(market_class_3: str) -> list[dict]:
    recommended_products = []
    query = f"""
    select * from (
        select erm.etf_ticker,                                  -- 티커
            erm.etf_name,                                       -- etf 이름
            erm.isin as fund_code,                              -- 펀드 코드
            erm.market_class_1,                                 -- 국내외 구분
            erm.market_class_3,                                 -- 업종 섹터
            erm.personal_pension,                               -- 개인 연금 여부
            erm.retirement_pension,                             -- 퇴직 연금 여부
            erm.closing_price,                                  -- 전일 종가, 현재가
            erm.risk_level,                                     -- 위험등급
            erm.management_firm,                                -- 운용사
            entr.nav_total_return_1month as total_return_1month -- 한달 수익률
        from etf.etf_recent_master erm
        left join etf.etf_nav_total_return entr on erm.etf_ticker = entr.etf_ticker
        -- "ACE 미국빅테크TOP7 Plus", "ACE CD금리&초단기채권액티브", "ACE 글로벌반도체TOP4 Plus SOLACTIVE" 상품으로 고정
        where erm.etf_ticker in ('446770', '487340', '465580')
    ) as a
    order by a.total_return_1month desc
    """
    # where brand = 'ACE'
    # and (erm.market_class_3 = '{market_class_3}' or (entr.nav_total_return_1day > 0 and entr.nav_total_return_1week > 0))
    # order by random()
    # limit 3
    try:
        db_response = db_connector.execute(command=query)
        if db_response and len(db_response) > 0:
            for item in db_response:
                dict_data = dict(item)
                fund_code = dict_data.get("fund_code")
                dict_data["ace_etf_url"] = f"https://www.aceetf.co.kr/fund/{fund_code}"
                dict_data.pop("fund_code")
                recommended_products.append(dict_data)
    except Exception as ex:
        logging.fatal(ex)
        pass

    return recommended_products


def parse_json_string(input_string, keys):
    # Remove problematic characters
    clean_string = re.sub(r'[{}]', '', input_string)

    # Create pattern based on keys
    pattern_parts = [f'\\s*"{key}":\\s*"(.*?)"' for key in keys]
    pattern = ','.join(pattern_parts)

    # Find potential JSON objects
    full_pattern = f'{pattern}'
    matches = re.findall(full_pattern, clean_string)

    # Convert matches into a list of dictionaries
    json_data = [{keys[i]: match[i] for i in range(len(keys))} for match in matches]

    return json_data


async def get_etf_preset():
    extracted_etf_ticker: list = cl.user_session.get("extracted_etf_ticker")

    if extracted_etf_ticker is not None and len(extracted_etf_ticker) > 0:
        append_ticker: str = ""
        try:
            for index, etf_ticker in enumerate(extracted_etf_ticker):
                append_ticker += f"'{etf_ticker}'"
                if index != len(extracted_etf_ticker) - 1:
                    append_ticker += ","

            structured_recent_master: list = get_recent_master_with_price_information(
                etf_ticker=append_ticker
            )
            # Make sure that ACE ETF comes first
            structured_recent_master.sort(key=lambda x: x.get('etf_name'))

            for index, obj in enumerate(structured_recent_master):
                close_price_and_trade_volume_chart: list = get_closing_price_and_trade_volume(
                    etf_ticker=obj.get('etf_ticker'),
                    start_point=1
                )

                if close_price_and_trade_volume_chart:
                    structured_recent_master[index].update({
                        "close_price_and_trade_volume_series": close_price_and_trade_volume_chart
                    })

                average_trading_volume: int = get_average_trading_volume(
                    etf_ticker=obj.get('etf_ticker'),
                    start_point=1,
                    date_type="month"
                )
                if close_price_and_trade_volume_chart:
                    structured_recent_master[index].update({
                        "average_monthly_volume": average_trading_volume
                    })

            if append_ticker != "":
                elements: list = []
                content = "질문 하신 ETF에 대한 기본 정보는 다음과 같습니다."
                if len(structured_recent_master) == 0:
                    content = "질문 하신 ETF에 대한 정보를 찾을 수 없습니다."
                else:
                    cl_meta_card = cl.Text(
                        name="meta_card",
                        content=json_utils.dumps(structured_recent_master),
                        display="inline"
                    )
                    cl_meta_card.type = "meta_card"
                    elements.append(cl_meta_card)

                if len(structured_recent_master) == 1:
                    ## 구성 정보 카드
                    structured_portfolio_deposit_files: dict = get_portfolio_deposit_file(
                        etf_ticker=structured_recent_master[0].get('etf_ticker'),
                        is_basic_card=True
                    )
                    cl_portfolio_deposit_file = cl.Text(
                        name="portfolio_deposit_file_card",
                        content=json_utils.dumps(structured_portfolio_deposit_files),
                        display="inline"
                    )
                    cl_portfolio_deposit_file.type = "meta_card"
                    elements.append(cl_portfolio_deposit_file)

                    ## 분배급 지급 내역
                    structured_dividend_series: dict = get_cumulative_dividend(
                        etf_ticker=structured_recent_master[0].get('etf_ticker'),
                        is_basic_card=True
                    )

                    cl_dividend_series = cl.Text(
                        name="cumm_dividend_series_card",
                        content=json_utils.dumps(structured_dividend_series),
                        display="inline"
                    )
                    cl_dividend_series.type = "meta_card"
                    elements.append(cl_dividend_series)

                    ## 관련 컨텐츠
                    structured_recent_master_with_addons: dict = get_recent_master_with_addons_information(
                        etf_ticker=structured_recent_master[0].get('etf_ticker')
                    )
                    cl_recent_master_with_addons = cl.Text(
                        name="addons_card",
                        content=json_utils.dumps(structured_recent_master_with_addons),
                        display="inline",
                    )
                    cl_recent_master_with_addons.type = "meta_card"
                    elements.append(cl_recent_master_with_addons)

                msg = cl.Message(content=content, elements=elements)
                await msg.send()

                # elements: list = []
                if len(structured_recent_master) == 1 and len(elements) > 2:
                    ## 추천 상품
                    structured_recommended_products: list = get_recommended_products(
                        market_class_3=structured_recent_master[0].get('market_class_3')
                    )

                    cl_recommended_products = cl.Text(
                        name="recommended_products_card",
                        content=json_utils.dumps(structured_recommended_products),
                        display="inline"
                    )
                    cl_recommended_products.type = "meta_card"
                    # elements.append(cl_recommended_products)
                    # content = "질문하신 ETF에 대한 추천 상품 Top 3의 정보는 다음과 같습니다."
                    content = "다음과 같은 ETF도 한번 살펴보세요."
                    msg = cl.Message(content=content, elements=[cl_recommended_products])
                    await msg.send()

            if len(extracted_etf_ticker) == 1:
                cl.user_session.set("macro_history_ticker", extracted_etf_ticker)
            elif len(extracted_etf_ticker) == 2:
                # cl.user_session.set("macro_history_ticker", None)
                extracted_etf_ticker.pop(1)
                cl.user_session.set("macro_history_ticker", extracted_etf_ticker)
            cl.user_session.set("extracted_etf_ticker", None)
        except Exception as ex:
            logging.fatal(ex)


async def get_etf_portfolio_preset():
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    extracted_etf_ticker: list = cl.user_session.get("extracted_etf_ticker")
    # 후속 질문에 포함될 경우 실행
    if extracted_etf_ticker is None or len(extracted_etf_ticker) == 0:
        if macro_history_ticker is not None and len(macro_history_ticker) > 0:
            extracted_etf_ticker = macro_history_ticker
        else:
            return

    try:
        # Same as In Rust iterator.get(index: usize).unwrap()
        # Safe way to get value in index 0, if it gets empty list it will raise assertion.
        append_ticker: str = next(iter(extracted_etf_ticker))
        structured_portfolio_deposit_files: dict = get_portfolio_deposit_file(
            etf_ticker=append_ticker,
            is_single_card=True
        )
        cl_portfolio_deposit_file = cl.Text(
            name="portfolio_deposit_file_card",
            content=json_utils.dumps(structured_portfolio_deposit_files),
            display="inline"
        )
        cl_portfolio_deposit_file.type = "meta_card"
        elements: list = [cl_portfolio_deposit_file]
        content = "질문 하신 ETF에 대한 구성 종목 Top10 정보는 다음과 같습니다."
        msg = cl.Message(content=content, elements=elements)
        await msg.send()

        ### AI 메시지 처럼 변화 비중 출력하도록 구현 시작 ###
        portfolio_etf_name = structured_portfolio_deposit_files.get("etf_name")
        portfolio_data: list = structured_portfolio_deposit_files.get("data")

        content = ""
        # 기준 ETF 상품만 갖고 있는 구성 종목
        portfolio_product_msg = [f"**'{portfolio_etf_name}'** 상품에 대한 '구성 종목 Top 10' 정보는 다음과 같습니다. \n\n"]
        for i, value in enumerate(portfolio_data):
            portfolio_product_msg.append(f"{i + 1}. {value["name"]} (비중: {value["size"]}%)")
        if len(portfolio_product_msg) > 1:
            content += "\n".join(portfolio_product_msg) + "\n"
            # 메시지 출력
            msg = await cl.Message(content="").send()
            if content != "":
                newline_token_list = content.split('\n')
                # 출력할 토큰이 많을 경우 개행 과 띄어쓰기 기준으로 뿌려주도록 제한
                if len(newline_token_list) > 0:
                    for newline_str in newline_token_list:
                        newline_str += '\n'
                        for white_space_token in newline_str.split(' '):
                            await msg.stream_token(white_space_token + ' ')
                    await msg.update()
        ### AI 메시지 처럼 변화 비중 출력하도록 구현 종료 ###

    except StopIteration as e:
        elements = None
        content = "해당 ETF는 포트폴리오 정보가 존재하지 않거나, 데이터를 찾을 수 없습니다."
        msg = cl.Message(content=content, elements=elements)
        await msg.send()
        logging.fatal(e)

    except Exception as ex:
        logging.fatal(ex)

    finally:
        cl.user_session.set("macro_history_ticker", extracted_etf_ticker)
        cl.user_session.set("extracted_etf_ticker", None)


async def get_changed_portfolio_presets():
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    extracted_etf_ticker: list = cl.user_session.get("extracted_etf_ticker")
    if extracted_etf_ticker is None or len(extracted_etf_ticker) == 0:
        if macro_history_ticker is not None and len(macro_history_ticker) > 0:
            extracted_etf_ticker = macro_history_ticker
        else:
            return
        
    try:
        append_ticker: str = next(iter(extracted_etf_ticker))
        # 비교 구성종목 정보
        structured_changed_portfolio_deposit_files: dict = get_changed_portfolio_deposit_file(
            etf_ticker=append_ticker
        )
        cl_changed_portfolio_deposit_file = cl.Text(
            # name="historical_portfolio_deposit_file_card",
            name="portfolio_deposit_file_card",
            content=json_utils.dumps(structured_changed_portfolio_deposit_files),
            display="inline"
        )
        cl_changed_portfolio_deposit_file.type = "meta_card"
        # 최신 구성종목 정보
        structured_portfolio_deposit_files: dict = get_portfolio_deposit_file(
            etf_ticker=append_ticker
        )

        if any([len(structured_portfolio_deposit_files) == 0, len(structured_changed_portfolio_deposit_files) == 0]):
            raise StopIteration("No date to compare.")

        cl_portfolio_deposit_file = cl.Text(
            name="portfolio_deposit_file_card",
            content=json_utils.dumps(structured_portfolio_deposit_files),
            display="inline"
        )
        cl_portfolio_deposit_file.type = "meta_card"
        elements = [cl_changed_portfolio_deposit_file, cl_portfolio_deposit_file]

        content = "질문 하신 ETF에 대한 '구성 종목 Top10' 변화 정보는 다음과 같습니다."
        msg = cl.Message(content=content, elements=elements)
        await msg.send()

    except StopIteration as e:
        elements = None
        content = "해당 ETF는 포트폴리오 정보가 존재하지 않거나, 데이터를 찾을 수 없습니다."
        msg = cl.Message(content=content, elements=elements)
        await msg.send()
        logging.fatal(e)

    except Exception as ex:
        logging.fatal(ex)
    finally:
        cl.user_session.set("macro_history_ticker", extracted_etf_ticker)
        cl.user_session.set("extracted_etf_ticker", None)


async def get_etf_dividend_series_preset():
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    extracted_etf_ticker: list = cl.user_session.get("extracted_etf_ticker")
    # 후속 질문에 포함될 경우 실행
    if extracted_etf_ticker is None or len(extracted_etf_ticker) == 0:
        if macro_history_ticker is not None and len(macro_history_ticker) > 0:
            extracted_etf_ticker = macro_history_ticker
        else:
            return

    fund_code = ""
    try:
        append_ticker: str = next(iter(extracted_etf_ticker))
        structured_dividend_series: dict = get_cumulative_dividend(
            etf_ticker=append_ticker
        )
        fund_code = structured_dividend_series.get("fund_code")
        # If there is no data
        if len(structured_dividend_series.get("data")) == 0:
            raise StopIteration("type 'list' structured_dividend_series is not iterable. or data is empty.")

        cl_dividend_series = cl.Text(
            name="cumm_dividend_series_card",
            content=json_utils.dumps(structured_dividend_series),
            display="inline"
        )
        cl_dividend_series.type = "meta_card"
        elements: list = [cl_dividend_series]
        msg_content = "질문 하신 ETF에 대한 분배금 지급 내역은 다음과 같습니다."
        msg = cl.Message(content=msg_content, elements=elements)
        await msg.send()

    except StopIteration as e:
        elements = None
        # msg_content = "해당 ETF는 분배금 지급 내역이 존재하지 않거나, 데이터를 찾을 수 없습니다."
        msg_content = (f"해당 ETF는 현재까지 분배금을 지급한 내역이 없습니다. 자세한 사항은 운용사 홈페이지에서 확인해 주세요.\n"
                       f"(상품 링크:https://www.aceetf.co.kr/fund/{fund_code})")
        msg = cl.Message(content=msg_content, elements=elements)
        await msg.send()
        print("get_etf_dividend_series_preset - StopIteration :", e)

    except Exception as ex:
        logging.fatal(ex)

    finally:
        cl.user_session.set("macro_history_ticker", extracted_etf_ticker)
        cl.user_session.set("extracted_etf_ticker", None)


async def get_etf_close_price_with_nav_total_preset():
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    extracted_etf_ticker: list = cl.user_session.get("extracted_etf_ticker")
    # 후속 질문에 포함될 경우 실행
    if extracted_etf_ticker is None or len(extracted_etf_ticker) == 0:
        if macro_history_ticker is not None and len(macro_history_ticker) > 0:
            extracted_etf_ticker = macro_history_ticker
        else:
            return

    try:
        append_ticker: str = next(iter(extracted_etf_ticker))
        chart: dict = get_close_price_with_nav_total_information(
            etf_ticker=append_ticker
        )
        cl_meta_card = cl.Text(
            name="close_price_with_nav_total_card",
            content=json_utils.dumps(chart),
            display="inline"
        )
        cl_meta_card.type = "meta_card"
        elements: list = [cl_meta_card]
        content = "질문 하신 ETF에 대한 수익률 정보는 다음과 같습니다."
        msg = cl.Message(content=content, elements=elements)

        await msg.send()

    except StopIteration as e:
        elements = None
        content = "해당 ETF는 수익률 정보가 없거나, 데이터를 찾을 수 없습니다."
        msg = cl.Message(content=content, elements=elements)
        await msg.send()
        logging.fatal(e)

    except Exception as ex:
        logging.fatal(ex)

    finally:
        cl.user_session.set("macro_history_ticker", extracted_etf_ticker)
        cl.user_session.set("extracted_etf_ticker", None)
