import chainlit as cl

import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from datetime import datetime
from matplotlib import rcParams


def prepare_data(data):
    """ 날짜 문자열을 datetime 객체로 변환하고 정렬 """
    data_sorted = sorted(data.items(), key=lambda x: datetime.strptime(x[0], '%Y%m%d'))
    dates = [datetime.strptime(entry[0], '%Y%m%d') for entry in data_sorted]
    values = [entry[1] for entry in data_sorted]
    return dates, values


def create_plot(dates, values, plot_type, ax, label, color, marker=None):
    """ Plot 생성 함수 """
    if plot_type == 'line':
        ax.plot(dates, values, marker=marker, linestyle='-', color=color, label=label)
    elif plot_type == 'bar':
        ax.bar(dates, values, color=color, label=label)


def format_plot(ax, xlabel, ylabel, title=None):
    """ Plot 포맷팅 함수 """
    if title:
        ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=1))
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    ax.legend()


def get_1year_line_plot(etf_name, closing_price):
    rcParams['font.family'] = 'AppleGothic'
    rcParams['axes.unicode_minus'] = False

    plt.title("한글 텍스트", fontname='AppleGothic')
    plt.xlabel("X축 라벨", fontname='AppleGothic')
    plt.ylabel("Y축 라벨", fontname='AppleGothic')

    dates, prices = prepare_data(closing_price)
    fig, ax = plt.subplots(figsize=(12, 8))

    create_plot(dates, prices, 'line', ax, f'{etf_name} Closing Price', 'g', marker='o')
    format_plot(ax, 'Date', 'Closing Price', f'{etf_name} Closing Prices Over Time')

    fig.tight_layout()
    element = cl.Pyplot(name="plot", figure=fig, display="inline", ElementSize="large")
    return element
