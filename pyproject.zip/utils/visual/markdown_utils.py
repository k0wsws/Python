from datetime import datetime
from typing import Any

from utils.number_replacer import number_to_korean


def format_date(date_str: str) -> str:
    try:
        date_obj = datetime.strptime(date_str, "%Y%m%d")
        return f"{date_obj.year}년 {date_obj.month}월 {date_obj.day}일"
    except (ValueError, TypeError):
        return "-"


def validation_empty_value(data_obj: Any) -> str:
    if data_obj and data_obj != '-':
        return data_obj
    return "-"


def get_formatted_markdown_data(data: dict, etf_ticker: str) -> dict:
    formatted_markdown = {"종목코드": etf_ticker.replace('A', ''),}

    if data:
        def safe_value(value, suffix=''):
            if suffix == '%':
                values = f"{'%.2g' % value if isinstance(value, (float, int)) else value}{suffix}" if value != '-' else "-"
            else:
                values = f"{'%.15g' % value if isinstance(value, (float, int)) else value}{suffix}" if value != '-' else "-"
            return values

        formatted_markdown["종목명"] = validation_empty_value(data_obj=data.get("etf_name"))
        formatted_markdown["운용사"] = validation_empty_value(data_obj=data.get("management_firm"))
        formatted_markdown["펀드 유형"] = validation_empty_value(data_obj=data.get("market_class_1"))
        formatted_markdown["상장일"] = format_date(data.get("inception_date"))
        formatted_markdown["추종지수"] = validation_empty_value(data_obj=data.get("tracking_index"))

        aum_value = data.get("asset_under_management")
        aum_value = str(round(int(aum_value) / 100_000_000) * 100_000_000)
        formatted_markdown["운용자산"] = f"{number_to_korean(aum_value)}원" if aum_value != '-' else "-"

        total_expense_ratio = safe_value(data.get("total_expense_ratio"), '')
        formatted_markdown["총보수"] = f"연 {total_expense_ratio}%"

        formatted_markdown["분배금(연평균)"] = safe_value(data.get("recent_dividend_amount"), '원')
        formatted_markdown["분배율"] = safe_value(data.get("dividend_ratio"), '%')
    return formatted_markdown


def convert_to_markdown(data, header_order=None) -> str:
    markdown_str: str = ""

    if isinstance(data, list) and all(isinstance(item, dict) for item in data):
        if not header_order:
            return ""

        main_header_key = header_order[0]

        available_keys = [key for key in header_order if any(key in item for item in data)]

        if main_header_key not in available_keys:
            return ""

        column_headers = [item.get(main_header_key, '') for item in data]

        header_row = "| **" + main_header_key + "** | " + " | ".join(column_headers) + " |"
        separator = "|:---:| " + " | ".join(":---" for _ in data) + " |"
        markdown_str += header_row + "\n" + separator + "\n"

        keys = [key for key in available_keys if key != main_header_key]

        for key in keys:
            row = f"| **{key}** | " + " | ".join(str(item.get(key, '')) if key in item else '' for item in data) + " |"
            markdown_str += row + "\n"
    else:
        return ""

    return markdown_str




