import json
import re
import logging
import chainlit as cl

from datetime import datetime
from dateutil.relativedelta import relativedelta

from utils import json_utils
import requests
from utils.langchain.call_llm_invoke import invoke_llm

from utils.visual.get_etf_preset import (
    get_portfolio_deposit_file,
    get_historical_portfolio_deposit_file,
)

# Disable warning for SSL
requests.packages.urllib3.disable_warnings()


async def get_etf_historical_portfolio_preset(date: str):
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    extracted_etf_ticker: list = cl.user_session.get("extracted_etf_ticker")

    # 후속 질문에 포함될 경우 실행
    if (extracted_etf_ticker is None or len(extracted_etf_ticker) == 0) or (re.match(r"\d{4}-\d{2}-\d{2}", extracted_etf_ticker[-1])):
        if (macro_history_ticker is not None and len(macro_history_ticker) > 0):
            extracted_etf_ticker = macro_history_ticker
        else:
            return
    try:
        append_ticker: str = next(iter(extracted_etf_ticker))
        #최신 구성종목 정보
        structured_portfolio_deposit_files: dict = get_portfolio_deposit_file(
            etf_ticker=append_ticker
        )
        cl_portfolio_deposit_file = cl.Text(
            name="portfolio_deposit_file_card",
            content=json_utils.dumps(structured_portfolio_deposit_files),
            display="inline"
        )
        cl_portfolio_deposit_file.type = "meta_card"
        if structured_portfolio_deposit_files.get("recorded_date") == date:
            transition_date = datetime.strptime(date, '%Y-%m-%d')
            day = 1
            if transition_date.weekday() == 6:
                # 일요일의 경우 2를 빼서 금요일 데이터를 비교 하도록
                day = 2
            date = (transition_date - relativedelta(days=day)).strftime("%Y-%m-%d")
        # 특정 일정 비교 구성종목 정보
        structured_historical_portfolio_deposit_files: dict = get_historical_portfolio_deposit_file(
            etf_ticker=append_ticker,
            date=date
        )
        cl_history_portfolio_deposit_file = cl.Text(
            # name="historical_portfolio_deposit_file_card",
            name="portfolio_deposit_file_card",
            content=json_utils.dumps(structured_historical_portfolio_deposit_files),
            display="inline"
        )
        cl_history_portfolio_deposit_file.type = "meta_card"
        if any([len(structured_portfolio_deposit_files) == 0, len(structured_historical_portfolio_deposit_files) == 0]):
            raise StopIteration("No date to compare.")

        elements = [cl_history_portfolio_deposit_file, cl_portfolio_deposit_file]

        content = "질문 하신 ETF에 대한 '구성 종목 Top10' 변화 정보는 다음과 같습니다.\n"
        msg = cl.Message(content=content, elements=elements)
        await msg.send()

        ### AI 메시지 처럼 변화 비중 출력하도록 구현 시작 ###
        current_data: list = structured_portfolio_deposit_files.get("data")
        current_recorded_date = current_data[0].get("recorded_date").strftime("%Y-%m-%d")
        current_data_remove_idx: list = []

        previous_data: list = structured_historical_portfolio_deposit_files.get("data")
        previous_recorded_date = previous_data[0].get("recorded_date").strftime("%Y-%m-%d")
        previous_data_remove_idx: list = []

        content = f"{previous_recorded_date}와 {current_recorded_date} 일자의 '구성 종목 Top 10' 비중 변화는 다음과 같습니다. \n\n"
        # 구성 종목 비중 차이 메세지 가공
        common_msg = ["- **공통 종목 비중 변화:**"]
        for i, current in enumerate(current_data):
            for j, previous in enumerate(previous_data):
                if current.get("name") == previous.get("name"):
                    diff_size = round((current.get("size") - previous.get("size")), 2)
                    if diff_size < 0:
                        diff_size = f"감소: {abs(diff_size)}%"
                    elif diff_size > 0:
                        diff_size = f"증가: {abs(diff_size)}%"
                    else:
                        diff_size = "변화 없음"
                    common_msg.append(f"**{current.get("name")}** : {previous.get("size")}% -> {current.get("size")}% ({diff_size})")
                    current_data_remove_idx.append(i)
                    previous_data_remove_idx.append(j)
                    break
        if len(common_msg) > 1:
            for i, common in enumerate(common_msg):
                if i > 0:
                    common_msg[i] = f"{i}. {common}"
            content += "\n".join(common_msg) + "\n"

        # 신규 추가된 구성 종목 메세지 가공
        append_product_msg = [f"- **'{current_recorded_date}' Top 10에 신규 추가된 구성 종목:**"]
        if len(current_data_remove_idx) > 0:
            current_data_remove_idx.sort(reverse=True)
            for value in current_data_remove_idx:
                del current_data[value]
        for i, value in enumerate(current_data):
            append_product_msg.append(f"{i + 1}. **{value["name"]}** (비중: {value["size"]}%)")
        if len(append_product_msg) > 1:
            content += "\n".join(append_product_msg) + "\n"

        # 제외된 구성 종목 메세지 가공
        delete_product_msg = [f"- **'{current_recorded_date}' Top 10에서 제외된 구성 종목:**"]
        if len(previous_data_remove_idx) > 0:
            previous_data_remove_idx.sort(reverse=True)
            for value in previous_data_remove_idx:
                del previous_data[value]
        for i, value in enumerate(previous_data):
            delete_product_msg.append(f"{i + 1}. **{value["name"]}** (비중: {value["size"]}%)")
        if len(delete_product_msg) > 1:
            content += "\n".join(delete_product_msg)

        # 변화가 없을 경우 메시지 가공
        if len(common_msg) == 1 and len(append_product_msg) == 1 and len(delete_product_msg) == 1:
            content = f"두 데이터를 비교한 결과, {structured_portfolio_deposit_files.get("etf_name")} ETF의 구성 종목 Top 10 비중에 변화가 없습니다."

        # 메시지 출력
        msg = await cl.Message(content="").send()
        if content != "":
            newline_token_list = content.split('\n')
            # 출력할 토큰이 많을 경우 개행 과 띄어쓰기 기준으로 뿌려주도록 제한
            if len(newline_token_list) > 0:
                for newline_str in newline_token_list:
                    newline_str += '\n'
                    for white_space_token in newline_str.split(' '):
                        await msg.stream_token(white_space_token + ' ')
                await msg.update()
        ### AI 메시지 처럼 변화 비중 출력하도록 구현 종료 ###

        ### LLM 호출 구문 시작 ###
    #         cl.user_session.set("extracted_etf_ticker", extracted_etf_ticker)
    #
    #         previous_recorded_date = ""
    #         previous_data = []
    #         for previous in structured_portfolio_deposit_files.get("data"):
    #             previous_recorded_date = previous.get("recorded_date").strftime("%Y-%m-%d")
    #             temp: dict = {
    #                 "previous component name": previous.get("name"),
    #                 "previous component weight": str(previous.get("size")) + "%"
    #             }
    #             previous_data.append(temp)
    #         previous_data_list: dict = {"previous_data": previous_data}
    #
    #         current_recorded_date = ""
    #         current_data = []
    #         for current in structured_historical_portfolio_deposit_files.get("data"):
    #             current_recorded_date = current.get("recorded_date").strftime("%Y-%m-%d")
    #             temp: dict = {
    #                 "current component name": current.get("name"),
    #                 "current component weight": str(current.get("size")) + "%"
    #             }
    #             current_data.append(temp)
    #         current_data_list: dict = {"current_data": current_data}
    #
    # #         invoke_msg = f"""
    # # Question: {structured_portfolio_deposit_files.get("etf_name")} 상품에 대한 '{previous_recorded_date}' 일자와 '{current_recorded_date}' 일자의 구성 종목 별 구성 종목 비중에 대한 변화 정보 알려줘.\n
    # # Observation: {previous} 와 {current} \n
    # # Thought: 최종 답이 {structured_portfolio_deposit_files.get("etf_name")} 제품에 관한 것이 아닌 데이터는 제공하지 마세요.
    # # """
    #         invoke_msg = f"""Question: Please let me know the weight changes of {structured_portfolio_deposit_files.get("etf_name")} products by the '{previous_recorded_date}' and '{current_recorded_date}' day components.
    # Observation: previous data is '{json.dumps(previous_data_list)}' and current data is '{json.dumps(current_data_list)}'
    # Thought: Please do not provide any data whose final answer is not about {structured_portfolio_deposit_files.get("etf_name")} products. and Please highlight the components. and mention all components of the {previous_recorded_date} and {current_recorded_date} products.
    # """
    #         await invoke_llm(json.dumps(invoke_msg))
    ### LLM 호출 구문 종료 ###

    except StopIteration as e:
        elements = None
        content = "해당 ETF는 포트폴리오 정보가 존재하지 않거나, 데이터를 찾을 수 없습니다."
        msg = cl.Message(content=content, elements=elements)
        await msg.send()
        logging.fatal(e)

    except Exception as ex:
        logging.fatal(ex)
    finally:
        cl.user_session.set("macro_history_ticker", extracted_etf_ticker)
        cl.user_session.set("extracted_etf_ticker", None)


async def get_similar_portfolio_presets():
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    extracted_etf_ticker: list = cl.user_session.get("extracted_etf_ticker")
    if extracted_etf_ticker is None or len(extracted_etf_ticker) == 0:
        if macro_history_ticker is not None and len(macro_history_ticker) > 1:
            extracted_etf_ticker = macro_history_ticker
        else:
            return
    if len(extracted_etf_ticker) != 2:
        raise ValueError("extracted_etf_ticker must have 2 elements.")
    try:
        structured_portfolio_deposit_files1: dict = get_portfolio_deposit_file(
            etf_ticker=extracted_etf_ticker[0]
        )
        structured_portfolio_deposit_files2: dict = get_portfolio_deposit_file(
            etf_ticker=extracted_etf_ticker[1]
        )

        if any([len(structured_portfolio_deposit_files1) == 0, len(structured_portfolio_deposit_files2) == 0]):
            raise StopIteration("No date to compare.")

        cl_portfolio_deposit_file1 = cl.Text(
            name="portfolio_deposit_file_card",
            content=json_utils.dumps(structured_portfolio_deposit_files1),
            display="inline"
        )
        cl_portfolio_deposit_file1.type = "meta_card"
        cl_portfolio_deposit_file2 = cl.Text(
            name="portfolio_deposit_file_card",
            content=json_utils.dumps(structured_portfolio_deposit_files2),
            display="inline"
        )
        cl_portfolio_deposit_file2.type = "meta_card"
        elements = [cl_portfolio_deposit_file1, cl_portfolio_deposit_file2]
        content = "유사한 ETF 상품에 대한 '구성 종목 Top10' 비교 정보는 다음과 같습니다."
        msg = cl.Message(content=content, elements=elements)
        await msg.send()

        ### AI 메시지 처럼 변화 비중 출력하도록 구현 시작 ###
        reference_etf_name = structured_portfolio_deposit_files1.get("etf_name")
        reference_data: list = structured_portfolio_deposit_files1.get("data")
        reference_data_remove_idx: list = []

        # reference_recorded_date = reference_data[0].get("recorded_date").strftime("%Y-%m-%d")

        comparison_etf_name = structured_portfolio_deposit_files2.get("etf_name")
        comparison_data: list = structured_portfolio_deposit_files2.get("data")
        comparison_data_remove_idx: list = []

        content = f"**'{reference_etf_name}'** 와 **'{comparison_etf_name}'** 상품에 대한 '구성 종목 Top 10' 비교 정보는 다음과 같습니다. \n\n"
        # 구성 종목 비중 차이 메세지 가공
        common_msg = ["- **공통적으로 포함된 구성 종목:**"]
        for i, reference in enumerate(reference_data):
            for j, comparison in enumerate(comparison_data):
                if reference.get("name") == comparison.get("name"):
                    common_msg.append(f"**{comparison.get("name")}** : {reference_etf_name} ({reference.get("size")}%) **vs** {comparison_etf_name} ({comparison.get("size")}%)")
                    reference_data_remove_idx.append(i)
                    comparison_data_remove_idx.append(j)
                    break

        # 기준 ETF 상품만 갖고 있는 구성 종목
        reference_product_msg = [f"- **'{reference_etf_name}' 고유 구성 종목:**"]
        if len(reference_data_remove_idx) > 0:
            reference_data_remove_idx.sort(reverse=True)
            for value in reference_data_remove_idx:
                del reference_data[value]
        for i, value in enumerate(reference_data):
            reference_product_msg.append(f"{i + 1}. {value["name"]} (비중: {value["size"]}%)")
        if len(reference_product_msg) > 1:
            content += "\n".join(reference_product_msg) + "\n"

        # 비교 대상 ETF 상품만 갖고 있는 구성 종목
        comparison_product_msg = [f"- **'{comparison_etf_name}' 고유 구성 종목:**"]
        if len(comparison_data_remove_idx) > 0:
            comparison_data_remove_idx.sort(reverse=True)
            for value in comparison_data_remove_idx:
                del comparison_data[value]
        for i, value in enumerate(comparison_data):
            comparison_product_msg.append(f"{i + 1}. {value["name"]} (비중: {value["size"]}%)")
        if len(comparison_product_msg) > 1:
            content += "\n".join(comparison_product_msg) + "\n"

        # 공통된 내용이 있을 경우 메시지
        if len(common_msg) > 1:
            for i, common in enumerate(common_msg):
                if i > 0:
                    common_msg[i] = f"{i}. {common}"
            content += "\n".join(common_msg) + "\n"
        elif len(common_msg) == 1:
            # 공통된 내용이 없을 경우 메시지
            content += f"\n'{reference_etf_name}' 와 '{comparison_etf_name}' 상품의 구성 종목을 비교한 결과, 중복되는 구성 종목은 존재하지 않습니다."

        # 메시지 출력
        msg = await cl.Message(content="").send()
        if content != "":
            newline_token_list = content.split('\n')
            # 출력할 토큰이 많을 경우 개행 과 띄어쓰기 기준으로 뿌려주도록 제한
            if len(newline_token_list) > 0:
                for newline_str in newline_token_list:
                    newline_str += '\n'
                    for white_space_token in newline_str.split(' '):
                        await msg.stream_token(white_space_token + ' ')
                await msg.update()
        ### AI 메시지 처럼 변화 비중 출력하도록 구현 종료 ###


        ###### LLM 호출 구문 시작 ######
#         cl.user_session.set("extracted_etf_ticker", extracted_etf_ticker)
#
#         reference_target_etf_name = structured_portfolio_deposit_files1.get("etf_name")
#         reference_target_data = []
#         for data in structured_portfolio_deposit_files1.get("data"):
#             reference_target_data.append({
#                 f"name": data.get("name"),
#                 f"weight": str(data.get("size")) + "%"
#             })
#         reference_target_data_list: dict = {reference_target_etf_name: reference_target_data}
#
#         comparison_target_etf_name = structured_portfolio_deposit_files2.get("etf_name")
#         comparison_target_data = []
#         for data in structured_portfolio_deposit_files2.get("data"):
#             comparison_target_data.append({
#                 f"name": data.get("name"),
#                 f"weight": str(data.get("size")) + "%"
#             })
#         comparison_target_data_list: dict = {comparison_target_etf_name: comparison_target_data}
#
#         #         invoke_msg = f"""
#         # Question: {reference_target_etf_name}와 {comparison_target_etf_name}의 구성 종목 비중 차이를 비교해줘. \n
#         # 1. 공통된 구성 종목이 있다면 구성 종목 비중 차이를 비교해주고 공통된 구성 종목이 없다면 구성 종목만 나열해줘 \n
#         # Observation: {reference_target_etf_name}의 데이터 {reference_target_data_list} 와 {comparison_target_etf_name}의 데이터 {comparison_target_data_list} \n
#         # """
#         invoke_msg = f"""Question: Please compare the proportion of components for {reference_target_etf_name} and {comparison_target_etf_name} products.
# 1. If there is a common composition item, compare the weight difference of the composition item, and if there is no common composition item, list only the composition item.
# Observation: {reference_target_etf_name} data is '{json.dumps(reference_target_data_list)}' and {comparison_target_etf_name} data is '{json.dumps(comparison_target_data_list)}'
# Thought: Please do not provide any data whose final answer is not about {reference_target_etf_name} and {comparison_target_etf_name} products. And The maximum token of the final answer should not exceed 1547353. Please mention all components of the {reference_target_etf_name} and {comparison_target_etf_name} products.
# """
#         await invoke_llm(json.dumps(invoke_msg))
        ###### LLM 호출 구문 종료 ######

    except Exception as ex:
        logging.fatal(ex)
    finally:
        cl.user_session.set("macro_history_ticker", extracted_etf_ticker)
        cl.user_session.set("extracted_etf_ticker", None)
