from langfuse.callback import CallbackHandler as LangfuseCallbackHandler
from langchain.schema.output import LLMResult
from typing import Any, Optional
from uuid import UUID


class LangfuseCallbackWrapperHandler(LangfuseCallbackHandler):
    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ):
        usage = response.llm_output["token_usage"]
        is_langfuse_usage = any(k in usage for k in (
            "input", "output", "total", "usage"))
        is_openai_usage = any(
            k in usage
            for k in (
                "promptTokens",
                "prompt_tokens",
                "completionTokens",
                "completion_tokens",
                "totalTokens",
                "total_tokens",
            )
        )

        if not is_langfuse_usage and not is_openai_usage:
            response.llm_output["token_usage"] = {"total": 0}

        super().on_llm_end(response=response, run_id=run_id,
                           parent_run_id=parent_run_id, **kwargs)
