from langfuse import Langfuse
from langfuse.callback import CallbackHandler as LangfuseCallbackHandler

def create_prompt(name, prompt, config):
    """
        langfuse에 prompt 등록해주는 함수

        Args:
            name: prompt 이름
            prompt: prompt 내용
            config: prompt config

        history: juntae kim 2024-04-22 신규작성
    """
    langfuse = Langfuse()

    # Initialize Langfuse CallbackHandler for Langchain (tracing)
    langfuse_callback_handler = LangfuseCallbackHandler()
    
    # Optional, verify that Langfuse is configured correctly
    assert langfuse.auth_check()
    assert langfuse_callback_handler.auth_check()

    langfuse.create_prompt(
        name=name,
        prompt=prompt,
        config=config,
        is_active=True
        #labels=["production"]
    )