import subprocess

def _get_username_from_ps(default="unknown_user"):
        
    try :
      # Find python process and check the user running
      ps = subprocess.Popen(['/bin/ps', '-o', 'comm,pid,user'],stdout=subprocess.PIPE).stdout.read().decode('utf-8')
      pss = ps.split()
      offset = [i for i, e in enumerate(pss) if e in ['python', 'chainlit']][0]

      return pss[offset - pss.index('COMMAND') + pss.index('USER')]
    except :
        return default