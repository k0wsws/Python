import re
import math


def number_to_korean(number) -> str:
    korean_expression: str = ""
    integer_part, decimal_part = str(number).split('.') if '.' in str(number) else (str(number), '')

    units: list = ['', '만', '억', '조', '경']

    reversed_digits = list(reversed(integer_part))

    if len(reversed_digits) < 5:
        return str(number)

    for i in range(0, len(reversed_digits), 4):
        part = ''.join(reversed_digits[i:i + 4])[::-1]
        if int(part) != 0:
            part = str(int(part))
            korean_expression = f"{int(part):,}{units[i // 4]} " + korean_expression

    korean_expression = korean_expression.strip()
    return f"{korean_expression}"


def replace_with_korean(column, number):
    if column == "asset_under_management":
        number = str(round(int(number) / 100_000_000) * 100_000_000)
    korean_number: str = number_to_korean(number)
    return korean_number


def replace_realtime_etf_info(db_response: dict) -> dict:
    key_columns: dict = {
        # etf_recent_master
        "inception_date": {"description": "상장일자"},
        "inverse": {"description": "인버스 ETF 여부"},
        "asset_under_management": {"description": "운용자산(AUM)", "unit": "원", "need_replace_korean": True},
        "closing_price": {"description": "전일 종가", "unit": "원", "need_replace_korean": True},
        "net_asset_value": {"description": "순자산가치(NAV)", "unit": "원", "need_replace_korean": True},
        "total_trade_volume": {"description": "전일 거래량", "unit": "주"},
        "total_trade_value": {"description": "전일 거래대금", "unit": "원"},
        "total_expense_ratio": {"description": "총보수", "unit": "%"},
        "management_fee_ratio": {"description": "운용보수", "unit": "%"},
        "sell_fee_ratio": {"description": "판매보수", "unit": "%"},
        "custody_fee_ratio": {"description": "신탁보수", "unit": "%"},
        "back_fee_ratio": {"description": "일반사무보수", "unit": "%"},
        "beta": {"description": "베타", "unit": "%", "percentage": True},
        "alpha": {"description": "알파", "unit": "%", "percentage": True},
        "disparate_ratio": {"description": "괴리율", "unit": "%"},
        "recent_dividend_amount": {"description": "최근 분배한 금액", "unit": "원"},
        "recent_dividend_ratio": {"description": "최근 분배율", "unit": "%"},
        "annual_dividend_amount": {"description": "1년동안 분배한 금액", "unit": "원"},
        "annual_dividend_ratio": {"description": "연간 분배율", "unit": "%"},

        # etf_recent_investor_value
        "institution_trade_amount": {"description": "기관거래순매수대금", "unit": "만원"},
        "institution_trade_quantity": {"description": "기관거래순매수량", "unit": "주"},
        "foreign_trade_amount": {"description": "외국인거래순매수대금", "unit": "만원"},
        "foreign_trade_quantity": {"description": "외국인거래순매수량", "unit": "주"},
        "individual_trade_amount": {"description": "개인거래순매수대금", "unit": "만원"},
        "individual_trade_quantity": {"description": "개인거래순매수량", "unit": "주"},

        # etf_close_price_return
        "price_return_1day": {"description": "전일 종가 수익률", "unit": "%"},
        "price_return_1week": {"description": "1주일간 종가 수익률", "unit": "%"},
        "price_return_1month": {"description": "1달간 종가 수익률", "unit": "%"},
        "price_return_3month": {"description": "3달간 종가 수익률", "unit": "%"},
        "price_return_6month": {"description": "6달간 종가 수익률", "unit": "%"},
        "price_return_1year": {"description": "1년간 종가 수익률", "unit": "%"},
        "price_return_3year": {"description": "3년간 종가 수익률", "unit": "%"},
        "price_return_year_to_date": {"description": "올초부터 현재까지의 종가 수익률", "unit": "%"},
        "cumulative_price_return": {"description": "상장 후 현재까지의 종가 수익률", "unit": "%"},

        # etf_close_price_total_return
        "price_total_return_1day": {"description": "전일 종가 기준 총수익률(TR)", "unit": "%"},
        "price_total_return_1week": {"description": "1주일간 종가 기준 총수익률(TR)", "unit": "%"},
        "price_total_return_1month": {"description": "1달간 종가 기준 총수익률(TR)", "unit": "%"},
        "price_total_return_3month": {"description": "3달간 종가 기준 총수익률(TR)", "unit": "%"},
        "price_total_return_6month": {"description": "6달간 종가 기준 총수익률(TR)", "unit": "%"},
        "price_total_return_1year": {"description": "1년간 종가 기준 총수익률(TR)", "unit": "%",},
        "price_total_return_3year": {"description": "3년간 종가 기준 총수익률(TR)", "unit": "%"},
        "price_total_return_year_to_date": {"description": "올초부터 현재까지의 종가 기준 총수익률(TR)", "unit": "%"},
        "cumulative_price_total_return": {"description": "상장 후 현재까지의 종가 기준 총수익률(TR)", "unit": "%"},

        # etf_nav_total_return
        "nav_total_return_1day": {"description": "전일 순자산가치 기준 총수익률(TR)", "unit": "%"},
        "nav_total_return_1week": {"description": "1주간 순자산가치 기준 총수익률(TR)", "unit": "%"},
        "nav_total_return_1month": {"description": "1달간 순자산가치 기준 총수익률(TR)", "unit": "%"},
        "nav_total_return_3month": {"description": "3달간 순자산가치 기준 총수익률(TR)", "unit": "%"},
        "nav_total_return_6month": {"description": "6달간 순자산가치 기준 총수익률(TR)", "unit": "%"},
        "nav_total_return_1year": {"description": "1년간 순자산가치 기준 총수익률(TR)", "unit": "%"},
        "nav_total_return_3year": {"description": "3년간 순자산가치 기준 총수익률(TR)", "unit": "%"},
        "nav_total_return_year_to_date": {"description": "올초부터 현재까지의 순자산가치 기준 총수익률(TR)", "unit": "%"},
        "cumulative_nav_total_return": {"description": "상장 후 현재까지의 순자산가치 기준 총수익률(TR)", "unit": "%"},

        # etf_recent_draw_down
        "draw_down_1week": {"description": "1주간 손실폭", "unit": "%"},
        "draw_down_1month": {"description": "1달간 손실폭", "unit": "%"},
        "draw_down_3month": {"description": "3달간 손실폭", "unit": "%"},
        "draw_down_6month": {"description": "6달간 손실폭", "unit": "%"},
        "draw_down_1year": {"description": "1년간 손실폭", "unit": "%"},
        "draw_down_3year": {"description": "3년간 손실폭", "unit": "%"},
        "draw_down_year_to_date": {"description": "올초부터 현재까지의 손실폭", "unit": "%"},
        "max_draw_down": {"description": "상장 후 현재까지의 손실폭 중 최대 값", "unit": "%"},

        # etf_recent_volatility
        "volatility_1week": {"description": "1주간 변동률", "unit": "%"},
        "volatility_1month": {"description": "1달간 변동률", "unit": "%"},
        "volatility_3month": {"description": "3달간 변동률", "unit": "%"},
        "volatility_6month": {"description": "6달간 변동률", "unit": "%"},
        "volatility_1year": {"description": "1년간 변동률", "unit": "%"},

        # etf_recent_constituent_holdings
        "max_holding_weight": {"description": "합산 비중", "unit": "%", "percentage": True},
        "holding_weight": {"description": "주식 비중", "unit": "%", "percentage": True},
        "holding_shares": {"description": "주식수", "unit": "주"},

        # etf_cumulative_dividend
        "dividend_amount": {"description": "분배금", "unit": "원"},
        "dividend_ratio": {"description": "시중 가격 대비 분배율", "unit": "%", "percentage": True},
    }

    custom_key_columns: dict = {
        # alias 로 지정된 임의의 케이스, 예외 케이스 추가
        ## 해당 key가 컬럼에 일부라도 존재하면 변환하는 방식
        ## ex) cumulative_institution_trade_amount => institution_trade_amount 매칭
        ## <WARNING !!> - 특정 케이스에 핏하게 description을 쓰면 예외가 발생할 수도 있음. ex) "누적" 키워드를 쓰면, 누적이 아닌 질문에 대해서도 고려해야 함.
        "institution_trade_amount": {"description": "누적 기관거래순매수대금", "unit": "만원"}, # cumulative_institution_trade_amount, total_institution_trade_amount
        "foreign_trade_amount": {"description": "누적 외국인거래순매수대금", "unit": "만원"}, # cumulative_foreign_trade_amount, total_foreign_trade_amount
        "individual_trade_amount": {"description": "누적 개인거래순매수대금", "unit": "만원"}, # cumulative_individual_trade_amount, total_individual_trade_amount
    }

    is_replace = False
    for column in db_response.copy().keys():
        if column in key_columns:
            number = db_response.get(column)
            if number is not None:
                if key_columns.get(column, {}).get("need_replace_korean"):
                    db_response[column] = replace_with_korean(column, db_response[column])
                    is_replace = True
                elif key_columns.get(column, {}).get("percentage"):
                    try:
                        if column != "holding_weight" and column != "dividend_ratio":
                            number = float(number) * 100
                            order_of_magnitude = math.floor(math.log10(abs(number)))
                            if order_of_magnitude < 0:
                                factor = 10 ** (1 - order_of_magnitude)
                                number = round(number * factor) / factor
                            else:
                                number = round(float(number), 2)
                        else:
                            number = round(float(number), 2)
                        is_replace = True
                    except ValueError:
                        continue  # SQL Generation Issue

                    db_response[column] = number

            if db_response[column] is not None and key_columns.get(column, {}).get("unit"):
                db_response[column] = f"{db_response[column]}{key_columns.get(column)['unit']}"
                is_replace = True
            db_response[key_columns.get(column)['description']] = db_response.pop(column)
        elif any(each_custom_column in column for each_custom_column in custom_key_columns.keys()):
            for each_custom_column in custom_key_columns.keys():
                target_column = each_custom_column
                if each_custom_column in column:
                    break
            
            if db_response[column] is not None and custom_key_columns.get(target_column, {}).get("unit"):
                db_response[column] = f"{db_response[column]}{custom_key_columns.get(target_column)['unit']}"
                is_replace = True
            ## key를 한글로 바꾸려면 주석 해제. 그러나 <Warning !!> 참조
            #db_response[custom_key_columns.get(target_column)['description']] = db_response.pop(column)
    return db_response, is_replace


def number_replacer(text: str):
    def replace_percentage(match):
        percentage = int(match.group(1)) / 100
        return f'{percentage}'

    update_text = re.sub(r'(\d+)(?:퍼센트|%)', replace_percentage, text)

    return update_text
