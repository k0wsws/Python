import re


def parse_tools(messages, tools):
    """
    전체 input에서 tool prompt parsing하는 함수

        Args:
            messages: input content
            tools: tool 리스트
    
    Returns:
        prompts: prompt parsing values

        history: juntae kim 2024-04-22 신규작성
    """
    sep = ':|'.join(re.escape(tool) for tool in tools + ['Use the following format:'])
    split_parts = re.split(sep, messages)
    cleaned_parts = [part.strip() for part in split_parts]

    prompts = []
    for index in range(1, len(tools) + 1):
        prompt = cleaned_parts[index]
        prompts.append(prompt)

    return prompts
