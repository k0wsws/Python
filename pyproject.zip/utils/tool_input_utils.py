from typing import Any 
from utils import json_utils
import re

def parse(text:str)->dict[Any]:
  """
			:param: agent에서 action input으로 주입되는 tool에 대한 input값(json string)
			:return: action값을 json으로 변환한 값

      해당 부품은 agent에서 tool에대한 input 주입에 대한 parse처리를 전용으로 담당합니다.

			writer: seongjun noh
      date: 
      	2024-04-18 초기 생성
  """
  json_pattern = r'\{.*?\}'
  json_match = re.search(json_pattern, text)
  extracted_text = json_match.group() if json_match else None

  param = {}
  try:
    param = json_utils.loads(extracted_text)
  except Exception as err:
    param = json_utils.parse_markdown_json(extracted_text)
  
  return param