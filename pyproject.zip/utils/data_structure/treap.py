import random

class TreapNode:
    def __init__(self, key):
        self.key = key
        self.priority = random.random()  # 우선순위는 무작위로 설정
        self.left = None
        self.right = None
        self.size = 1  # 서브트리의 크기를 저장하는 속성

class Treap:
    def __init__(self):
        self.root = None

    def _rotate_right(self, node):
        new_root = node.left
        node.left = new_root.right
        new_root.right = node

        # 회전 후 노드의 서브트리 크기 업데이트
        node.size = 1 + self._get_size(node.left) + self._get_size(node.right)
        new_root.size = 1 + self._get_size(new_root.left) + self._get_size(new_root.right)

        return new_root

    def _rotate_left(self, node):
        new_root = node.right
        node.right = new_root.left
        new_root.left = node

        # 회전 후 노드의 서브트리 크기 업데이트
        node.size = 1 + self._get_size(node.left) + self._get_size(node.right)
        new_root.size = 1 + self._get_size(new_root.left) + self._get_size(new_root.right)

        return new_root

    def _get_size(self, node):
        return node.size if node else 0

    def _insert(self, node, key):
        if node is None:
            return TreapNode(key)

        if key == node.key:
            # 중복된 키는 삽입하지 않음
            return node

        if key < node.key:
            node.left = self._insert(node.left, key)
            if node.left.priority > node.priority:
                node = self._rotate_right(node)
        else:
            node.right = self._insert(node.right, key)
            if node.right.priority > node.priority:
                node = self._rotate_left(node)

        # 삽입 후 노드의 서브트리 크기 업데이트
        node.size = 1 + self._get_size(node.left) + self._get_size(node.right)

        return node

    def insert(self, key):
        self.root = self._insert(self.root, key)

    def _inorder(self, node):
        if node is not None:
            yield from self._inorder(node.left)
            yield node.key
            yield from self._inorder(node.right)

    def inorder(self):
        return list(self._inorder(self.root))

    def get_length(self):
        return self._get_size(self.root)  # 트립의 루트 노드의 크기를 반환