import re
import pandas as pd

from utils.vector_data_client import VectorDataClient

class StockDictSingleton:
    _instance = None
    _stock_dict = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(StockDictSingleton, cls).__new__(cls)
            cls._initialize_stock_dict(cls._instance)
        return cls._instance

    @classmethod
    def _initialize_stock_dict(cls, instance):
        df = pd.read_csv('./infra/qdrant_server/initializer/data/stock_name_code.csv')  # TODO: DB Store 로 변경 필요.
        instance._stock_dict = pd.Series(df['JM_KSD_CD'].values, index=df['AGGREGATED_NAMES']).to_dict()

    def get_stock_dict(self):
        return self._stock_dict


async def check_label_existence(extracted_value, stock_dict):
    if extracted_value in stock_dict:
        return stock_dict[extracted_value]
    else:
        res = await VectorDataClient.request(extracted_value, collection="stock-name", limit=5)
        if res and len(res) > 0:
            correct_ticker = res[0]['payload']['stock_code']
        else:
            correct_ticker = None

        return correct_ticker


async def existing_holding_name(sql_dml: str):
    pattern = r"holding_name\s*(?:=\s*[\'\"]([^\'\"]+)[\'\"]|LIKE\s+[\'\"]%([^\'\"]+)%[\'\"]|IN\s*\(\s*([\'\"][^\'\"]+[\'\"](?:\s*,\s*[\'\"][^\'\"]+[\'\"])*\s*)\))"
    split_matches = re.findall(pattern, sql_dml)

    extracted_values = []
    for match in split_matches:
        if match[0]:  # EQUAL case
            extracted_values.append(match[0])
        elif match[1]:  # LIKE case
            extracted_values.append(match[1])
        elif match[2]:  # IN case
            in_values = re.findall(r'[\'\"]([^\'\"]+)[\'\"]', match[2])
            extracted_values.extend(in_values)

    stock_dict = StockDictSingleton().get_stock_dict()

    if 'holding_name IN' in sql_dml:  # IN case
        updated_in_values = []
        for ex_value in extracted_values:
            new_ticker = await check_label_existence(ex_value, stock_dict)
            if new_ticker:
                updated_in_values.append(new_ticker)
            else:
                updated_in_values.append(ex_value)

        if updated_in_values:
            in_clause = ", ".join([f"'{value}'" for value in updated_in_values])
            sql_dml = re.sub(
                r"holding_name\s+IN\s*\([^\)]+\)",
                fr"holding_ticker IN ({in_clause})",
                sql_dml,
                count=1
            )
    else:  # EQUAL or LIKE case # IN case
        for ex_value in extracted_values:
            new_ticker = await check_label_existence(ex_value, stock_dict)
            if new_ticker:
                sql_dml = re.sub(
                    fr"(holding_name\s*=\s*[\'\"]{re.escape(ex_value)}[\'\"]|holding_name\s+LIKE\s+[\'\"]%{re.escape(ex_value)}%[\'\"])",
                    fr"holding_ticker = '{new_ticker}'",
                    sql_dml,
                    count=1
                )

    # print("UPDATE :", sql_dml)

    return sql_dml