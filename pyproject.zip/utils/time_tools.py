import logging
from datetime import datetime, timedelta

from chainlit.custom.database.postgres_connector import db_connector
from sqlalchemy import text


def get_last_weekday():
    current_date = datetime.now()

    if current_date.hour < 8:
        current_date = current_date - timedelta(days=1)

    two_days_ago = current_date - timedelta(days=1)

    if two_days_ago.weekday() >= 5:  # 5: 토요일, 6: 일요일
        two_days_ago = two_days_ago - timedelta(days=(two_days_ago.weekday() - 4))

    return two_days_ago


def get_record_max_date() -> dict:
    query: str = text("""WITH max_date AS (
            SELECT MAX(recorded_date) AS max_recorded_date
            FROM etf.etf_historical_statistics
        )
        SELECT 
            (SELECT MAX(recorded_date)
            FROM etf.etf_historical_statistics 
            WHERE recorded_date <= (max_date.max_recorded_date - INTERVAL '1 DAY')) AS "1d",
            (SELECT MAX(recorded_date)
            FROM etf.etf_historical_statistics 
            WHERE TO_CHAR(recorded_date, 'YYYY-MM-DD') LIKE 
                CONCAT(TO_CHAR(DATE_TRUNC('year', max_date.max_recorded_date - INTERVAL '1 YEAR'), 'YYYY-'), '12%')
            ) AS "ytd"
        FROM max_date;
        """)

    periods: dict = {}

    try:
        fetched_data: list[dict] = db_connector.execute(command=query, fetch="one")
        if fetched_data and len(fetched_data) > 0:
            if fetched_data:
                periods = {
                    '1day': fetched_data[0].get('1d').strftime('%Y-%m-%d'),
                    'year_to_date': fetched_data[0].get('ytd').strftime('%Y-%m-%d')
                }
    except Exception as ex:
        logging.fatal(ex)
        pass  # TODO:

    return periods


def get_specific_date():
    today = datetime.today()
    current_year = today.year

    record_periods: dict = get_record_max_date()

    date_mapping = {
        "연초/년초": record_periods.get('year_to_date', f"{current_year - 1}-12-28")
        # "전일/어제": record_periods.get('1day', get_last_weekday().strftime('%Y-%m-%d')),
    }
    return date_mapping
