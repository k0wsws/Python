import re

import orjson
from decimal import Decimal
from datetime import date, datetime, timedelta
from typing import Any

import json

"""
    해당 부품은 아래의 2가지 목적으로 작성되었습니다.
    1. 느린 python 기본 json 함수
    2. Decimal, Datetime등의 객체가 toString시, 함수명으로 표시/parsing이 어려운 부분 해결
    해당 부품은 agent에서 tool에대한 input 주입에 대한 parse처리를 전용으로 담당합니다.

    writer: seongjun noh
    date: 2024-04-18 초기 생성
"""

"""code block의 language(또는 data type)과 내용을 추출하기 위한 정규식"""
code_block_regexp=re.compile(r"```(\w+)\n(.+)```")

def custom_serializer(obj:Any)->Any:
  """
      :param: 원시형 데이터 외의 python 객체에 대한 default 처리
      :return: 원시형 데이터 대체 값

      직렬화 시, python 객체에 대한 정규화 처리 콜백입니다.

      writer: seongjun noh
      date: 
        2024-04-18 초기 생성
  """
  if isinstance(obj, (Decimal, timedelta)):
      return str(obj)
  elif isinstance(obj, (datetime, date)):
      return obj.isoformat()
  raise TypeError

def dumps(value:dict[Any])->str:
  """
      :param: json을 대표하는 dictionary
      :return: json을 string으로 변환한 값

      json.dumps와 동일합니다.

      writer: seongjun noh
      date: 2024-04-18 초기 생성
  """
  return orjson.dumps(value, default=custom_serializer).decode('utf-8')

def loads(value:str)->dict[Any]:
  """
      :param: json으로 변환하려는 text
      :return: json을 대표하는 dictionary

      json.loads 동일합니다.

      writer: seongjun noh
      date: 2024-04-18 초기 생성
  """
  return orjson.loads(value)


def checks(input_str):
  try:
    # 문자열을 JSON으로 파싱 시도
    parsed_json = json.loads(input_str)
    return True, parsed_json  # JSON 객체를 반환
  except json.JSONDecodeError:
    # JSON 파싱에 실패한 경우
    return False, input_str  # 원본 문자열을 반환


def parse_markdown_json(text:str)->dict[Any]:
  """
      :param: json을 대표하는 code block 텍스트
      :return: json으로 변환하려는 code block style 텍스트

      code block style형식의 text에서 json 데이터 형식일 경우, json을 추출합니다.

      writer: seongjun noh
      date: 2024-04-18 초기 생성
  """
  try:
    res = code_block_regexp.search(text)
    type = res[1]
    body = res[2]
    if type == 'json':
      return loads(body.strip())
  except Exception as err:
    print(err)
    pass
  
  return {}

if __name__ == "__main__":
  print(parse_markdown_json('```json\n  {"a":"b"}```'))