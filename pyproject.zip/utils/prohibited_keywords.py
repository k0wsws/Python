

#금지어 리스트 

PROHIBITED_KEYWORDS = ['러시아', 'Russia']

def contains_prohibited_keyword(text):
    """
    테스트에 금지어가 존재하는지 체크하는 함수 
    """
    return any(keyword.lower() in text.lower() for keyword in PROHIBITED_KEYWORDS)