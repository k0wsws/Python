import chainlit
from chainlit.context import context
from utils.llm_setting.llm_factory import ProvidedModelPresets
from chainlit.input_widget import Select, Switch, Slider

input_widget = [
    Select(
        id="model_preset",
        label="OpenLLM - Model",
        values=[p.name for p in ProvidedModelPresets],
        initial_index=0
    ),
    Switch(id="streaming", label="OpenLLM - Stream Tokens", initial=True),
    Slider(
        id="temperature",
        label="OpenLLM - Temperature",
        initial=0.1,
        min=0,
        max=2,
        step=0.1,
    ),
    Slider(
        id="max_token",
        label="OpenLLM - Max Tokens",
        initial=1024,
        min=0,
        max=4096,
        step=1,
    ),
    Slider(
        id="top_k",
        label="OpenLLM - Top K",
        initial=2,
        min=1,
        max=10,
        step=1,
    ),
    Slider(
        id="repetition_penalty",
        label="OpenLLM - Repetition Penalty",
        initial=1,
        min=0.1,
        max=3,
        step=0.1,
    )

]


def setup_agent_wrapper(func):
    async def wrapper(settings):
        """
        Step 1. 선택된 Preset 식별
        """
        sel_preset_collection = getattr(ProvidedModelPresets, settings['model_preset'])
        sel_preset, sel_preset_attr = sel_preset_collection.name, sel_preset_collection.value

        has_preset_changed = sel_preset != chainlit.user_session.get("prev_sel_preset")

        if has_preset_changed:
            """
            Step 2. Widget의 initial 값 및 `chat_settings` session 강제로 바꾸기
            """

            fixed_input_widget = [{
                    **iw.to_dict(),
                    'initial': sel_preset if iw.id == "model_preset" else sel_preset_attr[iw.id]
                }
                for iw in input_widget
            ]
            await context.emitter.emit("chat_settings", fixed_input_widget)

            """
            Step 3. setup_agent() -> OpenAi API 에 넘겨줄 setting 값 변경.
            """

            for k, v in settings.items():
                if k == "model_preset":
                    continue
                elif settings[k] is not None and sel_preset_attr[k] is not None:
                    settings[k] = sel_preset_collection.value[k]
        else:
            pass  # Do Nothing

        # print("set chat_settings", settings)
        chainlit.user_session.set('chat_settings', settings)

        ret = await func(settings)
        chainlit.user_session.set("prev_sel_preset", sel_preset)
        return ret

    return wrapper
