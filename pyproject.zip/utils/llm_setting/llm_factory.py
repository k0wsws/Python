from langchain_openai import ChatOpenAI
from enum import Enum


class ProvidedModels(Enum):
    QWEN_72B1_5_CHAT = "Qwen/Qwen1.5-72B-Chat"
    COMMAND_R_PLUS_104B = "CohereForAI/c4ai-command-r-plus"
    ORION_14B_CHAT_RAG = "OrionStarAI/Orion-14B-Chat-RAG"
    ORION_14B_CHAT_PLUGIN = "OrionStarAI/Orion-14B-Chat-Plugin"
    EEVE_10B_KOR_INST = "yanolja/EEVE-Korean-Instruct-10.8B-v1.0"
    LLAMA3_70B_INST = "meta-llama/Meta-Llama-3-70B-Instruct"
    QWEN_110B1_5_CHAT = "Qwen/Qwen1.5-110B-Chat"
    # QWEN_72B_Instruct = "Qwen/Qwen2-72B-Instruct"
    # QWEN_72B_Instruct_AWQ = "Qwen/Qwen2-72B-Instruct-AWQ"
    QWEN_72B_Instruct_GPTQ_INT4 = "Qwen/Qwen2-72B-Instruct-GPTQ-Int4"


class ProvidedModelPresets(Enum):
    # QWEN_2_DEFAULT = {
    #     'model': ProvidedModels.QWEN_72B_Instruct_AWQ.value,
    #     'name': 'Qwen_2_default',
    #     'streaming': False,
    #     'temperature': 0.4,
    #     'max_token': 2048,
    #     'top_k': 6,
    #     'repetition_penalty': 1.0
    # }

    QWEN_2_DEFAULT = {
        'model': ProvidedModels.QWEN_72B_Instruct_GPTQ_INT4.value,
        'name': 'Qwen_2_default',
        'streaming': False,
        'temperature': 0.1,
        #'temperature': 0.4,
        'max_token': 2048,
        'top_k': 6,
        'repetition_penalty': 1.0
    }

    # QWEN_2_DEFAULT = {
    #     'model': ProvidedModels.QWEN_72B_Instruct.value,
    #     'name': 'Qwen_2_default',
    #     'streaming': False,
    #     'temperature': 0.4,
    #     'max_token': 2048,
    #     'top_k': 6,
    #     'repetition_penalty': 1.0
    # }

    QWEN_1_5_DEFAULT = {
        'model': ProvidedModels.QWEN_72B1_5_CHAT.value,
        'name': 'Qwen_1.5_default',
        'streaming': False,
        'temperature': 0.1,
        'max_token': 2048,
        'top_k': 6,
        'repetition_penalty': 1.0
    }
    COMMANDR_PLUS_104B_DEFAULT = {
        'model': ProvidedModels.COMMAND_R_PLUS_104B.value,
        'name': 'CommandR+_104b_default',
        'streaming': False,
        'temperature': 0.1,
        'max_token': 4096,
        'top_k': 3,
        'repetition_penalty': 1.0
    }
    LLAMA3_70B_INST = {
        'model': ProvidedModels.LLAMA3_70B_INST.value,
        'name': 'Meta-Llama-3-70B-Instruct_default',
        'streaming': False,
        'temperature': 0.1,
        'max_token': 4096,
        'top_k': 3,
        'repetition_penalty': 1.0
    }
    ORION_14B_RAG_DEFAULT = {
        'model': ProvidedModels.ORION_14B_CHAT_RAG.value,
        'name': 'Orion_14b_chat_rag_default',
        'streaming': False,
        'temperature': 0.3,
        'max_token': 1024,
        'top_k': 4,
        'repetition_penalty': 1.0
    }
    ORION_14B_PLUGIN_DEFAULT = {
        'model': ProvidedModels.ORION_14B_CHAT_PLUGIN.value,
        'name': 'Orion_14b_chat_plugin_default',
        'temperature': 0.3,
        'max_token': 1024,
        'top_k': 6,
        'repetition_penalty': 1.0
    }
    EEVE_10B_DEFAULT = {
        'model': ProvidedModels.EEVE_10B_KOR_INST.value,
        'name': 'Eeve_10b_default',
        'temperature': 0.3,
        'max_token': 1024,
        'top_k': 6,
        'repetition_penalty': 1.0
    }
    QWEN_1_5_110B_DEFAULT = {
        'model': ProvidedModels.QWEN_110B1_5_CHAT.value,
        'name': 'Qwen_1.5_110b_default',
        'streaming': False,
        'temperature': 0.1,
        'max_token': 2048,
        'top_k': 6,
        'repetition_penalty': 1.0
    }


## TODO: Make code to handle more model

llm_base_url_dict = {
    # ProvidedModels.QWEN_72B_Instruct_AWQ.value: "http://10.8.12.8:8000/v1",
    ProvidedModels.QWEN_72B_Instruct_GPTQ_INT4.value: "http://10.0.0.159:8000/v1",
    # ProvidedModels.QWEN_72B_Instruct.value: "http://10.0.0.159:7000/v1",
    ProvidedModels.COMMAND_R_PLUS_104B.value: "http://10.0.0.159:7001/v1",
    ProvidedModels.ORION_14B_CHAT_RAG.value: "http://10.0.1.60:7000/v1",
    ProvidedModels.ORION_14B_CHAT_PLUGIN.value: "http://10.0.1.60:7001/v1",
    ProvidedModels.EEVE_10B_KOR_INST.value: "http://10.0.1.60:7002/v1",
    ProvidedModels.LLAMA3_70B_INST.value: "http://10.8.12.8:7002/v1",
    ProvidedModels.QWEN_110B1_5_CHAT.value: "http://10.0.0.159:7007/v1",
}


class LLMManager:
    def __init__(self, settings):
        self._settings = settings
        self._preset = getattr(ProvidedModelPresets,
                               settings['model_preset']).value

    @property
    def llm(self):
        llm = ChatOpenAI(
            base_url=llm_base_url_dict[self._preset["model"]],
            openai_api_key="dummy",
            model=self._preset["model"],  # "Qwen/Qwen-72B-Chat",
            temperature=self._settings["temperature"],  # 0.1
            max_tokens=self._settings["max_token"],  # 2048,
            streaming=self._settings.get("streaming", False),
            extra_body={
                "top_k": self._settings["top_k"],
                "repetition_penalty": self._settings["repetition_penalty"],
                "stop": ["<|endoftext|>", "<|im_end|>",
                         "<|im_start|>", "\nObservation:", "\nObserv"],
            })
        return llm
