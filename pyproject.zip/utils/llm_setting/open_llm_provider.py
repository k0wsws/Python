from chainlit.playground.config import BaseProvider
from typing import Dict, Optional
from fastapi.responses import StreamingResponse
from langchain.schema.runnable.config import RunnableConfig
from utils.llm_setting.llm_factory import LLMManager
from utils.langfuse.get_username import _get_username_from_ps
from langfuse.callback import CallbackHandler as LangfuseCallbackHandler
from utils.llm_setting.setup_utils import input_widget
import chainlit as cl


class OpenLLMProvider(BaseProvider):

    # Format the message based on the template provided
    def format_message(self, message: cl.GenerationMessage, inputs: Optional[Dict]):
        message = super().format_message(message, inputs)
        # Additional formatting...
        return message

    def message_to_string(self, message: cl.GenerationMessage):
        return message.content

    async def create_completion(self, request):

        await super().create_completion(request)

        settings = request.generation.settings
        llm = LLMManager(settings).llm

        config=RunnableConfig(
        callbacks=[
            LangfuseCallbackHandler(
                session_id = "playground",
                user_id = _get_username_from_ps("unknown_user")+'_dev')
        ],
        metadata=settings,
        )

        async def create_event_stream():
            stream = llm.astream(
                request.chatGeneration.messages, config=config)
            async for chunk in stream:
                yield chunk.content

        return StreamingResponse(create_event_stream(), media_type="text/event-stream")


example_env_vars = {"api_key": "LANGFUSE_SECRET_KEY"}


def make_open_llm_provider():
    return OpenLLMProvider(
        id="openLLM",
        name="openLLM",
        env_vars=example_env_vars,
        inputs=input_widget,
        is_chat=False,
    )
