import os
from typing import List, Tuple
import httpx


class WebSearchDataClient(object):  # Used Google Search Engine
    url: str = f"{os.environ.get('WEB_SEARCH_DB_SERVER')}/google/"

    def __new__(cls):
        if not hasattr(cls, "instance"):
            cls.instance = super(WebSearchDataClient, cls).__new__(cls)

        return cls.instance

    @classmethod
    async def request(cls, query: str, limit: int = 5, recent_search: str = "y3") -> Tuple[List[dict], List]:
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{cls.url}",
                    params={"query": query, "limit": limit, "recent_search": recent_search},
                    timeout=120
                )
                response.raise_for_status()
                results = response.json().get("result", [])
                all_title_url_list = response.json().get("desc_url_info", [])
        except (httpx.RequestError, httpx.HTTPStatusError) as ex:
            print(f"Error during request: {ex}")
            return []
        except KeyError:
            return []

        if results == "[]":
            results = []
        if all_title_url_list == "[]":
            all_title_url_list = []
        
        return results, all_title_url_list