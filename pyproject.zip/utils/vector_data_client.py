import os
import time
from typing import List
import httpx


# class VectorResponse:
#     id: int
#     version: int
#     score: float
#     payload: dict
#     vertor: None
#     shard_key: str
#     url: str


class VectorDataClient(object):
    def __new__(cls):
        if not hasattr(cls, "instance"):
            cls.instance = super(VectorDataClient, cls).__new__(cls)

        return cls.instance

    @classmethod
    async def request(cls, text: str, *, collection: str = "faq", limit=3, answers=None, score_threshold: float = 0.5,
                      rerank_threshold: float = 0.7, delay=1, retries=3, urls=None, filter_list=None) -> List[dict]:

        for attempt in range(retries):
            try:
                async with httpx.AsyncClient() as client:
                    data: dict = {
                        "query": text,
                        "answers": answers,
                        "limit": limit,
                        "score_threshold": score_threshold,
                        "rerank_threshold": rerank_threshold,
                        "filter_list": filter_list
                    }

                    if urls is not None:
                        data["urls"] = urls
                    if collection == "rerank":
                        response = await client.post(
                            f'{os.environ.get("RERANK_DB_SERVER")}/{collection}',
                            json=data,
                            timeout=None)
                    else:
                        data["query"] = "query: " + text # qdrant DB encoding에 사용한 'intfloat/multilingual-e5-large' 모델의 템플릿 참고 # https://huggingface.co/intfloat/multilingual-e5-large#faq
                        response = await client.post(
                            f'{os.environ.get("VECTOR_DB_SERVER")}/{collection}',
                            json=data
                        )

                    response.raise_for_status()  # HTTP 에러 발생 시, 예외 발생.

                    if response is not None:
                        vectors = response.json()["result"]
                        if vectors and len(vectors) > 0:
                            return vectors
                        else:
                            return []
            except httpx.RequestError as e:
                print(f"Attempt {attempt + 1} failed: {e}")
                if attempt < retries - 1:
                    time.sleep(delay)
                else:
                    raise
