import json
import logging
from typing import Optional, List

from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.language_models import BaseLanguageModel

from agents.etf_name_select_agent import create_etf_name_select_agent
from agents.extract_etf_name_agent import extract_etf_name_agent

from utils.vector_data_client import VectorDataClient
import re
import chainlit as cl

def parse_json_list(text):
    json_pattern = r'\{.*\}'
    json_matches = re.findall(json_pattern, text)
    json_return = json.loads(f'[{json_matches[0]}]')
    return json_return


async def retrieve_etf_name_tool(llm: BaseLanguageModel, question: str,
                                 run_manager: Optional[CallbackManagerForToolRun] = None) -> tuple[List, List]: #tuple[Treap, Treap]:
    extract_agent = await extract_etf_name_agent(llm)
    cb_manager = run_manager.get_child() if run_manager is not None else None
    extract_agent_response = await extract_agent.ainvoke(
        {"question": question},
        {"callbacks": cb_manager}
    )

    listed_extract_agent: list[dict] = json.loads(extract_agent_response)

    extracted_etf_ticker: List = list()
    extracted_query_information: List = list()
    if listed_extract_agent is not None and len(listed_extract_agent) > 0:
        etf_name_list = cl.user_session.get("etf_name_list")
        etf_name_ticker_dict = cl.user_session.get("etf_name_ticker_dict")
        #listed_join_etf: str = ', '.join([f"{etf_name}" for etf_name in listed_extract_agent])
        listed_response = []
        for each_etf_name in listed_extract_agent:
            each_etf_name = re.sub(r"ETF|etf", "", each_etf_name).strip()
            if each_etf_name in etf_name_list: #static에 있는지 확인
                each_etf_ticker = etf_name_ticker_dict[each_etf_name]
                extracted_query_information.append(f"{each_etf_ticker} for {each_etf_name} ({each_etf_ticker})")
                extracted_etf_ticker.append(each_etf_ticker)
            else:
                listed_response.extend(await VectorDataClient.request(
                    each_etf_name,
                    collection="ticker-name",
                    score_threshold=0.7, # 0.9 고려.
                    limit=30,
                    # filter_list = [] # TODO 여기에 exact match 케이스를 추가하는 방안 고려
                    )
                )

        if listed_response is not None and len(listed_response) > 0:
            etf_name_select_agent = await create_etf_name_select_agent(llm)
            cb_manager = run_manager.get_child() if run_manager is not None else None
            selected_etf_response = await etf_name_select_agent.ainvoke(
                {
                    "pre_specified_etf_name": listed_extract_agent,
                    "etf_name_list": [item["payload"] for item in listed_response],
                    "question": question
                },
                {"callbacks": cb_manager}
            )

            try:
                parsed_etf_resp = json.loads(selected_etf_response)
                if isinstance(parsed_etf_resp, list):
                    for item in parsed_etf_resp:
                        if item['etf_ticker']:  # TODO: VectorDB 업데이트 해야함.
                            extracted_query_information.append((item['etf_ticker'] if len(item['etf_ticker'])==6 else f"0{item['etf_ticker']}") + f" for {item['etf_name']}")
                            extracted_etf_ticker.append(item['etf_ticker'] if len(item['etf_ticker'])==6 else f"0{item['etf_ticker']}")
                elif isinstance(parsed_etf_resp, dict):
                    extracted_query_information.append((parsed_etf_resp['etf_ticker'] if len(parsed_etf_resp['etf_ticker'])==6 else f"0{parsed_etf_resp['etf_ticker']}") + f" for {parsed_etf_resp['etf_name']}")
                    extracted_etf_ticker.append((parsed_etf_resp['etf_ticker'] if len(parsed_etf_resp['etf_ticker'])==6 else f"0{parsed_etf_resp['etf_ticker']}"))
            except ValueError as ex:
                logging.fatal(ex)  # TODO:
                pass

    return extracted_query_information, extracted_etf_ticker
