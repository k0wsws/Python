from langchain_core.tools import BaseTool
from langchain_core.callbacks import (
    CallbackManagerForToolRun,
)
from utils import tool_input_utils
from utils.vector_data_client import VectorDataClient
from typing import Any, Dict, Optional


class RetrieveFaqTool(BaseTool):
    """Tool for getting faq."""

    llm: Any = None
    name: str = "retrieve_faq_tool"
    name_for_human: str = "retrieve_faq_tool"
    description: str = """retrieve faq data from vector DB. Use this tool for broad questions related to ETFs and other finance-related topics.
Broad questions are those that do not require real-time information and may include basic knowledge questions such as 'What is an ETF?'
For example, general information about ETFs that applies to all ETFs, rather than a specific ETF, as well as basic financial information, definitions, and methodologies, are considered broad questions.
"""

    parameters: list[Dict] = [
        {
            "name": "question",
            #"description": "please write specific question or query to answer the user\'s Question based on the [<PLAN>] and the [<previous_conversation_history>].",
            "description": "repeat the full text of given user's Question",
            "required": True,
            "schema": {"type": "string"},
        }
    ]

    def _run(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        pass

    async def _arun(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        param = tool_input_utils.parse(tool_input)
        question = param["question"]

        faq_response = await VectorDataClient.request(question, collection="faq", limit=5, score_threshold=0.5)
        if faq_response is not None:
            answers_list: list = []
            for item in faq_response:
                answers_list.append(f"{item.get('payload').get('question')}-{item.get('payload').get('answer')}")

            rerank_response = await VectorDataClient.request(
                question,
                answers=answers_list,
                collection="rerank",
                limit=5,
                score_threshold=0.5,  # TODO: 최적화 필요
                rerank_threshold=0.5  # TODO: 최적화 필요
            )

        #     if rerank_response is not None:
        #         rerank_response.sort(key=lambda x: x['score'], reverse=True)
        #         return f"질문 내용:{question}/답변 내용:`{rerank_response[0].get('payload').get('answer')}`를 모두 참조하여 바탕으로 질문자가 읽기 쉽도록 구어체를 만드세요."
        # return "VectorDB에 질문과 관련된 데이터가 없으므로 web_search_tool을 사용하여 정보를 검색해야합니다."

            try:
                if rerank_response is not None:
                    rerank_response.sort(key=lambda x: x['score'], reverse=True)
                    return f"질문 내용:{question}/답변 내용:`{rerank_response[0].get('payload').get('answer')}`를 모두 참조하여 바탕으로 질문자가 읽기 쉽도록 구어체를 만드세요."
                else:
                    return "FAQ 조회결과 연관성이 높은 정보를 찾을 수 없었습니다. 다른 도구를 사용하거나, 사용자의 질문에 우회하여 응답하세요."
            except (IndexError, AttributeError) as e:
                return f"FAQ 조회시 일시적인 오류가 발생했습니다. 다른 도구를 사용하거나, 사용자의 질문에 우회하여 응답하세요."