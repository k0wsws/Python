from langchain.tools import Tool
from typing import Any, Dict, Optional
from langchain_core.tools import BaseTool
from langchain.chains import LLMMathChain
from langchain_core.callbacks import CallbackManagerForToolRun
from utils import tool_input_utils
import json

CALCULATOR_PROMPT_TEMPLATE = """
주어진 데이터를 기반으로 계산을 수행하세요.

question: {question}
information: {information}

계산해야 할 내용을 다음과 같은 형식으로 작성하세요:

예시 1) 수익률 계산:
현재 종가: 1만 2,105원
이전 종가: 1만 790원
equation : (12105 - 10790) / 10790 * 100
result: 12.19

예시 2) 증감률 계산:
- 이전 값: 100
- 현재 값: 120
equation : ((120 - 100) / 100) * 100 = 20
result: 20
"""


class CalculatorTool(BaseTool):
    """Tool for getting calculation."""

    llm: Any = None
    name: str = "calculator_tool"
    name_for_human: str = "calculator_tool"
    description: str = """This tool is used when complex mathematical calculations are required.
When a user's question involves complex mathematical computations, this tool provides responses by performing calculations based on the provided information.
"""

    llm_math: Optional[LLMMathChain] = None

    parameters: list[Dict] = [
        {
            "name": "question",
            "description": "repeat the full text of given user's Question",
            "required": True,
            "schema": {"type": "string"},
        },
        {
            "name": "information",
            "description": "Information to be used for mathematical calculations extracted from the DB based on user's question",
            "required": True,
            "schema": {"type": "string"},
        },
    ]

    def __init__(self, llm: Any = None):
        """초기화 함수"""
        super().__init__()
        if llm:
            self.llm = llm
            self.llm_math = LLMMathChain.from_llm(llm)

    def _run(
        self,
        tool_input: str = "",
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        try:
            param: json = tool_input_utils.parse(tool_input)
            question = param.get("question", "")
            information = param.get("information", "")

            calculation_prompt = CALCULATOR_PROMPT_TEMPLATE.format(
                question=question,
                information=information
            )
            try:
                if self.llm_math:
                    calculation_expression = self.llm_math.run(calculation_prompt)
                    # 생성된 계산식에서 실제 수식만 추출 (마지막 줄 사용)
                    # calculation_expression = calculation_expression.strip().split('\n')[-1]
                    
                    # # numexpr로 계산 수행
                    # result = numexpr.evaluate(calculation_expression)
                    return calculation_expression
            
            except Exception as e:
                return f"계산 중 오류가 발생했습니다: {str(e)}"
            
            return "계산을 수행할 수 없습니다. 다른 방식으로 질문해 주시겠어요?"

        except Exception as e:
            return f"예기치 않은 오류가 발생했습니다: {str(e)}"
        
    async def _arun(
        self,
        tool_input: str = "",
    ) -> str:
        try:
            param: json = tool_input_utils.parse(tool_input)
            question = param.get("question", "")
            information = param.get("information", "")
            
            calculation_prompt = CALCULATOR_PROMPT_TEMPLATE.format(
                question=question,
                information=information
            )
            try:
                # LLM을 사용하여 계산식 생성
                if self.llm_math:
                    calculation_expression = await self.llm_math.arun(calculation_prompt)
                    return f"다음 Question, Equation, Answer를 토대로 수식 결과와 요청 질문에 답변을 설명하세요.\nQuestion: {question}\nEquation: {information}\n{calculation_expression}"
                
            except Exception as e:
                return f"계산 중 오류가 발생했습니다: {str(e)}"

            return "계산을 수행할 수 없습니다. 다른 방식으로 질문해 주시겠어요?"

        except Exception as e:
            return f"예기치 않은 오류가 발생했습니다: {str(e)}"