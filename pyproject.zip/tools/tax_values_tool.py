import logging

import chainlit as cl

from chainlit.custom.database.postgres_connector import db_connector

from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.tools import BaseTool

from tools.retrieve_etf_name_tool import retrieve_etf_name_tool
from utils import tool_input_utils
from utils.data_structure.treap import Treap
from typing import Any, Dict, Optional


class RetrieveTaxValuesTool(BaseTool):
    """Tool for getting tax."""

    llm: Any = None
    name: str = "retrieve_tax_tool"
    name_for_human: str = "retrieve_tax_tool"
    description: str = """Retrieve FAQ Data Related to ETF Tax Information. Use this tool to handle questions related to tax information for ETFs.
Questions about tax information may include inquiries about the tax treatment of specific ETFs, as well as general tax-related information, definitions, and methodologies applicable to ETFs in general.
For example, general information on the tax treatment of dividends from ETFs or differences in tax treatment compared to other investment products would be covered by this tool.
"""

    parameters: list[Dict] = [
        {
            "name": "question",
            "description": "repeat the full text of given user's Question",
            "required": True,
            "schema": {"type": "string"},
        }
    ]

    description_of_trading_profit: str = """국내주식형 이외의 ETF로 분류되므로, 보유기간과세가 적용됩니다. 이는, 투자 기간 동안 발생한 이익에 대해 과세하는 방식입니다.
매매차익 또는 ETF의 과표기준가격 상승분 중 적은 금액에 대해 15.4%(배당소득세 14%+주민세 1.4%)의 세금이 부과됩니다."""

    description_of_dividend: str = """ETF에서 발생하는 분배금에 대해서도 세금이 발생합니다. 
분배금이란 ETF가 주식 배당금 및 이자소득, 지수대비 초과 이익 발생분 등을 기초로 투자자에게 지급하는 금액입니다. 
이 분배금은 배당소득세 과세 대상이므로, 분배금 지급 시 배당소득세가 원천징수되며, 이는 금융소득종합과세에 포함됩니다."""

    tax_rule: dict = {
        "국내대체": f"매매차익: 과세, 증권거래세: 과세, 분배금: 과세\n설명:{description_of_trading_profit}\n{description_of_dividend}",
        "해외대체": f"매매차익: 과세, 증권거래세: 과세, 분배금: 과세\n설명:{description_of_trading_profit}\n{description_of_dividend}",
        "국내혼합형": f"매매차익: 과세, 증권거래세: 과세, 분배금: 과세\n설명:{description_of_trading_profit}\n{description_of_dividend}",
        "국내채권형": f"매매차익: 과세, 증권거래세: 과세, 분배금: 과세\n설명:{description_of_trading_profit}\n{description_of_dividend}",
        "해외채권형": f"매매차익: 과세, 증권거래세: 과세, 분배금: 과세\n설명:{description_of_trading_profit}\n{description_of_dividend}",
        "해외혼합형": f"매매차익: 과세, 증권거래세: 과세, 분배금: 과세\n설명:{description_of_trading_profit}\n{description_of_dividend}",
        "국내주식형": f"매매차익: 비과세, 증권거래세: 면세, 분배금: 과세\n설명:{description_of_dividend}",
        "기타형": f"매매차익: 과세, 증권거래세: 과세, 분배금: 과세\n설명:{description_of_trading_profit}\n{description_of_dividend}",
        "해외주식형": f"매매차익: 과세, 증권거래세: 과세, 분배금: 과세\n설명:{description_of_trading_profit}\n{description_of_dividend}",
    }

    def _run(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        pass

    async def _arun(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        param = tool_input_utils.parse(tool_input)
        question = param["question"]

        _, extracted_etf_ticker = await retrieve_etf_name_tool(
            llm=self.llm,
            question=question,
            run_manager=run_manager
        )

        def get_etf_market_class_1(etf_ticker_list: str) -> list[dict]:
            query: str = f"""select etf_ticker, etf_name, market_class_1
from etf_recent_master erm
where etf_ticker in ({etf_ticker_list})
            """

            resp_list: list[dict] = []

            try:
                db_response = db_connector.execute(command=query)
                if db_response and len(db_response) > 0:
                    for obj in db_response:
                        resp_list.append(obj)
            except Exception as ex:
                logging.fatal(ex)
                pass  # TODO:

            return resp_list

        inorder_etf_ticker: list = extracted_etf_ticker#.inorder()
        appendix_ticker: str = ""
        if len(inorder_etf_ticker) > 0:
            for index, etf_ticker in enumerate(inorder_etf_ticker):
                appendix_ticker += f"'{etf_ticker}'"
                if index != len(inorder_etf_ticker) - 1:
                    appendix_ticker += ","

            db_response: list = get_etf_market_class_1(appendix_ticker)
            final_resp: list[str] = []
            for obj in db_response:
                final_resp.append(f"{obj.get('etf_name')}({obj.get('etf_ticker')})-{self.tax_rule[obj.get('market_class_1')]})")

            ticker_list: list = cl.user_session.get("extracted_etf_ticker")
            if ticker_list:
                for tic in ticker_list:
                    #extracted_etf_ticker.insert(tic)
                    extracted_etf_ticker.append(tic)
            cl.user_session.set("extracted_etf_ticker", (extracted_etf_ticker))#.inorder()))

            return f"`{''.join(final_resp)}`를 바탕으로 질문자가 읽기 쉽도록 구어체를 만드세요."
        else:
            return "ETF 정보가 제공되지 않아 세금 정보를 알 수 없습니다."


