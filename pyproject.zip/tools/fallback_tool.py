from langchain_core.tools import BaseTool
from typing import Any, Dict, Optional
from langchain_core.callbacks import (
    CallbackManagerForToolRun,
)


class FallBackTool(BaseTool):
    """Tool for getting faq."""

    llm: Any = None
    name: str = "fallback_tool"
    name_for_human: str = "fallback_tool"
    description: str = """The fallback routine for questions unrelated to finance investment or related to Russia. This tool provides predefined responses in cases where the user's inquiry is unrelated to finance investment, pertains to Russia, or when an exception occurs.
If the user's question is not related to ETFs, stock information, general financial inquiries, or market conditions, or if the question pertains to Russia, please use this tool to respond courteously.
Additionally, this tool can be used to handle malicious or irrelevant questions that are not related to financial information services.
"""
    
    parameters: list[Dict] = [
        {
            "name": "question",
            "description": "repeat the full text of given user's Question",
            "required": True,
            "schema": {"type": "string"},
        },
        {
            "name": "err_message",
            "description": "describe why user's Question cannot find intention.",
            "required": True,
            "schema": {"type": "string"},
        },
    ]

    def _run(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None,) -> str:
        pass

    async def _arun(self,tool_input: str = "",) -> str:
        # TODO 다양한 예외 처리 ex. 질문에 대한 대응, 주제 이탈에 대한 대응, 어택에 대한 대응, (환각에 대한 대응) 등
        return "해당 질문에 답변할 수 없습니다, 다른 질문을 해주시겠어요?"
