import json

from langchain_core.tools import BaseTool
from typing import Any, Dict, Optional, List
from langchain_core.callbacks import (
    CallbackManagerForToolRun,
)

from agents.web_searching_agent import create_web_searching_agent
from utils import tool_input_utils
from utils.web_data_client import WebSearchDataClient
from utils.vector_data_client import VectorDataClient

from .keyword_reformulation_tool import *
from .keyword_plan_tool import *


class WebSearchTool(BaseTool):
    """Tool for getting web search."""

    llm: Any = None
    name: str = "web_search_tool"
    name_for_human: str = "web_search_tool"
    description: str = f"""search relevant information from internet. 사용자의 질문이 최신 뉴스나 관련 정보에 대해 웹 검색이 필요하다고 판단되는 경우, '{name}' 도구를 사용하여 응답하세요.   
단, 응답을 종료해야 하는 경우에는 해당 툴을 사용하지 않습니다. '{name}' 는 다른 도구들을 사용하여 정보를 구하지 못한 경우에 인터넷에서 추가적인 정보를 탐색하는데 활용할 수 있습니다.
'{name}' 도구를 활용하여 최신 웹 정보를 검색한 후, 이를 토대로 친절하게 한국어로 답변하세요.
검색한 내용으로 Final Answer를 만들때 사용자에게 "다음은 웹 검색 툴을 활용한 답변입니다." 라는 안내 멘트를 유지한 채로 함께 답변하세요.
"""

    parameters: List[Dict] = [
        {
            "name": "question",
            "description": "repeat the full text of given user's Question",
            "required": True,
            "schema": {"type": "string"},
        },
        {
            "name": "keywords",
            "description": (
                "Extract relevant keywords or phrases from the user's query in Korean that can yield the most accurate and relevant search results. "
                "For example, if the user asks '트럼프가 대통령이 되었을 때 사면 좋을 ETF는?', extract keywords like "
                "'트럼프 대통령 ETF 투자'. The keywords should focus on the essential elements of the query to ensure optimal search results in Korean, "
                "such as the topic (e.g., '트럼프'), the context (e.g., '대통령'), and the target (e.g., 'ETF')."
            ),
            "required": True,
            "schema": {"type": "string"},
        },
        {
            "name": "recent_search",
            "description": "If the query requires the latest information, return 'm6'. For general information, return 'y3'.",
            "required": False,
            "schema": {
                "type": "string",
                "enum": ["m6", "y3"],
                "default": "y3"
            }
        }
    ]

    def _run(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None, ) -> str:
        pass

    # -------------------- 꼬리 질문형 검색 모델 ----------------------# 
    async def recurrent_search(self, llm, question: str, recent_search: str, num: int):
        answer_list, previous_info, res = [], [], ""

        for i in range(num):
            if not res:
                previous_info = ""
            else:
                previous_info = " ".join([item["payload"]["answer"] for item in res])
            keywords = await reformulate_keywords(llm, question, previous_info)
            res, all_url = await WebSearchDataClient.request(keywords, recent_search=recent_search)

            if not res:
                new_keywords = await retry_reformulate(llm, question, keywords)
                res, all_url = await WebSearchDataClient.request(new_keywords, recent_search=recent_search)
            answers, urls = [], []
            for item in res:
                try:
                    answers.append(item["payload"]["answer"])
                    urls.append(item["payload"]["url"])
                except (UnicodeDecodeError, KeyError, TypeError) as e:
                    print(f"Error processing item: {item}, error: {e}")
                    continue
            res = await VectorDataClient.request(
                question,
                answers=answers,
                collection="rerank",
                limit=5,
                rerank_threshold=0.3,
                urls=urls
            )

            answer_list.append(res)

        return answer_list, all_url

    # -------------------- 계획을 먼저 세우고 여러 키워드 검색 모델 ----------------------#
    async def plan_first_search(self, llm, question: str, recent_search: str, num: int):
        reformulated_string = await reformulate_plans(llm, question, num)
        keywords_list = reformulated_string.split(',')
        answer_list: list = []

        for keywords in keywords_list:
            res, all_url = await WebSearchDataClient.request(keywords, recent_search=recent_search)
            answers, urls = [], []
            for item in res:
                try:
                    answers.append(item["payload"]["answer"])
                    urls.append(item["payload"]["url"])
                except (UnicodeDecodeError, KeyError, TypeError) as e:
                    print(f"Error processing item: {item}, error: {e}")
                    continue

            res = await VectorDataClient.request(
                question,
                answers=answers,
                collection="rerank",
                limit=5,
                rerank_threshold=0.3,
                urls=urls
            )

            answer_list.append(res)

        return answer_list, all_url

    # -------------------- 기본 검색 모델 ----------------------#
    async def one_shot_search(self, question: str, keywords: str, recent_search: str):
        keywords = await reformulate_keywords(self.llm, question, [])
        try:
            res, all_url = await WebSearchDataClient.request(keywords, recent_search=recent_search)
        except:  # avoid 404
            res, all_url = [], []
        answers, urls = [], []
        for item in res:
            try:
                answers.append(item["payload"]["answer"])
                urls.append(item["payload"]["url"])
            except (UnicodeDecodeError, KeyError, TypeError) as e:
                print(f"Error processing item: {item}, error: {e}")
                continue

        res = await VectorDataClient.request(
            question,
            answers=answers,
            collection="rerank",
            limit=5,
            rerank_threshold=0.3,
            urls=urls
        )
        return res, all_url #list(set(urls))

    async def _arun(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        param = tool_input_utils.parse(tool_input)
        question = param["question"]
        keywords = param["keywords"]
        recent_search = param.get("recent_search", None)

        answer, unique_urls = await self.one_shot_search(question, keywords, recent_search)

        context = json.dumps(
            [
                {
                    "search_query": item["payload"]["question"],
                    "similarity": item["score"],
                    "searched_result": item["payload"]["answer"],
                    "url": item["urls"],
                }
                for item in answer
            ],
            ensure_ascii=False,
            indent=2
        )
        web_parsed_status = ""
        if context == '[]' or context == []:
            if unique_urls == []:
                context = str(context)
                generation_rule = """There is no valid searched result. Just say, "관련된 검색 결과가 없습니다." without any hyperlink."""
                web_parsed_status = "failed"
            else:
                context = str(unique_urls)
                generation_rule = """There is no valid searched result. Answer induce to refer the references for more information, using only 'reference_name', 'cand_title', 'cand_url'."""
                web_parsed_status = "url_only"
        else:
            context = str(context)
            generation_rule = """(This contains the search results from the web. If there's no result, just say, "관련된 검색 결과가 없습니다.")"""
            web_parsed_status = "success"
        agent = await create_web_searching_agent(self.llm)
        llm_res = await agent.ainvoke(
            {
                "context": context,
                "question": question,
                "generation_rule": generation_rule
            },
            {
                "callbacks": run_manager.get_child()
            },
        )
        if web_parsed_status in ["url_only", "success"]: # failed는 제외. 
            llm_res = "다음은 웹 검색 툴을 활용한 답변입니다.\n" + llm_res + "\n(웹 검색 결과를 기반으로 답변한 내용으로, 사실과 다를 수 있습니다.)"
        return llm_res
