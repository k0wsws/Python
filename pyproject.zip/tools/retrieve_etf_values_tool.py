import re
import json
import logging

import chainlit as cl

from langchain_core.tools import BaseTool
from langchain_core.callbacks import (
    CallbackManagerForToolRun,
)

from utils import tool_input_utils
from chainlit.custom.database.postgres_connector import db_connector
from agents.sql_generation_agent import create_sql_generation_agent, table_struct_prompt
from typing import Any, Dict, Optional, Union, List

from tools.retrieve_etf_name_tool import retrieve_etf_name_tool
from utils import json_utils
from utils.holding_name_checker import existing_holding_name
from utils.number_replacer import replace_realtime_etf_info
from utils.time_tools import get_specific_date
from datetime import date
import fnmatch
from copy import deepcopy

def remove_null_values(data):
    return [{k: v for k, v in entry.items() if v is not None} for entry in data]

def answer_on_null_value_case(null_result):
    nav = fnmatch.filter(null_result.keys(), "*nav_total_return*") # nav_total_return
    ptr = fnmatch.filter(null_result.keys(), "*price_total_return*") # price_total_return
    pr = fnmatch.filter(null_result.keys(), "*price_return*") # price_return
    dd = fnmatch.filter(null_result.keys(), "*draw_down*") # 낙폭
    vol = fnmatch.filter(null_result.keys(), "*volatility*") # 변동성
    fee = fnmatch.filter(null_result.keys(), "*total_expense_ratio*") + fnmatch.filter(null_result.keys(), "*fee_ratio*") # 보수율
    divi = fnmatch.filter(null_result.keys(), "*div*") + fnmatch.filter(null_result.keys(), "*payment*") #분배, 배당
    point = fnmatch.filter(null_result.keys(), "*fund_characteristics*") + fnmatch.filter(null_result.keys(), "*investment_points*")
    beta_alpha = fnmatch.filter(null_result.keys(), "*beta*") + fnmatch.filter(null_result.keys(), "*alpha*")
    resp: List = []
    if any([nav, ptr, pr, dd, vol, fee, divi, point]):
        try:
            info = db_connector.execute(command=f"SELECT etf_name, inception_date, (CURRENT_TIMESTAMP - etf_recent_master.inception_date::timestamp) > INTERVAL '32 days' AS exceeds_31_days FROM etf_recent_master WHERE etf_ticker = '{(null_result["etf_ticker"])}';", fetch="all")
            etf_name = info[0]['etf_name']
            exceeds_31_days = info[0]['exceeds_32_days']
            inception_date = f"상장일자는 {info[0]['inception_date']} 이므로,"
        except:
            etf_name = "해당" # query로 던진 상품의 대명사
            inception_date = ""
            exceeds_31_days = None
    
        if any([nav, ptr, pr, dd, vol, fee, beta_alpha]) and inception_date:
            resp.append(f" {etf_name} ETF의 {inception_date}")

        if nav:
            resp.append(f"{etf_name} ETF의 {nav} 기간의 수익률은 존재하지 않습니다.")
        if ptr:
            resp.append(f"{etf_name} ETF의 {ptr} 기간의 종가 총수익률(TR)은 존재하지 않습니다.")
        if pr:
            resp.append(f"{etf_name} ETF의 {pr} 기간의 종가 수익률(PR)은 존재하지 않습니다.")
        if dd:
            resp.append(f"{etf_name} ETF의 {dd} 기간 손실폭은 존재하지 않습니다.")
        if vol:
            resp.append(f"{etf_name} ETF의 {vol} 기간 변동성은 존재하지 않습니다.")
        if fee:
            resp.append(f"{etf_name} ETF의 보수율은 존재하지 않습니다.")
        if beta_alpha:
            resp.append(f"{etf_name} ETF의 베타 및 알파 계수는 존재하지 않습니다.")

        if divi:
            if exceeds_31_days:
                resp.append(f"{etf_name} ETF는 분배금을 지급하지 않습니다.")
            else:
                resp.append(f"{etf_name} ETF의 {inception_date} {etf_name} ETF의 분배 이력이 존재하지 않습니다.")
        if point:
            resp.append(f"{etf_name} ETF의 투자 전략은 제공되지 않습니다.")
    return " ".join(resp).strip()

class RetrieveETFValuesTool(BaseTool):
    """Tool for getting ETF analysis or compare info."""

    llm: Any = None
    name: str = "retrieve_etf_values_tool"
    name_for_human: str = "retrieve_etf_values_tool"
    description: str = """This tool finds and retrieves ETF information from an SQL database. 
    The database contains data on the ETF's constituents, volatility data, yield data, payout data, closing price data, NAV data, brand name, the weight of the stock portfolio in a particular ETF (구성종목), and etc. 
    If you are given an ETF name, use this tool to find the answer. This tool can also be used to search and compare ETFs based on specific values or conditions.
    For best performance, this tool can handle complex queries all at once, rather than breaking them down into several smaller queries.
    The most recent data in database is yesterday recorded, so if question requires today's data, you respond that today's data is unrecorded then answer about yesterday (most recent day).
    Pay close attention to any brand names mentioned. If the query refers to a brand name rather than a specific ETF, use the ETF nicknames below to search.
    *** nickname of ETFs ***
    {{
        "ACE ETF": ["에이스", "한투", "한국"],
        "PLUS ETF": ["플러스", "ARIRANG", "아리랑", "한화"],
        "BNK ETF": ["비엔케이"],
        "FOCUS ETF": ["포커스", "브이아이", "VI"],
        "HANARO ETF": ["하나로", "농협", "NH"],
        "HK ETF": ["흥국"],
        "ITF ETF": ["IBK"],
        "RISE ETF": ["KB", "케이비", "국민"],
        "KODEX ETF": ["코덱스", "삼성"],
        "KoAct ETF": ["코액트", "삼성액티브"],
        "KOSEF ETF": ["코세프", "키움"],
        "SOL ETF": ["쏠", "신한"],
        "TIGER ETF": ["타이거", "미래"],
        "TIMEFOLIO ETF": ["타임폴리오"],
        "TREX ETF": ["티렉스", "유리"],
        "UNICORN ETF": ["유니콘", "현대"],
        "VITA ETF": ["밸류"],
        "WOORI ETF": ["우리"],
        "대신343 ETF": ["대신"],
        "마이티 ETF": ["DB", "디비"],
        "파워 ETF": ["교보"],
        "히어로즈 ETF": ["키움"]
    }}
    """

    parameters: list[Dict] = [
        {
            'name': 'question',
            #'description': 'please write specific question or query to answer the user\'s Question based on the [<PLAN>] and the [<previous_conversation_history>]. ',
            "description": "repeat the full text of given user's Question",
            'required': True,
            'schema': {
                'type': 'string'
            },
        },
        {
            'name': 'needs_calculator',
            'description': 'Boolean flag indicating whether this query requires calculation',
            'required': True,
            'schema': {
                'type': 'boolean'
            },
        }
    ]

    def remove_markdown(self, strings):
        strings = re.sub(r'```\n```', '```', strings)
        strings = re.sub(r'```sql', '```', strings)
        strings = re.sub(r'```SQL', '```', strings)

        code_block = re.findall(r'```(.*?)```', strings, re.DOTALL)
        if code_block and len(code_block) > 0:
            return code_block[-1].strip()
        else:
            return ""

    def remove_etf_suffix(self, strings):
        return [s[:-3] if s.endswith("ETF") else s for s in strings]

    def _run(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        pass

    async def _arun(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) \
            -> Union[str, list[str], list]:
        param: json = tool_input_utils.parse(tool_input)
        question = param.get("question")
        needs_calculator = param.get("needs_calculator", False)
        # print(f"User Question - {question}")

        extracted_query_information, extracted_etf_ticker = await retrieve_etf_name_tool(
            llm=self.llm,
            question=question,
            run_manager=run_manager
        )

        #is_exists_etf_ticker_list: bool = extracted_query_information.get_length() != 0
        is_exists_etf_ticker_list: bool = len(extracted_query_information) != 0
        sql_generation_agent = await create_sql_generation_agent(
            llm=self.llm,
            exists_etf_ticker_list=is_exists_etf_ticker_list
        )

        today = date.today()
        formatted_date = today.strftime("%Y년 %m월 %d일")

        sql_generation_parameter: dict = {
            "top_k": 50, #10,
            "table_struct_prompt": table_struct_prompt,
            "current_date": formatted_date,
            "date_example": get_specific_date(),
            "question": question
        }

        if is_exists_etf_ticker_list:
            sql_generation_parameter["etf_ticker_list"] = extracted_query_information #.inorder()

        create_sql_dml = await sql_generation_agent.ainvoke(
            sql_generation_parameter,
            {"callbacks": run_manager.get_child()}
        )

        if "```" in create_sql_dml:
            create_sql_dml = self.remove_markdown(create_sql_dml)
        if not re.search(r"(GROUP BY|ORDER BY|JOIN|COUNT\()", create_sql_dml, flags=re.IGNORECASE) and re.search(r"(etf_recent_master)", create_sql_dml, flags=re.IGNORECASE): # sql에 group by와 order by가 있지 않으면 브랜드명으로 정렬 (ACE가 가장 먼저 나오도록)
            if re.search(r"LIMIT", create_sql_dml, flags=re.IGNORECASE): # sql에 LIMIT가 있을때
                create_sql_dml = re.sub(r"LIMIT", "ORDER BY etf_recent_master.brand LIMIT", create_sql_dml, flags=re.IGNORECASE)
            elif ";" in create_sql_dml: # sql이 ;로 끝날때
                create_sql_dml = re.sub(r";", " ORDER BY etf_recent_master.brand;", create_sql_dml, flags=re.IGNORECASE)
            else: # 그 외
                create_sql_dml = create_sql_dml + " ORDER BY etf_recent_master.brand"
        create_sql_dml = re.sub(
            r"(AS\s+)'(.*?)'",
            r'AS "\2"',
            create_sql_dml,
        )
        # print(f"SQL DML - {create_sql_dml}")

        tools_response: list = []
        null_result: list = []
        if 'holding_name' in create_sql_dml:
            create_sql_dml = await existing_holding_name(create_sql_dml)

        try:
            fetched_data = db_connector.execute(command=create_sql_dml, fetch="all")
            if fetched_data and len(fetched_data) > 0:
                tools_response = fetched_data
                for each_response in tools_response:
                    if None in each_response.values():
                        null_dict = dict((col_name, col_value) for col_name, col_value in each_response.items() if col_value is None)
                        if each_response.get('etf_name'):
                            null_dict['etf_name'] = each_response.get('etf_name')
                        if each_response.get('etf_ticker'):
                            null_dict['etf_ticker'] = each_response.get('etf_ticker')
                        null_result.append(null_dict)
        except Exception as ex:
            logging.fatal(ex)
            pass  # TODO:

        if len(tools_response) == 0 and ('etf_historical_dividend' in create_sql_dml):
            return f"""We could not found any information related to user's question from the database. Please answer as the following examples.
User's Question: {question}
Example 1
Question: TIGER 200 TR ETF 분배금 지급내역을 알려줘.
Final Answer: TIGER 200 TR ETF는 분배금을 지급하지 않습니다.

Example 2
Question: ACE KPOP포커스 ETF의 배당금이 얼마야?
Final Answer: ACE KPOP포커스 ETF는 배당금을 지급하지 않습니다."""

        elif len(tools_response) == 0 and 'etf_historical_constituent_holdings' in create_sql_dml:
            return f"""There's no result related to holding stock and ETF, so you must answer as the following examples formation.
User's Question: {question}
Example 1
Question: TIGER 리츠부동산인프라 ETF에 삼성전자 들어있어?
Final Answer: TIGER 리츠부동산인프라 ETF에 삼성전자 종목이 들어있지 않습니다.

Example 2
Question: ACE 코스피 ETF에 엔비디아 종목 포함되어 있어?
Final Answer: ACE 코스피 ETF에 엔비디아 종목이 포함되어 있지 않습니다.

Example 3
Question: 두나무 비중이 가장 높은 국내 ETF가 뭐야?
Final Answer: 두나무가 포함된 국내 ETF가 없습니다."""
        elif len(tools_response) == 0:  # 이밖에 예외 케이스도 처리를 해줘야함.
            return f"""We could not find any information related to the user's question from the database.
User's Question: {question}
Please respond that we cannot answer the question."""

        ticker_list: list = cl.user_session.get("extracted_etf_ticker")
        if ticker_list:
            for tic in ticker_list:
                #extracted_etf_ticker.insert(tic)
                extracted_etf_ticker.append(tic)
        #cl.user_session.set("extracted_etf_ticker", (extracted_etf_ticker.inorder()))
        cl.user_session.set("extracted_etf_ticker", (extracted_etf_ticker))

        final_db_response: list = []
        calculator_final_db_response: list = []
        calculator_final_db_response = deepcopy(tools_response)  # 원본 데이터 전체 복사
        for resp in tools_response:
            database_response, is_replace = replace_realtime_etf_info(resp)
            final_db_response.append(database_response)
        if null_result:
            resp: List = []
            for each_null_result in null_result:
                resp.append(answer_on_null_value_case(each_null_result))
            resp = " ".join(resp)
            if tools_response == null_result:
                return resp
            else:
               return f"""검색결과:`{json_utils.dumps(final_db_response)}`를 모두 참조하여 질문자의 궁금증을 해소할 수 있는 답변을 만드세요. 
`{resp}`"""
        if any(non_replaced_condition in create_sql_dml for non_replaced_condition in ['holding_shares', 'holding_name', 'holding_weight']) or not is_replace: # TODO: 조건 추가해야함.
            return f"""검색결과:`{json_utils.dumps(final_db_response)}`를 모두 참조하여 질문자의 궁금증을 해소할 수 있는 답변을 만드세요."""
        else:
            return f"""검색결과:`{json_utils.dumps(final_db_response)}`를 모두 참조하여 질문자의 궁금증을 해소할 수 있는 답변을 만드세요., 변환전: `{json_utils.dumps(calculator_final_db_response)}`"""