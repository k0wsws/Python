import json

from langchain_core.tools import BaseTool
from langchain_core.callbacks import (
    CallbackManagerForToolRun,
)

from utils import tool_input_utils
from chainlit.custom.database.postgres_connector import db_connector
from typing import Any, Dict, Optional, Union

from tools.retrieve_etf_name_tool import retrieve_etf_name_tool

class SimilarETFSearchTool(BaseTool):
    llm: Any = None
    name: str = "similar_etf_search_tool"
    name_for_human: str = "similar_etf_search_tool"
    description: str = f"""Find ETFs similar to a specific ETF name.
If you're looking for similar or competing products based on a particular ETF, use the {name}.
This tool should only be used when searching for a specific ETF name.
For general questions about concepts, investment strategies, themes, or sectors, use other tools instead.
"""

    parameters: list[Dict] = [
        {
            'name': 'question',
            "description": "repeat the full text of given user's Question",
            'required': True,
            'schema': {
                'type': 'string'
            },
        }
    ]

    def _run(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        pass


    async def _arun(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) \
        -> Union[str, list[str], list]:
        param: json = tool_input_utils.parse(tool_input)
        question = param.get("question")

        try:
            #사용자 질문에서 ETF 이름과 티커를 파싱
            extracted_query_information, extracted_etf_ticker = await retrieve_etf_name_tool(
                llm=self.llm,
                question=question,
                run_manager=run_manager
            )
            ace_peer = []
            similar_etf = []
            if extracted_etf_ticker:
                #사용자 질문에서 파싱한 ETF 티커로 ETF 정보 검색 
                likes = f"etf_ticker SIMILAR TO '%({"|".join(extracted_etf_ticker)})%'" # TODO: 문제 발생 시 얘는 similar to 로 찾지말고 ON 으로 정확히 일치 케이스로 찾으세요.
                ql = f"SELECT ace_peer, etf_ticker, etf_name FROM etf.etf_recent_master erm WHERE {likes} ORDER BY erm.asset_under_management DESC;"
                etf_matches = db_connector.execute(command=ql, fetch="all")
                #검색된 ETF가 있을 경우 유사 ETF를 찾는 로직을 사용
                if etf_matches:
                    # 검색된 ETF에서 'ace_peer'열이 있는지 검색
                    for each_etf in etf_matches:
                        if each_etf["ace_peer"]:
                            ace_peer.extend(each_etf["ace_peer"].split(","))
                    #ace_peer가 있을 경우 이를 통해 유사한 ETF를 검색
                    if ace_peer:
                        ace_peer = list(set(ace_peer))
                        for remove_theme in ['ACE PEER', ' ACE PEER']:
                            if remove_theme in ace_peer:
                                ace_peer.remove(remove_theme)
                        likes = f"ace_peer SIMILAR TO '%({"|".join(ace_peer)})%'"
                        #ace_peer_ql = f"SELECT ace_peer, etf_ticker, etf_name FROM etf.etf_recent_master erm WHERE ({' OR '.join(likes)}) ORDER BY erm.asset_under_management DESC;"
                        #최대 갯수 조절시 ace가 우선이 될 수 있도록 ace etf와 non ace etf를 구분해서 쿼리를 생성하고 순차적으로 처리
                        ace_etf_ql = f"SELECT ace_peer, etf_ticker, etf_name FROM etf.etf_recent_master erm WHERE {likes} AND brand = 'ACE' ORDER BY erm.asset_under_management DESC;"
                        non_ace_etf_ql = f"SELECT ace_peer, etf_ticker, etf_name FROM etf.etf_recent_master erm WHERE {likes} AND brand != 'ACE' ORDER BY erm.asset_under_management DESC;"
                        ace_etf_peer_ql_matches = db_connector.execute(command=ace_etf_ql, fetch="all")
                        non_ace_etf_peer_ql_matches = db_connector.execute(command=non_ace_etf_ql, fetch="all") 
                        if ace_etf_peer_ql_matches or non_ace_etf_peer_ql_matches:
                            for ace_peer_matches in [ace_etf_peer_ql_matches, non_ace_etf_peer_ql_matches]:
                                for each_etf in ace_peer_matches:
                                    if each_etf["etf_ticker"] not in extracted_etf_ticker:
                                        #완전히 일치하는 테마를 가지고 있는지 검사하고, 있는 경우 similar_etf에 추가
                                        checker = False
                                        for theme in each_etf["ace_peer"].split(","):
                                            if theme.strip() != "ACE PEER" and theme in ace_peer:
                                                checker = True
                                                break
                                        if checker:
                                            similar_etf.append(each_etf)
                if similar_etf:
                    similar_etf = [f"{etf['etf_name']}({etf['etf_ticker']})" for etf in similar_etf]
                    #사용자에게 제공할 갯수를 조절(5개까지)
                    #similar_etf = similar_etf[:min(5, len(similar_etf))] # TODO limit 여부 판단 필요.
                    response = f"""검색결과: `{(', ').join(similar_etf)}`를 참조하여 질문자의 궁금증을 해소할 수 있는 답변을 만드세요."""

                else:
                    response = "검색결과: 주어진 ETF와 유사한 ETF를 찾지 못했습니다."

            else:
                response = "검색결과: 주어진 ETF와 유사한 ETF를 찾지 못했습니다."

            return response
        except:
            response = "검색결과: 주어진 ETF와 유사한 ETF를 찾지 못했습니다."
            return response