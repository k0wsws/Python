import os
from typing import Dict, Optional
import requests
import urllib
from langchain_core.callbacks import CallbackManagerForToolRun
from langchain_core.tools import BaseTool
from langchain_openai import ChatOpenAI
from langchain.schema import StrOutputParser
from utils import tool_input_utils
from utils.langfuse.langfuse_prompt_save import create_prompt
from langchain_core.prompts.chat import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)
from langfuse import Langfuse

USE_LANGFUSE_PROMPT_MANAGER_YN = os.environ.get("USE_LANGFUSE_PROMPT_MANAGER_YN", "N")

name = "retrive_news_prompt"

instruction_prompt = """
### Role Competencies ###
You are a financial news curator chatbot responding customer's question about {keyword} industrial market .
In the context field given below, you have the searched news articles regarding to the {keyword} industrial market.
The searched news result scheme: 
{{"title":"news headline", "originallink": "url for the original news article", "link":"url for the new article", "description":"cached page context", "pubDate":"Publish date of the atricle}}
Please generate the news context. 

### Context ###
{context}

### Generation Rules and Formats ###
1. You MUST generate your response in Korean Language (한국어)
2. Delete news article(s) with duplicate or similar headlines. List news articles with unique headlines
3. Delete news article(s) if the title is not relevant to {keyword}

Answer: 
"""

system_prompt = "You are a very knowledgeable chatbot who can answer almost any user's question"


class RetrieveNewsTools(BaseTool):
    """
    Tool for retrieve news from naver search engine api.
    """

    llm: ChatOpenAI = None

    name: str = "retrieve_news_tool"
    name_for_human: str = "retrieve_news_tool."
    description: str = "search industry news or trends."

    parameters: list[Dict] = [
        {
            "name": "keyword",
            "description": "keyword to query at search engine.",
            "required": True,
            "schema": {"type": "string"},
        },
    ]

    def _run(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None, ) -> str:
        pass

    async def _arun(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None, ) -> str:
        param = tool_input_utils.parse(tool_input)

        keyword = param["keyword"]
        assert keyword is not None

        params = urllib.parse.urlencode([("query", keyword)])

        res = requests.get(
            f"https://openapi.naver.com/v1/search/news?{params}",
            headers={
                "Content-Type": "application/json",
                "X-Naver-Client-Id": os.environ.get("X_NAVER_CLIENT_ID", ""),
                "X-Naver-Client-Secret": os.environ.get("X_NAVER_CLIENT_SECRET", ""),
            },
        )

        context = res.json()["items"]

        langfuse = Langfuse()

        if USE_LANGFUSE_PROMPT_MANAGER_YN == "Y":
            try:
                template = langfuse.get_prompt(name).prompt
            except Exception as e:

                template = instruction_prompt
                create_prompt(
                    name,
                    template,
                    config={
                        "name": name,
                        "instruction_prompt": instruction_prompt,
                        "system_prompt": system_prompt,
                        # "template" : prompt.template
                    }
                )
        else:
            template = instruction_prompt

        system_message_prompt = SystemMessagePromptTemplate.from_template(system_prompt)
        human_message_prompt = HumanMessagePromptTemplate.from_template(template)
        prompt = ChatPromptTemplate.from_messages(
            [system_message_prompt, human_message_prompt]
        )

        news_query_chain = (
                prompt | self.llm | StrOutputParser()
        )

        return await news_query_chain.ainvoke({"keyword": keyword, "context": context}, {})
