from langchain_core.tools import BaseTool
from langchain_openai import ChatOpenAI
from typing import Dict, List, Optional
from utils import tool_input_utils
from langchain_core.runnables import RunnableLambda
from chainlit.custom.database.postgres_connector import db_connector
from langchain_core.runnables import RunnablePassthrough, chain
from langchain.output_parsers import CommaSeparatedListOutputParser
from langchain.prompts import ChatPromptTemplate

from langchain_core.callbacks import (
    CallbackManagerForToolRun,
)

_available_topics = None


class ThemeSearchTool(BaseTool):
    """
    Tool for recommend etf
    """

    llm: ChatOpenAI = None
    name: str = "theme_search_tool"
    name_for_human: str = "theme_search_tool"
    description: str = (f"""Find ETFs related to a general theme, not specific names. Use '{name}' when you need to provide information about ETFs related to a broad investment theme, such as an industry sector, investment strategy. 
The tool is intended for questions about general topics, such as investing in specific sectors (e.g., technology, healthcare), strategies (e.g., value investing, growth investing), or trends (e.g., emerging markets, renewable energy).
Do not use this tool for requests involving specific companies or stocks, individual ETF names, or narrowly focused queries that mention a specific entity or product. 
Ensure that the question pertains to a general investment theme or category rather than a specific stock or ETF name.
    """)

    parameters: list[Dict] = [
        {
            "name": "question",
            #"description": "please write specific question or query to answer the user\'s Question based on the [<PLAN>] and the [<previous_conversation_history>].",
            "description": "repeat the full text of given user's Question",
            "required": True,
            "schema": {"type": "string"},
        },
    ]

    def _run(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        pass

    async def _arun(self, tool_input: str = "", run_manager: Optional[CallbackManagerForToolRun] = None) -> str:
        param = tool_input_utils.parse(tool_input)

        question = param["question"]
        assert question is not None
 
        async def _fetch_available_topics(_):
            """
             전체 topic 조회해서 parsing 하기.
            """
            global _available_topics

            if _available_topics is not None:
                return _available_topics

            else:
                # query: str = """
                #  SELECT string_agg(topics, ',') AS unique_topics FROM (
                #             SELECT DISTINCT unnest(string_to_array(universe_theme, ',')) AS topics 
                #             FROM etf.etf_recent_master
                #  ) as a;
                # """

                query: str = """
SELECT string_agg(distinct topics, ',') AS unique_topics FROM (
SELECT DISTINCT unnest(string_to_array(universe_theme, ',')) AS topics 
FROM etf.etf_recent_master
UNION ALL
SELECT DISTINCT unnest(string_to_array(market_class_3, ',')) AS topics 
FROM etf.etf_recent_master 
UNION ALL
SELECT DISTINCT unnest(string_to_array(ace_peer, ',')) AS topics 
FROM etf.etf_recent_master 
ORDER BY topics ASC
) a;
"""
                res = db_connector.execute(command=query, fetch="all")
                assert len(res) > 0

                _available_topics = res[0]['unique_topics']

            return _available_topics

        async def find_universe(question):
            _max = lambda _: 3
            prompt = ChatPromptTemplate.from_messages(
                [('system', """You are a ETF universe theme categorizer.
Please select the entities related to the question from the topics list.
Do not create topics that are not in the list, and only extract the relevant topics.

If you cannot find a topic relevant to the question, please choose None.

Here are examples to guide you:
- Example 1
    - "question": "Please recommend ETFs that invest in Japanese semiconductors."
    - "answer": 일본반도체, 반도체, 일본
- Example 2
    - "question": "Please recommend ETFs that invest in U.S. Treasury bonds."
    - "answer": 북미채권, 미국30년국채
- Example 3
    - "question": "Please recommend ETFs that invest in U.S. healthcare."
    - "answer": 헬스케어, 헬스케어섹터
- Example 4
    - "question": "Please recommend ETFs that invest in U.S. REITs."
    - "answer": 리츠, 글로벌리츠재간접
- Example 5
    - "question": "Recommend ETFs employing covered call strategy."
    - "answer": 옵션인컴
- Example 6
    - "question": "Please recommend ETFs that invest in Antarctica."
    - "answer": [None]
                  
If you cannot find a topic relevant to the question, please choose None.

Please choose at most 5 topic(s) that is most related to answer the user's question from the list below:
{topics}

""")
                 ,
                 ('human', "{question}")
            ])

            ## TODO: 만약 추천할 것이 없는 경우? 어떻게 해야 하는가?
            res = await (
                  RunnablePassthrough.assign(topics=_fetch_available_topics)|#, max=_max) | \
                   prompt | \
                   self.llm
                  ).ainvoke(input=dict(question=question))
            if 'None' in res.content: 
                res.content = '찾을 수 없습니다.'
            else:
                # 토픽을 찾았는데 LLM 마음대로 생성한 경우, 실제 universe_theme에 있는것만 토픽으로 사용 
                topic_list = [item.strip() for item in res.content.split(',')]
                _available_topics_ = [topic.strip() for topic in _available_topics.split(',')]
                filtered_topic = [item for item in topic_list if item in _available_topics_]
                for remove_topic in ['ETF', 'ACE PEER', ' ACE PEER']:
                    if remove_topic in filtered_topic:
                        filtered_topic.remove(remove_topic)
                filtered_topics = ', '.join(filtered_topic)
                if not filtered_topics:
                    res.content = "해당하는 etf를 찾지 못했습니다."
                else:
                    res.content = filtered_topics

            return res
        
        def generate_query(keywords):

            # TODO: keywrds = [] 일때의 예외처리.
            # TODO: 현재는 market_class_3를 따로 가져오지만, 추후 DB에서 통합된다면 수정 필요.
         
            # _ACE_PEER_ = "ACE PEER"

        #   if _ACE_PEER_ in keywords:
        #       _keywords = [k for k in keywords if k != _ACE_PEER_]

        #       likes = [ f"((universe_theme LIKE '%{iter}%' OR market_class_3 LIKE '%{iter}%') AND (universe_theme LIKE '%{_ACE_PEER_}%'))" for iter in _keywords]
        #    else:
        #       likes = [f"(universe_theme LIKE '%{kw}%' OR market_class_3 LIKE '%{kw}%')" for kw in keywords]
            # likes = [ f"((universe_theme LIKE '%{iter}%' OR market_class_3 LIKE '%{iter}%'))" for iter in keywords]
            # ACE_ql = f"SELECT universe_theme, market_class_3 ,etf_ticker, etf_name, investment_points FROM etf.etf_recent_master erm WHERE ({' OR '.join(likes)}) AND brand = 'ACE' ORDER BY erm.asset_under_management DESC;"
            # non_ACE_ql = f"SELECT universe_theme, market_class_3 ,etf_ticker, etf_name FROM etf.etf_recent_master erm WHERE ({' OR '.join(likes)}) AND brand != 'ACE' ORDER BY erm.asset_under_management DESC;"
            likes = f"universe_theme SIMILAR TO '%({"|".join(keywords)})%' OR market_class_3 SIMILAR TO '%({"|".join(keywords)})%' OR ace_peer SIMILAR TO '%({"|".join(keywords)})%'"
            ACE_ql = f"SELECT ace_peer, universe_theme, market_class_3, etf_ticker, etf_name, investment_points FROM etf.etf_recent_master erm WHERE {likes} AND brand = 'ACE' ORDER BY erm.asset_under_management DESC;"
            non_ACE_ql = f"SELECT ace_peer, universe_theme, market_class_3, etf_ticker, etf_name FROM etf.etf_recent_master erm WHERE {likes} AND brand != 'ACE' ORDER BY erm.asset_under_management DESC;"

            # return dict(keywords=keywords, query=ql)
            return dict(keywords=keywords, non_ace_query=non_ACE_ql, ace_query=ACE_ql)
            
        def execute_query(ctx):
            keywords, non_ace_ql, ace_ql = ctx['keywords'], ctx['non_ace_query'], ctx['ace_query']
            success=False
            matches=None
            try:
                ace_matches = db_connector.execute(command=ace_ql, fetch="all")
                non_ace_matches = db_connector.execute(command=non_ace_ql, fetch="all")
                for each_list in [ace_matches, non_ace_matches]:
                    indices_to_remove = []
                    for i, each_etf in enumerate(each_list):
                        matching = False
                        for each_theme in f"{each_etf['universe_theme']},{each_etf['market_class_3']},{each_etf['ace_peer']}".split(","):
                            if each_theme in keywords: # 포함되는지 이중 체크
                                matching = True
                        if not matching: # 없으면 제거
                            indices_to_remove.append(i)
                    for index in sorted(indices_to_remove, reverse=True):
                        each_list.pop(index)
                if ace_matches or non_ace_matches:
                    success = True
            except Exception as ex:
                print(f"ERROR in {ex}")
                # raise InterruptedError() ## 예외 처리 로직 필요.
          
            return dict(success=success, non_ace_etfs=non_ace_matches, ace_etfs=ace_matches, keywords=keywords)

        async def pick_etfs(ctx):
            if not ctx['success']:
                return "해당하는 ETF를 찾지 못했습니다."

            non_ace_etfs, ace_etfs, keywords = ctx['non_ace_etfs'], ctx['ace_etfs'], ctx['keywords']
            # etfs, keywords, ace_etfs = ctx['etfs'], ctx['keywords'] #, ctx['ace_etfs']

            param = tool_input_utils.parse(tool_input)
            question = param["question"]
            # _max = lambda _: 3
            _max = lambda _: 5
            unlimit_keywords  = ["전부", "모두", "전체", "가장", "중에"]
            if any(each_unlimit_keyword in question for each_unlimit_keyword in unlimit_keywords):
                _max = lambda _: 35

            _topics = lambda _: ', '.join(list(keywords))

            # _etfs = lambda _: str(etfs)
            _etfs = lambda _: str(ace_etfs)
            _etfs2 = lambda _: str(non_ace_etfs)
                 # If no suitable ETF is found, return '해당하는 ETF를 찾지 못했습니다.'
            prompt = ChatPromptTemplate.from_messages(
                  #Please choose at most {max} items from ETFS below.
                  # You are a ETF suggester.
                  # 모든 ETF의 선택은 테마조건(미국 반도체, 일본 리츠 등)을 기준으로 해야 합니다. 사용자의 질문에 추가조건(AUM, 수익율, 분배금 등)이 포함되어 있어도, 테마조건만으로 선택해야 합니다. 
                  # 사용자의 질문에 테마조건(미국 반도체, 일본 리츠 등 ETF가 투자하는 테마) 이외의 추가조건(AUM, 수익율, 분배금 등)이 주어진다면, 테마조건에 완벽하게 부합하는 **모든** ETF를 선택하세요.
                [('system', """
# Task
Select ETFs related to the user's question and topics from the ACE ETF lists and NON-ACE ETF lists.

# ACE ETF lists
{ace_etfs}

# NON-ACE ETF lists
{non_ace_etfs}

# Important Guidelines
Select ETFs from the ETF lists based on the topic most similar to the question.
First select ETFs from the ACE ETF lists, and then choose ETFs from the NON-ACE ETF lists.
When the question includes a country name, region name, or global, then it must be reflected.
The selected ETF must have at least one of the topics in the 'topics' section included in either 'universe_theme' or 'market_class_3'.
모든 ETF의 선택은 테마조건(미국 반도체, 일본 리츠 등)을 기준으로 해야 합니다. 사용자의 질문에 추가조건(AUM, 수익율, 분배금 등)이 포함되어 있어도, 테마조건만으로 선택해야 합니다. 
사용자의 질문에 테마조건(미국 반도체, 일본 리츠 등 ETF가 투자하는 테마)이 주어지면, 테마조건에 완벽하게 부합하는 **모든** ETF를 선택하세요.
If no suitable ETF is found, return '해당하는 ETF를 찾지 못했습니다.'
'Additional_Information' should only be provided if the selected ETF starts with 'ACE'."

# User's Question
{question}

# Topics
{topics}

# Format
Provide each item as the following format: 검색결과: {{etf_name}} ({{etf_ticker}})
Items sepearated by comma(,) as the following format(example):
If an ETF starting with ACE is selected, please add 'Additional_Information' at the bottom of the existing search results in the format: {{etf_name}}({{etf_ticker}}): 'investment_points'.
No further details should be provided besides 'search_results' and 'Additional_Information'.                 

## Example 1
Search_Results: {{etf_name}} ({{etf_ticker}})...
Additional_Information: {{etf_name}} ({{etf_ticker}}): 'investment_points'...
""")
                #   Provide each item as the following format: {{etf_name}}({{etf_ticker}}):description
                #   Items sepearated by comma(,) as the following format(example):
                #   {{ACE AI반도체포커스(469150):description,
                #   ACE 일본반도체(469160):description,
                #   TIGER Fn반도체TOP10(396500):description}}
                 ,
                 ('human', "{question}")
            ])
            # prompt = prompt.partial(etfs=str(etfs), topics=', '.join(list(keywords)))

            res = await (
                #   RunnablePassthrough.assign(topics=_topics, max=_max, etfs=_etfs) | \
                    RunnablePassthrough.assign(topics=_topics, ace_etfs=_etfs, non_ace_etfs=_etfs2) | #, max=_max, ace_etfs=_etfs, non_ace_etfs=_etfs2) | \
                    prompt | \
                    self.llm
                ).ainvoke(input=dict(question=question))
            #사용자에게 언급해도 되는 일반적인 키워드(지수, 특정테마, 특정국가 등)
            general_keyword: List = ['2차전지','5G','AI','ESG','IT(정보기술)','KRX100','KRX300','MSCI','S&P500','건설','게임','경기(자유)소비재','경기방어','구리','국채',
                '글로벌','금','금속','금융','금현물','기계','남미','내수주','농산물','농업','단기채권','달러','대만','대형주','독일','라이프사이클','럭셔리','로봇','리츠','메타버스','멕시코',
                '물','미디어','미래차','바이오','반도체','방산','배당','베트남','베트남주식','부동산기타','북미주식','빅테크','사이버보안','산업재','삼성그룹','생활(필수)소비재','선진국','성장','성장소비','소비','소재',
                '소프트웨어','수소','수출주','신재생에너지','신흥국','신흥국주식','싱가포르','아시아','에너지','엔','여행','우선주','우주','운송','원유','원자력','월배당','유럽','유럽주식','유럽채권','유전자','은','은행',
                '의료기기','인공지능','인도','인도네시아','인도주식','인프라','일본','일본Nikkei','일본TOPIX','일본반도체','일본주식','자동차','자산배분','전기차','조선','중국','중국CSI300','중국소비','중국주식','중남미주식',
                '증권','지주회사','철강','코스닥','코스피','코스피200','코스피200TR','콩','클라우드','탄소배출권','토탈리턴','팔라듐','포스코그룹','필리핀','하이볼','해외원자재','헬스케어','현금','화장품','회사채','회사채권','희토류']
            keywords = [k for k in keywords if k in general_keyword]
            res_topics = ""
            if keywords:
                res_topics = f"""topics:[{', '.join(keywords)}]\n"""
            prefix_content = "1. Sequentially list all 'Search_Results'.\n"
            if "Additional_Information" in res.content:
                prefix_content += """2. 'Search_Results'만을 모두 나열한 후, 'Additional_Information'의 **정보를 간단하게 요약하여** 사용자에게 제공합니다.('Search_Results'의 나열에 'Additional_Information'가 포함되면 안됩니다.)
3. 'Additional_Information'는 반드시 해당 ETF를 설명할 때만 사용되어야 합니다.
4. If the next step is not 'Final Answer', in subsequent steps, both the 'Additional_Information' and item 2 should be completely ignored. \n"""
            prefix_content += """\n**However, the term '추천' should not be used.**\n\n"""
            response = prefix_content + res.content


            if "해당하는 ETF를 찾지 못했습니다." in res.content:
                return "해당하는 ETF를 찾지 못했습니다."
            else:
                response = res_topics + response
                return response

        @chain
        def runnable(text):
            return RunnableLambda(find_universe) | \
                CommaSeparatedListOutputParser() | \
                RunnableLambda(generate_query) | \
                RunnableLambda(execute_query) | \
                RunnableLambda(pick_etfs)

        res = await runnable.ainvoke(question, {"callbacks": run_manager.get_child()})

        return res