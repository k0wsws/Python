import os
from langchain_core.language_models import BaseLanguageModel
from langchain_core.runnables import RunnableSerializable
from langfuse import Langfuse

from langchain.schema import StrOutputParser
from langchain_core.prompts.chat import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)
from utils.langfuse.langfuse_prompt_save import create_prompt

USE_LANGFUSE_PROMPT_MANAGER_YN = os.environ.get("USE_LANGFUSE_PROMPT_MANAGER_YN", "N")

name: str = "etf_name_select_agent"

system_prompt: str = """You are an expert in extracting and matching the most relevant ETF names from a given list based on user input. 
Your task is to analyze the user's question, identify specific ETF names or keywords, and compare them against a list of ETF names to find the most relevant matches. 
Your response should strictly follow the output format provided and should not include any additional text or explanations.
"""

instruction_prompt: str = """
## Input Format:
- `question`: {question}
- `etf_name_list`: {etf_name_list}

## Task

1. Analyze the `question` to determine if it specifically mentions an ETF name.
  - If the `question` directly references a specific ETF name and it contains one of the following brand names: ["ACE", "FOCUS", "PLUS", "TIGER", "RISE", "KOSEF", "HANARO", "KODEX", "SOL", "KCGI", "HK", "UNICORN", "히어로즈", "BNK", "KoAct", "TRUSTON", "WOORI", "1Q", "마이다스", "TIMEFOLIO", "DAISHIN343", "마이티", "에셋플러스", "파워", "VITA", "ITF", "TREX"], proceed to step 2.
  - If the `question` is broad or generic (e.g., "ETFs that invest in the US market with monthly distributions"), or asks for ETFs based on general criteria, return an empty list (`[]`).
2. If a specific ETF name is identified and matches a brand from the list above, find and list all ETF names in the `etf_name_list` that contain the same brand name mentioned in the question.
  - Return only the most closely matching ETF name that includes the brand name identified in the `question`.
3. If the `question` specifies a number (e.g., 3 or 4), find and return that exact number of closely matching ETFs based on the specific ETF name and brand. If there aren't enough matches, return as many as possible up to the specified number.
4. If no specific number is mentioned in the `question`, return the single most closely matching ETF that includes the brand name from the question.
5. If no relevant match is found, return an empty list.

## Output Format:
- If a specific ETF name is mentioned and matches are found: `[{{"etf_name": "<ETF Name>", "etf_ticker": "<Ticker ID>"}}, ...]` (up to the specified number if requested)
- If a specific ETF name is mentioned and only one match is found: `[{{"etf_name": "<ETF Name>", "etf_ticker": "<Ticker ID>"}}]`
- If the `question` is broad or generic, or no specific ETF name is mentioned, or no match is found: `[]`
- Please ensure that <Ticker ID> is sequences of 6-digit numbers.
- **Do not** include any extra information or explanations.
"""


async def create_etf_name_select_agent(llm: BaseLanguageModel) -> RunnableSerializable[dict, str]:
    langfuse = Langfuse()

    if USE_LANGFUSE_PROMPT_MANAGER_YN == "Y":
        try:
            template = langfuse.get_prompt(name).prompt
        except Exception as e:
            template = instruction_prompt

            create_prompt(
                name,
                template,
                config={
                    "name": name,
                    "instruction_prompt": instruction_prompt,
                    "system_prompt": system_prompt,
                }
            )
    else:
        template = instruction_prompt

    prompt = ChatPromptTemplate.from_messages(
        [SystemMessagePromptTemplate.from_template(system_prompt), HumanMessagePromptTemplate.from_template(template)]
    )
    agent = prompt | llm | StrOutputParser()
    agent.name = name

    return agent
