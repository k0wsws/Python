import os
from datetime import date
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate
from langfuse import Langfuse
from langchain_core.language_models import BaseLanguageModel
from langchain_core.runnables import RunnableSerializable

from utils.langfuse.langfuse_prompt_save import create_prompt

USE_LANGFUSE_PROMPT_MANAGER_YN = os.environ.get("USE_LANGFUSE_PROMPT_MANAGER_YN", "N")

# Prompt
name: str = "sql_generation_agent"

today = date.today()
formatted_date = today.strftime("%Y년 %m월 %d일")

system_prompt: str = f"""You are an expert in generating SQL queries based on user's question and a list of ETF tickers.
Your task is to create SELECT queries for PostgresQL that meet the user's information request while following strict query generation rules.
You must ensure that your queries are precise, unambiguous, and use the provided column and table names accurately. 
First, I should plan what table and column information is required to answer user's question.
Second, return the generated SQL query as an output in sql code block format (e.g., ```SELECT ... ```). You should generate only one SQL Query to find answer.
Do not include any INSERT, UPDATE, DELETE, or DROP statements in the generated SQL.

Current date: {formatted_date}
"""

exists_etf_ticket_list_instruction_prompt: str = """
## Inputs:
- Question: {question}
- ETF Ticker List: {etf_ticker_list}

## Tasks:
  1. Analyze the `Question` to determine the specific data the user is requesting.
  2. Construct a SELECT query that accurately retrieves the data from the relevant table(s).

{table_struct_prompt}

## SQL Query Generation Rules:
  1. Use the `ETF Ticker List` exclusively for filtering with the `etf_ticker` column. Users are mainly informed about the etf information in the etf_ticker list.
  2. Do not use `etf_name` or `tracking_index`for filtering. Using columns like `etf_name` or `tracking_index` for filtering will result in an invalid query.
  3. Do not use `etf_name`, `tracking_index`, or other columns with `LIKE` or `=` operators for filtering.
  4. **Use only the exact column names as provided in the Table Structure, and do not use `AS` to create aliases for any column names**.
  5. Ensure the SQL query retrieves **only** the data explicitly requested in the `Question`. 
    - If the `Question` asks for "보수", query only the columns related to fees such as `total_expense_ratio` and `fee_ratio series`.
    - If the question asks for "구성종목" (constituent items), query using `holding_weight` in descending order.
    - If the `Question` involves comparisons or asks for differences between specific ETFs, focus **only** on numerical information related to returns (e.g., `nav_total_return_1week`), fees (e.g., `total_expense_ratio`, `management_fee_ratio`), and dividends (e.g., `recent_dividend_amount`, `recent_dividend_ratio`).
    - If the `Question` asks for details about dividend payments, you can retrieve dividend data from `etf_recent_master` or other appropriate tables, considering the `annual_dividend_amount` column in `etf_recent_master`. For "recent" dividend data, sort the results by `dividend_date` in descending order and apply `LIMIT 1` to return the most recent entry only.
    - If the `Question` asks for "종목 코드" or "티커", return only the `etf_ticker` column.
  6. **When using DESC, ASC, or ORDER BY conditions on a specific column, always include the "NULLS LAST" condition.**
  7. **You MUST limit the sql query up to 8 columns unless the user explicitly requests more.**
  8. **You MUST limit the sql result up to {top_k} rows using 'LIMIT {top_k}' query, unless the user explicitly requests more.**
  9. Please limit total tables up to 2 when join tables, and always use `LEFT JOIN` and all column and table names must be clearly specified.
    - In case using 'JOIN' query, always mention the table name in front of selected column name.
  10. If the `Question` asks info at certain date or specific time, refer to table named start with 'etf_historical' table.
  11. If date or time info is not granted, refer to recent table, or search for recently recorded date using `WHERE recorded_date = (SELECT MAX(recorded_date) FROM etf_historical_constituent_holdings)` query condition.
  12. Use only SELECT statements. DO NOT use any DML statements of following: (INSERT, UPDATE, DELETE, DROP).
  13. In case of ETF comparative question, remove the 'LIMIT' condition in SQL Query to compare value among selected ETFs.
  14. If the `Question` required condition of ordinal number, 'LIMIT' condition lift to corresponded number in SQL Query.
  15. If the `Question` contains compound on country and theme split the country. For example, '일본반도체' will return '일본' and '반도체'.

## Tips
  - To avoid ambiguity, **always prepend table names to column names in your SELECT statement and WHERE clause.
  - Ensure accuracy in matching the ETF brand names from the list here: "ACE", "FOCUS", "PLUS", "TIGER", "RISE", "KOSEF", "HANARO", "KODEX", "SOL", "KCGI", "HK", "UNICORN", "히어로즈", "BNK", "KoAct", "TRUSTON", "WOORI", "1Q", "마이다스", "TIMEFOLIO", "DAISHIN343", "마이티", "에셋플러스", "파워", "VITA", "ITF", "TREX".
  - 특정 종목 또는 주식을 포함하는 질문에 관한 경우 (보통 포함된 이라고 많이 질문함), etf_historical_constituent_holdings 테이블에서 `Current Date`에 유의해서 holding_name 컬럼을 참고해보세요. 
  - For questions about performance over periods, refer to etf_nav_total_return. ((default: nav_total_return_1week))
  - For questions about closing price returns, refer to etf_close_price_total_return. ((default: price_total_return_1day))
  - Avoid ambiguity issues by adding the table name to the column used in the WHERE Condition.
  - ETF Ticker List 값이 여러개고, 이름은 하나인 경우에는 이름이 가장 비슷한 ticker정보를 위주로 조회해.
  - If no specific time is given and only 'recent' is mentioned, consider up to three month ago.
  - Date Formatting examples: {{"24년 7월":"2024-07-01"}}, {{"6월 13일":"2024-06-13"}}, {{"24년":"2024-01-01"}}
  - 만약 질문에 "두 달 전", "4개월 전", "6개월" 등의 기간이 포함되어 있다면, Current Date (오늘)에서 해당 기간을 빼서 계산해.
  - Current Date (오늘): {current_date}
  - 1월 1일은 쉬는날이라 데이터가 없음으로 연초/년초 에 관한 질문은 다음 날짜를 사용해: {date_example}
  - 최대 3년까지의 수익률만 존재하기 때문에 질문에서 3년보다 초과되는 기간의 정보를 요청할 경우 가장 긴 기간의 데이터를 사용해 선택한 기간으로 답변하세요.
  - For reference, there is no information on current date in the DB, and the date is saved until previous day.
  - ETF에 여러개의 고유한 종목이 모두 포함되어 있는지 확인하려면 아래의 조건절을 활용하세요.
    - **WHERE etf_historical_constituent_holdings.holding_name IN ('holding_name1', 'holding_name2')**
    - **HAVING COUNT(DISTINCT etf_historical_constituent_holdings.holding_name)**
  - In case finding superlative condition like 'max', 'min', 'most', use condition query that matching equivalent multiple ETFs and exclude 'LIMIT' clause.
  - 커버드콜 ETF는 etf_name에 커버드콜이 포함되는 경우로 찾아야합니다.
## Output Format
  First. I should plan what table and column information is required to answer user's question, and select only 8 relevant columns if necessary.
  Second. return the generated SQL query as an output in sql code block format (e.g., ```SELECT ... ```). You have to generate only one SQL executable query, minimizing the rewriting.

------------------------------------
Here is the planning and SQL code block output: First.
"""

not_exists_etf_ticker_list_instruction_prompt: str = """
## Inputs:
- Question: {question}

## Tasks:
  1. Analyze the `Question` to determine the specific data the user is requesting.
  2. Construct a SELECT query that accurately retrieves the data from the relevant table(s).

{table_struct_prompt}

## SQL Query Generation Rules:
  1. Reference the `Question` to determine appropriate filtering conditions based on the user's input. Ensure that the filtering conditions are correctly applied based on the value type:
    - **ETF name (ETF 이름)**: When the user refers to an ETF name such as 'ACE 200', it is a full text value. However, when possible, use the `LIKE` condition for partial text matching. For example, `WHERE etf_name LIKE '%ACE%'` can be used to find ETFs that contain 'ACE' in their name.
    - **Holding name (보유 종목)**: Similar to ETF name, when the user refers to a holding name like '삼성전자', use the `LIKE` condition for partial matching. For example, `WHERE holding_name LIKE '%삼성%'` will return holdings that include '삼성' in their name.
    - **ETF Ticker (티커)**: When referring to an ETF ticker like '105190', it is a numeric value. Ensure that the `WHERE etf_ticker = '105190'` condition reflects the exact numeric format.
  2. **Use only the exact column names as provided in the Table Structure, and do not use `AS` to create aliases for any column names**.
  3. Ensure the SQL query retrieves **only** the data explicitly requested in the `Question`. 
    - If the `Question` asks for "보수", query only the columns related to fees such as `total_expense_ratio` and `fee_ratio series`.
    - If the `Question` involves comparisons or asks for differences between specific ETFs, focus **only** on numerical information related to returns (e.g., `nav_total_return_1week`), fees (e.g., `total_expense_ratio`, `management_fee_ratio`), and dividends (e.g., `recent_dividend_amount`, `recent_dividend_ratio`).
    - If the `Question` asks for details about dividend payments, you can retrieve dividend data from `etf_recent_master` or other appropriate tables, considering the `annual_dividend_amount` column in `etf_recent_master`. For "recent" dividend data, sort the results by `payment_date` in descending order and apply `LIMIT 1` to return the most recent entry only.
    - If the `Question` asks for "종목 코드" or "티커", return only the `etf_ticker` column.
  4. **When using DESC, ASC, or ORDER BY conditions on a specific column, always include the "NULLS LAST" condition.**
  5. **You MUST limit the sql query up to 8 columns unless the user explicitly requests more.**
  6. **You MUST limit the sql result up to {top_k} rows using 'LIMIT {top_k}' query, unless the user explicitly requests more.**
  7. Please limit total tables up to 2 when join tables, and always use `LEFT JOIN` and all column and table names must be clearly specified.
    - In case using 'JOIN' query, always mention the table name in front of selected column name.
  8. If the `Question` asks info at certain date or specific time, refer to table named start with 'etf_historical' table.
  9. If date or time info is not granted, refer to recent table, or search for recently recorded date using `WHERE recorded_date = (SELECT MAX(recorded_date) FROM etf_historical_constituent_holdings)` query condition.
  10. Use only SELECT statements. DO NOT use any DML statements of following: (INSERT, UPDATE, DELETE, DROP).
  11. For `etf_ticker` and `etf_name`, you should append table name to column name to avoid ambiguity.
  12. In case finding superlative condition like 'max', 'min', 'most', use condition query that matching equivalent multiple ETFs and exclude 'LIMIT' clause.
     - Question example: Let's find the highest total expense ratio ETF.
     - query condition example: WHERE total_expense_ratio = (select MAX(total_expense_ratio) from etf_recent_master)
  13. In case of ETF comparative question, remove the 'LIMIT' condition in SQL Query to compare value among selected ETFs.
  14. If the `Question` required condition of ordinal number, 'LIMIT' condition lift to corresponded number in SQL Query.
  15. If the `Question` contains compound on country and theme split the country. For example, '일본반도체' will return '일본' and '반도체'.

## Tips
  - To avoid ambiguity, **always prepend table names to column names in your SELECT statement and WHERE clause.
  - Ensure accuracy in matching the ETF brand names from the list here: "ACE", "FOCUS", "PLUS", "TIGER", "RISE", "KOSEF", "HANARO", "KODEX", "SOL", "KCGI", "HK", "UNICORN", "히어로즈", "BNK", "KoAct", "TRUSTON", "WOORI", "1Q", "마이다스", "TIMEFOLIO", "DAISHIN343", "마이티", "에셋플러스", "파워", "VITA", "ITF", "TREX".
  - 특정 종목 또는 주식을 포함하는 질문에 관한 경우 (보통 포함된 이라고 많이 질문함), etf_historical_constituent_holdings 테이블에서 `Current Date`에 유의해서 holding_name 컬럼을 참고해보세요.
  - For `etf_ticker` and `etf_name`. you should use table alias format to filter the conditional results.
  - For questions about performance over periods, refer to etf_nav_total_return. ((default: nav_total_return_1week))
  - For questions about closing price returns, refer to etf_close_price_total_return. ((default: price_total_return_1day))
  - If no specific time is given and only 'recent' is mentioned, consider up to a week or a month ago.
  - Avoid ambiguity issues by adding the table name to the column used in the WHERE Condition.
  - 만약 질문에 "두 달 전", "4개월 전", "6개월" 등의 기간이 포함되어 있다면, Current Date (오늘)에서 해당 기간을 빼서 계산해.
  - Date Formatting examples: {{"24년 7월":"2024-07-01"}}, {{"6월 13일":"2024-06-13"}}, {{"24년":"2024-01-01"}}
  - Current Date (오늘): {current_date}
  - 1월 1일은 쉬는날이라 데이터가 없음으로 연초/년초 에 관한 질문은 다음 날짜를 사용해: {date_example}
  - 최대 3년까지의 수익률만 존재하기 때문에 질문에서 3년보다 초과되는 기간의 정보를 요청할 경우 가장 긴 기간의 데이터를 사용해 선택한 기간으로 답변하세요.
  - For reference, there is no information on current date in the DB, and the date is saved until previous day.
  - ETF에 여러개의 고유한 종목이 모두 포함되어 있는지 확인하려면 아래의 조건절을 활용하세요.
    - **WHERE etf_historical_constituent_holdings.holding_name IN ('holding_name1', 'holding_name2')**
    - **HAVING COUNT(DISTINCT etf_historical_constituent_holdings.holding_name)**
  - 커버드콜 ETF는 etf_name에 커버드콜이 포함되는 경우로 찾아야합니다.

## Output Format
  First. I should plan what table and column information is required to answer user's question, and select only 8 relevant columns if necessary.
  Second. return the generated SQL query as an output in sql code block format (e.g., ```SELECT ... ```). You have to generate only one SQL executable query, minimizing the rewriting.

------------------------------------
Here is the planning and SQL code block output: First.
"""


async def create_sql_generation_agent(llm: BaseLanguageModel, exists_etf_ticker_list: bool) -> RunnableSerializable:
    langfuse = Langfuse()

    instruction_prompt: str = exists_etf_ticket_list_instruction_prompt \
        if exists_etf_ticker_list else not_exists_etf_ticker_list_instruction_prompt

    if USE_LANGFUSE_PROMPT_MANAGER_YN == "Y":
        try:
            template = langfuse.get_prompt(name).prompt
        except Exception as e:
            template = instruction_prompt

            create_prompt(
                name,
                template,
                config={
                    "name": name,
                    "instruction_prompt": instruction_prompt,
                    "system_prompt": system_prompt,
                }
            )
    else:
        template = instruction_prompt

    prompt = ChatPromptTemplate.from_messages(
        [SystemMessagePromptTemplate.from_template(system_prompt), HumanMessagePromptTemplate.from_template(template)]
    )

    agent = prompt | llm | StrOutputParser()
    agent.name = name

    return agent


table_struct_prompt: str = """
## SQL table structure and column details:
{{
  "tables": {{
    "etf_recent_master": {{
      "description": "This table contains recent meta information about ETFs as of yesterday, 가장 최근 (어제) ETF 메타 정보",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "tracking_index", "description": "Tracking index, 기초지수, 추종지수, ETF가 추종하고자 하는 지수 또는 벤치마크, ETF이름과는 다름, 구성 주식 종목과는 다름" }},
        {{ "name": "management_firm", "description": "Asset management firm, 자산운용사" }},
        {{ "name": "brand", "description": "ETF brand name, ETF 브랜드 이름", }},
        {{ "name": "risk_level", "description": "Risk level. The risk level ranges from 1 to 5, with higher values indicating greater risk., 위험도" }},
        {{ "name": "inception_date", "description": "Trading start date, listing date, ETF 거래시작일, ETF 상장일자" }},
        {{ "name": "investment_points", "description": "ETF key investment points, investment highlights, 투자포인트" }},
        {{ "name": "inverse", "description": "Inverse status, 인버스 여부", "labels": {{True, False}} }},
        {{ "name": "total_return", "description": "Total return status considering reinvestment, 재투자 여부", "labels": {{True, False}} }},
        {{ "name": "creation_unit", "description": "Creation unit (CU), 설정 유닛, 신규 발행 주식 단위" }},
        {{ "name": "leverage", "description": "Leverage status, 레버리지 여부", "labels": {{True, False}} }},
        {{ "name": "personal_pension", "description": "Personal pension status, 개인연금 여부", "labels": {{True, False}} }},
        {{ "name": "retirement_pension", "description": "Retirement pension status, 퇴직연금 여부", "labels": {{True, False}} }},
        {{ "name": "fx_hedge", "description": "FX hedge status, 환헷지 여부", "labels": {{True, False}} }},
        {{ "name": "synthetic", "description": "Synthetic status, 합성 여부", "labels": {{True, False}} }},
        {{ "name": "passive", "description": "Passive status, 패시브 여부", "labels": {{True, False}} }},
        {{ "name": "monthly_dividend", "description": "Monthly dividend status, 월배당 여부", "labels": {{True, False}} }},
        {{ 
          "name": "market_class_1", 
          "description": "Major classification of ETF types (only use from labels)", 
          "labels": ["국내주식형", "국내채권형", "국내혼합형", "국내대체", "해외주식형", "해외채권형", "해외혼합형", "해외대체", "기타형"]
        }},
        {{ 
          "name": "market_class_2", 
          "description": "Middle classification of ETF types (only use from labels)", 
          "labels": ["국가별", "국공채권", "권역별", "글로벌채권", "기타", "대체기타", "미분류", "부동산", "섹터별", "액티브주식", "인덱스주식", "일반채권", "주식혼합", "지역채권", "채권혼합", "특별자산", "해외부동산", "해외자산배분", "해외주식혼합", "해외채권혼합", "해외특별자산", "회사채권"]
        }},
        {{ 
          "name": "market_class_3", 
          "description": "Sub-classification of ETF types (only use from labels)", 
          "labels": ["KP", "공공서비스섹터", "국공채권", "국내외주식", "국내특별자산", "글로벌리츠재간접", "글로벌주식", "글로벌채권", "글로벌하이일드채권", "금융섹터", "기타국가주식", "라이프사이클", "리버스마켓", "만기매칭채권", "멀티/기타섹터", "베트남주식", "부동산기타", "북미주식", "북미채권", "산업재섹터", "소비재섹터", "소재섹터", "신흥국주식", "아시아퍼시픽주식(ex J)", "아시아퍼시픽채권", "아태리츠재간접", "액티브주식배당", "액티브주식일반", "에너지섹터", "유럽주식", "유럽채권", "인덱스주식KRX300", "인덱스주식기타", "인덱스주식섹터", "인덱스주식코스피200", "인도주식", "일반채권", "일본리츠재간접", "일본주식", "임시미분류", "정보기술섹터", "주식혼합", "중국주식", "중남미주식", "초단기채권", "채권혼합", "해외원자재", "해외자산배분", "해외채권혼합", "해외특별자산", "헬스케어섹터", "회사채권"]
        }},
        {{ "name": "universe_theme", "description": "Multiple ETF theme keywords, ETF 종목 테마" }},
        {{ "name": "total_expense_ratio", "description": "Total expense ratio, 총보수, " }},
        {{ "name": "management_fee_ratio", "description": "Management fee ratio, 운용보수" }},
        {{ "name": "sell_fee_ratio", "description": "Sales fee ratio, 판매보수" }},
        {{ "name": "custody_fee_ratio", "description": "Custody fee ratio, 신탁보수 (custody)" }},
        {{ "name": "back_fee_ratio", "description": "Administrative fee ratio, 일반사무보수" }},
        {{ "name": "asset_under_management", "description": "Total assets under management (AUM), net asset total, 총 운용자산(AUM), 운용규모" }},
        {{ "name": "net_asset_value", "description": "Net asset value, 순자산금액(NAV)" }},
        {{ "name": "closing_price", "description": "Closing price of the last trading day, 전일 종가" }},
        {{ "name": "total_trade_volume", "description": "Total Trade Volume, 거래량" }},
        {{ "name": "total_trade_value", "description": "Total Trade Value, 거래대금" }},
        {{ "name": "beta", "description": "Beta, 베타, 특정 주식 또는 포트폴리오의 변동성이 시장 전체와 비교하여 어느 정도인지를 나타내는 지표" }},
        {{ "name": "alpha", "description": "Alpha, 알파, 특정 투자나 포트폴리오가 시장 벤치마크 대비 초과 수익을 얼마나 올렸는지를 나타내는 지표" }},
        {{ "name": "disparate_ratio", "description": "Recent disparate ratio, Recent premium/discount ratio, 괴리율" }},
        {{ "name": "recent_dividend_date", "description": "Recent dividend date, 최근 분배일(최근 배당일)}},
        {{ "name": "recent_dividend_amount", "description": "Recent dividend amount, 최근 분배금(최근 배당금)}},
        {{ "name": "recent_dividend_ratio", "description": "Recent dividend ratio, 최근 분배율(최근 배당율)}},
        {{ "name": "annual_dividend_amount", "description": "Total amount of dividends distributed over a year (1년 분배금 총합), 연간 분배금(연간 배당금), 연 환산 분배금, 1년 동안 분배한 금액의 총합" }},
        {{ "name": "annual_dividend_ratio", "description": "Total ratio of dividends distributed over a year, 연간 분배율(연간 배당율), 연 환산 분배율, 연간 분배금을 현재의 시장 가격으로 나눈 비율" }},
        {{ "name": "annual_dividend_distribution_count", "description": "Number of dividend distributions in a year; '1' means once, 연간 분배 횟수 (연간 배당 횟수)" }}
      ]
    }},
    "etf_recent_draw_down": {{
      "description": "This table provides the most recent maximum drawdown information, 가장 최근 기간별 최대 낙폭 정보, 고점대비 최대 하락폭",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "draw_down_1day", "description": "1-day drawdown, 1일 낙폭" }},
        {{ "name": "draw_down_1week", "description": "7-day drawdown, 1주일 낙폭" }},
        {{ "name": "draw_down_1month", "description": "30-day drawdown, 1개월 낙폭" }},
        {{ "name": "draw_down_3month", "description": "90-day drawdown, 3개월 낙폭" }},
        {{ "name": "draw_down_6month", "description": "180-day drawdown, 6개월 낙폭" }},
        {{ "name": "draw_down_1year", "description": "1-year drawdown, 1년 낙폭" }},
        {{ "name": "draw_down_3year", "description": "3-year drawdown, 3년 낙폭" }},
        {{ "name": "draw_down_year_to_date", "description": "Year-to-date drawdown, 연초대비 낙폭" }},
        {{ "name": "max_draw_down", "description": "Maximum drawdown (MDD), 상장 이후 최대 낙폭" }}
      ]
    }},
    "etf_recent_volatility": {{
      "description": "This table contains the most recent maximum volatility information for ETFs, 가장 최근 ETF의 최대 변동성 (표준편차) 정보",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "volatility_1week", "description": "7-day volatility, 1주일 변동성%" }},
        {{ "name": "volatility_1month", "description": "30-day volatility, 1개월 변동성%" }},
        {{ "name": "volatility_3month", "description": "90-day volatility, 3개월 변동성%" }},
        {{ "name": "volatility_6month", "description": "180-day volatility, 6개월 변동성%" }},
        {{ "name": "volatility_1year", "description": "1-year volatility, 1년 변동성%" }}
      ]
    }},
    "etf_nav_total_return": {{
      "description": "This table provides Net Asset Value(NAV) total return information considering reinvested dividends over various periods, 분배금 재투자를 고려한 기간별 순자산가치(NAV) 수익률 정보, 일반적으로 사용하는 수익률 정보 (DEFAULT)",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "nav_total_return_1day", "description": "1-day total NAV return, 전일(1일) 기준 순자산가치(NAV) 총수익률" }},
        {{ "name": "nav_total_return_1week", "description": "7-day total NAV return, 1주 기준 순자산가치(NAV) 총수익률" }},
        {{ "name": "nav_total_return_1month", "description": "30-day total NAV return, 1달 기준 순자산가치(NAV) 총수익률" }},
        {{ "name": "nav_total_return_3month", "description": "90-day total NAV return, 3달 기준 순자산가치(NAV) 총수익률" }},
        {{ "name": "nav_total_return_6month", "description": "180-day total NAV return, 6달 기준 순자산가치(NAV) 총수익률" }},
        {{ "name": "nav_total_return_1year", "description": "1-year total NAV return, 1년 기준 순자산가치(NAV) 총수익률" }},
        {{ "name": "nav_total_return_3year", "description": "3-year total NAV return, 3년 기준 순자산가치(NAV) 총수익률" }},
        {{ "name": "nav_total_return_year_to_date", "description": "Year-to-date total NAV return, 연초 대비 순자산가치(NAV) 총수익률" }},
        {{ "name": "cumulative_nav_total_return", "description": "Cumulative total NAV return, 누적 순자산가치(NAV) 총수익률" }}
      ]
    }},
    "etf_close_price_total_return": {{
      "description": "This table provides price-based total return information including dividends over various periods, 분배금 재투자를 고려한 기간별 종가 총수익률 정보",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "price_total_return_1day", "description": "1-day total price return, 전일(1일) 종가 기준 총수익률" }},
        {{ "name": "price_total_return_1week", "description": "7-day total price return, 1주 종가 기준 총수익률" }},
        {{ "name": "price_total_return_1month", "description": "30-day total price return, 한달 종가 기준 총수익률" }},
        {{ "name": "price_total_return_3month", "description": "90-day total price return, 3달 종가 기준 총수익률" }},
        {{ "name": "price_total_return_6month", "description": "180-day total price return, 6달 종가 기준 총수익률" }},
        {{ "name": "price_total_return_1year", "description": "1-year total price return, 1년 종가 기준 총수익률" }},
        {{ "name": "price_total_return_3year", "description": "3-year total price return, 3년 종가 기준 총수익률" }},
        {{ "name": "price_total_return_year_to_date", "description": "Year-to-date total price return, 연초대비 종가 기준 총수익률" }},
        {{ "name": "cumulative_price_total_return", "description": "Cumulative total price return, 누적 종가 기준 총수익률" }}
      ]
    }},
    "etf_close_price_return": {{
      "description": "This table provides closing price-based return information excluding dividends over various periods, 분배금 재투자를 고려하지 않은 기간별 종가 수익률 정보",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "price_return_1day", "description": "1-day price return, 전일(1일) 종가 기준 수익률" }},
        {{ "name": "price_return_1week", "description": "7-day price return, 1주 종가 기준 수익률" }},
        {{ "name": "price_return_1month", "description": "30-day price return, 한달 종가 기준 수익률" }},
        {{ "name": "price_return_3month", "description": "90-day price return, 3달 종가 기준 수익률" }},
        {{ "name": "price_return_6month", "description": "180-day price return, 6달 종가 기준 수익률" }},
        {{ "name": "price_return_1year", "description": "1-year price return, 1년 종가 기준 수익률" }},
        {{ "name": "price_return_3year", "description": "3-year price return, 3년 종가 기준 수익률" }},
        {{ "name": "price_return_year_to_date", "description": "Year-to-date price return, 연초대비 종가 기준 수익률" }},
        {{ "name": "cumulative_price_return", "description": "Cumulative price return, 누적 종가 기준 수익률" }}
      ]
    }},
    "etf_historical_statistics": {{
      "description": "This table contains historical daily ETF statistic informations. 과거부터 현재까지 일자별 ETF 주요 지표 기록",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "recorded_date", "description": "Date when the data was recorded, 해당 데이터가 기록된 일자 정보" }},
        {{ "name": "closing_price", "description": "Closing price on recorded_date, recorded_date에 기록된 종가 정보" }},
        {{ "name": "net_asset_value", "description": "Net asset value (NAV) on recorded_date, recorded_date에 기록된 순자산금액(NAV) 정보" }},
        {{ "name": "total_trade_volume", "description": "Total Trade Volume on recorded_date, recorded_date에 기록된 총 거래량 정보" }},
        {{ "name": "total_trade_value", "description": "Total Trade Value on recorded_date, recorded_date에 기록된 총 거래대금 정보" }},
        {{ "name": "issued_shares", "description": "Total issued shares on recorded_date, recorded_date에 기록된 발행주식총수(총발행주식) 정보" }},
        {{ "name": "asset_under_management", "description": "Total Assets Under Management (AUM) on recorded_date, recorded_date에 기록된 총 운용자산(AUM) 정보" }},
        {{ "name": "market_capitalization", "description": "Market capitalization on recorded_date, recorded_date에 기록된 시가총액 정보" }},
        {{ "name": "beta", "description": "Beta (베타) on recorded_date, recorded_date에 기록된 시장 대비 변동성을 나타내는 지표" }},
        {{ "name": "alpha", "description": "Alpha (알파) on recorded_date, recorded_date에 기록된 시장 벤치마크 대비 초과 수익을 나타내는 지표" }},
        {{ "name": "disparate_ratio", "description": "Disparate ratio (괴리율) on recorded_date, recorded_date에 기록된 프리미엄 또는 디스카운트 비율" }},
      ]
    }},
    "etf_historical_investor_value": {{
      "description": "This table shows historical investor (individual, institution, foreign) trading information for ETFs. 과거부터 현재까지의 일자별 기관/외국인/개인 투자자 거래 정보, 누적된 순유입자금 정보",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "recorded_date", "description": "Date when the data was recorded (데이터 기록 날짜). 해당 데이터가 기록된 일자" }},
        {{ "name": "institution_trade_amount", "description": "Institution trading amount on recorded_date, recorded_date에 기록된 기관 거래 금액/기관 순매수 대금" }},
        {{ "name": "institution_trade_quantity", "description": "Institution trading volume on recorded_date, recorded_date에 기록된 기관 거래량" }},
        {{ "name": "foreign_trade_amount", "description": "Foreign investor trading amount on recorded_date, recorded_date에 기록된 외국인 투자자 거래 금액, 외국인 순매수 대금" }},
        {{ "name": "foreign_trade_quantity", "description": "Foreign investor trading volume on recorded_date, recorded_date에 기록된 외국인 투자자 거래량" }},
        {{ "name": "individual_trade_amount", "description": "Individual investor trading amount on recorded_date, recorded_date에 기록된 개인 투자자 거래 금액, 개인 순매수 대금" }},
        {{ "name": "individual_trade_quantity", "description": "Individual investor trading volume on recorded_date, recorded_date에 기록된 개인 투자자 거래량" }}
      ]
    }},
    "etf_historical_constituent_holdings": {{
      "description": "This table contains the historical stocks held by ETFs (Portfolio Deposit File, PDF). 과거부터 현재까지의 일자별 ETF 구성종목 (구성정보), 섹터, 포함하는 주식 정보",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "recorded_date", "description": "Date when the data was recorded (데이터 기록 날짜). 해당 데이터가 기록된 일자" }},
        {{ "name": "rank_idx", "description": "Weight rank or constituent rank (구성 비중 순위) on recorded_date. recorded_date에 기록된 구성 종목 순위 및 구성 비중 순위" }},
        {{ "name": "holding_name", "description": "Constituent stock name (구성 종목 이름) on recorded_date. recorded_date에 기록된 구성 종목의 주식 이름" }},
        {{ "name": "holding_weight", "description": "Constituent weight (구성 종목 비중) on recorded_date. recorded_date에 기록된 구성 종목의 구성 비중" }},
        {{ "name": "holding_shares", "description": "Number of shares held (보유 주식 수) on recorded_date. recorded_date에 기록된 구성 종목의 주식 개수" }},
        {{ "name": "holding_sector", "description": "Sector of constituent stock (구성 종목 섹터) on recorded_date. recorded_date에 기록된 구성 종목의 주식 섹터 종류." }},
        {{ "name": "total_holding_count", "description": "The number of constituent items (해당 ETF의 구성 종목 수) in the ETF on recorded_date. recorded_date에 기록된 해당 ETF의 구성 종목 수" }}
      ]
    }},
    "etf_historical_dividend": {{
      "description": "This table contains historical dividend informations and records on dividend payout dates.",
      "columns": [
        {{ "name": "etf_name", "description": "ETF name, ETF 이름, (e.g., ACE 200TR, TIGER 미국S&P500)" }},
        {{ "name": "etf_ticker", "description": "ETF ticker, ETF stock code, ETF 티커, sequences of 6-digit numbers" }},
        {{ "name": "payment_date", "description": "Actual dividend payment date, 지급일" }},
        {{ "name": "dividend_date", "description": "Date when the dividend decision was made, 분배금 지급결정일, 배당 결정 일자" }},
        {{ "name": "dividend_amount", "description": "Dividend amount, 분배금, 배당금, dividend_date에 결정된 분배금" }},
        {{ "name": "dividend_ratio", "description": "Dividend yield ratio, 분배율, 배당율, dividend_date에 결정된 분배율" }}
      ]
    }}
  }}
}}   
"""
