import os
from langchain_core.language_models import BaseLanguageModel
from langchain_core.runnables import RunnableSerializable
from langfuse import Langfuse

from langchain.schema import StrOutputParser
from langchain_core.prompts.chat import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)
from utils.langfuse.langfuse_prompt_save import create_prompt

USE_LANGFUSE_PROMPT_MANAGER_YN = os.environ.get("USE_LANGFUSE_PROMPT_MANAGER_YN", "N")

# Prompt
name = "topic_classification_agent"
#Classify the given input into one of the following <topics>.
system_prompt = """You are an AI model designed for classification of a <topics> based on the user's question."
Your goal is to classify the user's question into one of the given <topics> categories and return it.
If the given question does not fall under any <topics>, return "그외"
Always return a single word from the <topics> list.
"""

instruction_prompt = """
<Task>
Classify the given input into one of the following <topics>, using the provided <descriptions> of each <topics> as a reference.

<descriptions> = {{
괴리율: 괴리율, 유동성 공급, 기초지수와의 괴리에 관해서 묻는 질문,
세금: 특정 ETF의 세율, 내야하는 세금의 종류 등을 묻는 질문,
금리: 금리형 ETF의 금리(interest rate)에 따른 이자 지급과 관련된 질문,
유사ETF검색: 특정 ETF 이름을 제시하고, 이와 유사한 ETF를 찾는 질문(이 질문에는 대체로 비슷한, 유사한 이라는 말이 들어감),
ETF테마선택: ETF가 투자하는 관련 기초자산 또는 테마(나스닥, 일본 AI, 반도체 등)를 제시하고, 이에 해당하는 ETF를 찾거나 비교하는 질문,
ETF정보조회: 수익율, AUM, 가격, 분배금 등 조건을 주고, 해당하는 ETF를 찾거나 이를 비교하는 질문,
ETF명칭: 특정 ETF의 상품 명만 주어지는 경우,
특정ETF비교: 복수의 특정 ETF를 제시하고, 특정 수치(AUM, 수익율, etc)를 비교하는 질문(반드시 특정 ETF명이 포함되야 함),
커버드콜: 커버드콜 관련 ETF 질문일 경우,
그외: 위에 주어진 케이스를 제외한 모든 경우(수익율 등)
}}

<topics> = [괴리율, 세금, 금리, 유사ETF검색, ETF테마선택, ETF정보조회, ETF명칭, 특정ETF비교, 커버드콜, 그외]

<Example>
example_question: ACE 200 ETF의 괴리율은 왜 이렇게 커?
output: 괴리율

example_question: ACE AI반도체랑 비슷한 ETF 뭐가 있을까
output: 유사ETF검색

example_question: 일본반도체 ETF 3종 알려줘
output: ETF테마선택

example_question: AI 산업 전반에 투자할 수 있고 중소형주 위주로 담고 있는 ETF를 수익률순으로 알려줘.
output: ETF테마선택

example_question: 미국달러 ETF에 대해 알려줘
output: ETF테마선택

example_question: 제약, 바이오 관련 ETF 중에서 최근 3개월 누적 개인순매수 대금이 높은 Top10 ETF를 알려줘
output: ETF테마선택

example_question: S&P 500을 추종하는 최고의 ETF는 어떤 것이 있나요?
output: ETF테마선택

example_question: 베트남이랑 관련된 ETF 중 거래량이 가장 많은 ETF를 알려줘
output: ETF테마선택

example_question: ACE 중국본토CSI300와 TIGER 중국소비테마 중 AUM이 높은 ETF는 뭐야?
output: 특정ETF비교

example_question: ACE 빅테크TOP7과 TIGER미국테크TOP10의 구성종목과 비중이 어떻게 차이나는지 알려줘
output: 특정ETF비교

example_question: ACE 26-06 회사채(AA-이상)액티브 ETF는 언제 상장했어?
output: ETF정보조회

example_question: 도쿄 일렉트론을 담고 있는 ETF를 비중 높은 순으로 알려줘
output: ETF정보조회

example_question: 반도체 섹터에 집중 투자하는 ETF 중에서 가장 낮은 베타 값을 가지면서도 가장 높은 1년 수익률을 나타낸 ETF는 어떤 것인가요?
output: ETF정보조회

example_question: ETF는 어떤 세금을 내야해?
output: 그외

Important:
Only return one word that is in <topic>. The return must always be a single word."

Input: {input}
"""

def create_topic_classification_agent(
        llm: BaseLanguageModel,
        *,
        system_prompt=system_prompt,
) -> RunnableSerializable[dict, str]:
    langfuse = Langfuse()

    if USE_LANGFUSE_PROMPT_MANAGER_YN == "Y":
        try:
            template = langfuse.get_prompt(name).prompt
        except Exception as e:
            template = instruction_prompt

            create_prompt(
                name,
                template,
                config={
                    "name": name,
                    "instruction_prompt": instruction_prompt,
                    "system_prompt": system_prompt,
                }
            )
    else:
        template = instruction_prompt

    prompt = ChatPromptTemplate.from_messages(
        [SystemMessagePromptTemplate.from_template(system_prompt), HumanMessagePromptTemplate.from_template(template)]
    )
    agent = prompt | llm | StrOutputParser()
    agent.name = name

    return agent
