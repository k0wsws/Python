from langchain_core.runnables import RunnableSerializable
from langchain_core.runnables import RunnableLambda, RunnableBranch
from agents.intension_agent import create_intention_agent
from utils.llm_setting.llm_factory import LLMManager
from agents.etf_name_select_agent import create_etf_name_select_agent
from langchain.agents.agent import AgentExecutor, RunnableAgent
from langchain_core.runnables import RunnablePassthrough, RunnableLambda, chain
from datetime import datetime
from dateutil.relativedelta import relativedelta
import chainlit as cl
from asyncio import run, get_event_loop
# from utils.visual.get_etf_preset import get_etf_preset, get_etf_portfolio_preset, get_etf_dividend_series_preset, get_etf_close_price_with_nav_total_preset, get_etf_historical_portfolio_preset, get_changed_portfolio_presets, get_similar_portfolio_presets
from utils.visual.get_etf_preset import get_etf_preset, get_etf_portfolio_preset, get_etf_dividend_series_preset, get_etf_close_price_with_nav_total_preset, get_changed_portfolio_presets
from utils.visual.get_similar_portfolio_preset import get_etf_historical_portfolio_preset, get_similar_portfolio_presets
from tools.retrieve_etf_name_tool import retrieve_etf_name_tool
from utils.data_structure.treap import Treap
import re
from typing import Optional, List
import requests
from utils.visual.get_etf_preset import get_etf_preset
from . import ETFComparisonTable

# NOTE: To. Mainteners
#       For routing through propmt_etf_sel. cl.user_session is used. Keyword is "macro_history".
#       It is used to track the previous action and determine next action. 
#       It will be usful tracking with it during debugging.

# Disable warning for SSL
requests.packages.urllib3.disable_warnings()

# Define Constants
ETF_BASIC_LIST_LV1 = ["cls_1_stock", "cls_1_bond"]
ETF_BASIC_LIST_LV2 = ["cls_1_reits", "cls_1_commodity", "cls_2_local_stock", "cls_2_global_stock",
                      "cls_2_local_bond", "cls_2_global_bond", "cls_1_hybrid"]
ETF_BASIC_LIST_UPPER = ["cls_2_upper"]
ETF_BASIC_LIST_TOT = ETF_BASIC_LIST_LV1 + ETF_BASIC_LIST_LV2 + ETF_BASIC_LIST_UPPER
COMPARE_TABLE = ETFComparisonTable()


# ============================================== COMMON ================================================ #
# Route to the next action
async def prompt_etf_sel(tag: cl.Action) -> None:
    # locally used
    history: list[str] = cl.user_session.get("macro_history")
    if history is not None and not isinstance(history, list):
        history = [history]

    # If is is normal action
    if (tag.value not in history) and not (tag.value.endswith("_upper")):
        history.append(tag.value)
    # If is to go to previous step
    elif tag.value.endswith("_upper"):
        history.pop()

    value: Optional[str] = history[-1]
    status: Optional[str] = history[0]

    # If it is the end of the conversation
    if tag.value.isdigit() and (status not in ["ETF_SIMILAR_PRODUCT", "ETF_COMPONENTS_TRENDS_PDF", "ETF_SIMILAR_PRODUCT_COMPONETS_PDF"]):
        status = f"{status}_END"
        history.append(status)
    # If it is the end of the conversation for ETF_SIMILAR_PRODUCT
    elif len(history[-1].split("|")) == 2:
        match status:
            case "ETF_SIMILAR_PRODUCT":
                status = "ETF_SIMILAR_PRODUCT_END"
                history.append(status)
            case "ETF_SIMILAR_PRODUCT_COMPONETS_PDF":
                status = "ETF_SIMILAR_PRODUCT_COMPONETS_PDF_END"
                history.append(status)
    # If it is the end of the conversation for ETF_COMPONENTS_TRENDS_PDF
    elif re.match(r"\d{4}-\d{2}-\d{2}", tag.value):
        status = "ETF_COMPONENTS_TRENDS_PDF_END"
        history.append(status)

    cl.user_session.set("macro_history", history)
    match status:
        case "ETF_BASIC" | "ETF_COMPONENTS_PDF" | "ETF_RETURN_RATE" | "ETF_DISTRIBUTION_DETAIL" | "ETF_SIMILAR_PRODUCT" | "ETF_COMPONENTS_TRENDS_PDF" | "ETF_COMPONENTS_CHANGES_PDF" | "ETF_SIMILAR_PRODUCT_COMPONETS_PDF":
            if value in ETF_BASIC_LIST_LV2:
                await step_2(tag)
            # All action that goes to previous step
            elif (value in ETF_BASIC_LIST_UPPER) or len(history) == 1 or \
                    (value in [e if e.startswith("cls_1") else None for e in ETF_BASIC_LIST_LV2]):
                await step_1(None, None)
            # A action needs to go 3rd step, to compare with other ETF 
            # Only for ETF_SIMILAR_PRODUCT
            elif status in ["ETF_SIMILAR_PRODUCT", "ETF_SIMILAR_PRODUCT_COMPONETS_PDF"] and value.isdigit():
                await cl.Message(content=tag.label, type="user_message").send()
                await step_3(tag, value)
            elif status == "ETF_COMPONENTS_TRENDS_PDF" and value.isdigit():
                await cl.Message(content=tag.label, type="user_message").send()
                await step_3(tag, value)
            # To ditermine whether it is stock or bond, when action was go to previous step
            elif value in ETF_BASIC_LIST_LV1 + ETF_BASIC_LIST_UPPER:
                if re.search("bond", value):
                    tag.value = "cls_1_bond"
                elif re.search("stock", value):
                    tag.value = "cls_1_stock"
                else:
                    raise Exception("Unreachable")
                await step_2(tag)

        case "ETF_DEFINITION" | "ETF_TOP5_ASSET" | "ETF_REASON_DISPARATE_RATIO":
            # Unable to reach here, these are one step only. Just defined it for clarity.
            pass

        case _:
            # Case if it is the end of the conversation, redirect to here
            if status.endswith("END"):
                # Send the lsat chosen action
                content = tag.label
                last_action = cl.Message(content=content, type="user_message")
                await last_action.send()
            else:
                raise Exception("Unreachable")

    # Remove action button from UI after processing action button
    await tag.remove()

    return None


# Recommend next question
async def next_recommendation() -> None:
    try:
        macro_hist = cl.user_session.get("macro_history")
        if len(macro_hist) > 0:
            tag: str = macro_hist[-1]
            if tag == "ETF_COMPONENTS_TRENDS_PDF_END":
                date = macro_hist[-2]
        else:
            return None
    except TypeError | IndexError:
        return None
    
    if tag.endswith("END"):
        # Send the lsat chosen action
        content = "이 ETF 조금 더 알아보기\n <span id='new-etf' style='font-size:14px;'>(새로운 ETF 상품 조회를 원할 경우 대화 창에 'ACE'를 입력하세요.)</span>"
        # Empty the session history
        cl.user_session.set("macro_history", [])
        macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
        extracted_etf_ticker: list = cl.user_session.get("extracted_etf_ticker")

        match tag:
            case "ETF_BASIC_END":
                await get_etf_preset()

                # etf_sel = cl.Message( content=content, actions=[
                #     cl.Action( name="macro", value="pdf", label="ETF의 수익률 정보 알려줘"),
                #     cl.Action( name="macro", value="div", label="ETF 분배금 지급내역 보여줘"),
                #     ])
                etf_sel = cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="pdf", label="ETF 구성종목 보여줘"),
                    cl.Action(name="macro", value="pdf", label="ETF의 수익률 정보 알려줘"),
                    cl.Action(name="macro", value="pdf", label="ETF 분배금 지급내역 보여줘"),
                    cl.Action(name="macro", value="pdf", label="ETF와 유사한 상품 찾아줘"),
                ])
            case "ETF_COMPONENTS_PDF_END":
                if macro_history_ticker is None and extracted_etf_ticker is not None:
                    await get_etf_portfolio_preset()

                etf_sel =  cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="pdf", label="ETF 구성종목 변동사항 알려줘"),
                    cl.Action( name="macro", value="pdf", label="ETF의 수익률 정보 알려줘"),
                    cl.Action( name="macro", value="pdf", label="ETF 분배금 지급내역 보여줘"),
                    cl.Action( name="macro", value="pdf", label="ETF와 유사한 상품 찾아줘"),
                    cl.Action( name="macro", value="pdf", label="ETF와 유사한 상품의 구성종목 비교해줘"),
                    ## "." 문자 구분 - etf_selected_basic_info(선택된 ETF 조회) 호출
                    cl.Action( name="macro", value="div", label="ETF 기본 정보 알려줘"),
                ])
            case "ETF_DISTRIBUTION_DETAIL_END":
                if macro_history_ticker is None and extracted_etf_ticker is not None:
                    await get_etf_dividend_series_preset()

                etf_sel =  cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="pdf", label="ETF와 유사한 상품 찾아줘"),
                    cl.Action( name="macro", value="pdf", label="ETF 구성종목 보여줘"),
                    cl.Action( name="macro", value="pdf", label="ETF의 수익률 정보 알려줘"),
                    ## "." 문자 구분 - etf_selected_basic_info(선택된 ETF 조회) 호출
                    cl.Action( name="macro", value="div", label="ETF 기본 정보 알려줘"),
                ])
            case "ETF_RETURN_RATE_END":
                if macro_history_ticker is None and extracted_etf_ticker is not None:
                    await get_etf_close_price_with_nav_total_preset()

                etf_sel =  cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="pdf", label="ETF 분배금 지급내역 보여줘"),
                    cl.Action( name="macro", value="pdf", label="ETF와 유사한 상품 찾아줘"),
                    cl.Action( name="macro", value="pdf", label="ETF 구성종목 보여줘"),
                    ## "." 문자 구분 - etf_selected_basic_info(선택된 ETF 조회) 호출
                    cl.Action( name="macro", value="div", label="ETF 기본 정보 알려줘"),
                ])
            case "ETF_SIMILAR_PRODUCT_END":
                if (macro_history_ticker is not None and len(macro_history_ticker) > 1) \
                        or (extracted_etf_ticker is not None and len(extracted_etf_ticker) > 1):
                    await get_etf_preset()

                # TODO: Temporal items, It could be changed
                etf_sel =  cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="pdf", label="ETF 구성종목 보여줘"),
                    cl.Action( name="macro", value="pdf", label="ETF 분배금 지급내역 보여줘"),
                    cl.Action( name="macro", value="pdf", label="ETF와 유사한 상품 찾아줘"),
                    cl.Action(name="macro", value="pdf", label="ETF와 유사한 상품의 구성종목 비교해줘"),
                    ## "." 문자 구분 - etf_selected_basic_info(선택된 ETF 조회) 호출
                    cl.Action( name="macro", value="div", label="ETF 기본 정보 알려줘"),
                ])
            case "ETF_COMPONENTS_TRENDS_PDF_END":
                if((macro_history_ticker is not None and len(macro_history_ticker) > 0) \
                    or (extracted_etf_ticker is not None and len(extracted_etf_ticker) > 0)) \
                    and re.match(r"\d{4}-\d{2}-\d{2}", date):
                    # TODO: Temporal output, It will be changed after frontend is ready
                    await get_etf_historical_portfolio_preset(date)

                etf_sel = cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="pdf", label="ETF 분배금 지급내역 보여줘"),
                    cl.Action( name="macro", value="pdf", label="ETF와 유사한 상품 찾아줘"),
                    cl.Action( name="macro", value="pdf", label="ETF의 수익률 정보 알려줘"),
                    ## "." 문자 구분 - etf_selected_basic_info(선택된 ETF 조회) 호출
                    cl.Action( name="macro", value="div", label="ETF 기본 정보 알려줘"),
                ])
            case "ETF_COMPONENTS_CHANGES_PDF_END":
                if macro_history_ticker is None and extracted_etf_ticker is not None:
                    await get_changed_portfolio_presets()

                etf_sel =  cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="pdf", label="ETF와 유사한 상품 찾아줘"),
                    cl.Action( name="macro", value="pdf", label="ETF 구성종목 보여줘"),
                    cl.Action( name="macro", value="pdf", label="ETF의 수익률 정보 알려줘"),
                    ## "." 문자 구분 - etf_selected_basic_info(선택된 ETF 조회) 호출
                    cl.Action( name="macro", value="div", label="ETF 기본 정보 알려줘"),
                ])
            case "ETF_SIMILAR_PRODUCT_COMPONETS_PDF_END":
                if (macro_history_ticker is not None and len(macro_history_ticker) > 1) \
                        or (extracted_etf_ticker is not None and len(extracted_etf_ticker) > 1):
                    # TODO: Implement the function
                    await get_similar_portfolio_presets()

                etf_sel = cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="pdf", label="ETF 분배금 지급내역 보여줘"),
                    cl.Action( name="macro", value="pdf", label="ETF 구성종목 변동사항 알려줘"),
                    cl.Action( name="macro", value="pdf", label="ETF의 수익률 정보 알려줘"),
                    ## "." 문자 구분 - etf_selected_basic_info(선택된 ETF 조회) 호출
                    cl.Action( name="macro", value="div", label="ETF 기본 정보 알려줘"),
                ])
                pass
            case "ETF_DEFINITION_END" | "ETF_REASON_DISPARATE_RATIO_END" | "ETF_TOP5_ASSET_END":
                etf_sel =  cl.Message(content=content, actions=[
                    cl.Action( name="macro", value="div", label="ETF 기본 정보 알려줘"),
                    cl.Action( name="macro", value="pdf", label="ETF 구성종목 보여줘"),
                ])
            case _:
                raise Exception("Unreachable")

        cl.user_session.set("etf_sel", etf_sel)
        await etf_sel.send()
    else:
        pass

    return None


# ============================================== ETF BASIC ================================================ #
# Routine for ETF basic information Step 1
async def step_1(q, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")

    if len(history) > 1:
        history = history[0]

    cl.user_session.set("macro_history", history)

    etf_sel = cl.Message(
        content="어떤 ETF에 대해 궁금하신가요? 자산 유형을 알려주세요.",
        actions=[
            cl.Action(name="etf_sel", value="cls_1_stock", label="주식"),
            cl.Action(name="etf_sel", value="cls_1_bond", label="채권"),
            cl.Action(name="etf_sel", value="cls_1_hybrid", label="혼합"),
            cl.Action(name="etf_sel", value="cls_1_reits", label="리츠"),
            cl.Action(name="etf_sel", value="cls_1_commodity", label="원자재"),
        ],
    )
    cl.user_session.set("etf_sel", etf_sel)
    await etf_sel.send()

    return None


# Routine for ETF basic information Step 2
async def step_2(tag: cl.Action) -> None:
    history: list[str] = cl.user_session.get("macro_history")

    etf_sel = cl.user_session.get("etf_sel")
    content = ""
    actions = []

    # Remove previous message
    await etf_sel.remove()

    if tag.value in ETF_BASIC_LIST_TOT:
        content = "어떤 ETF에 대해 궁금하신가요? 조회 지역을 알려주세요."
        if tag.value == "cls_1_stock":
            actions = [
                cl.Action(name="etf_sel_reset", value="cls_2_upper", label=".."),
                cl.Action(name="etf_sel", value="cls_2_local_stock", label="국내"),
                cl.Action(name="etf_sel", value="cls_2_global_stock", label="해외"),
            ]
        elif tag.value == "cls_1_bond":
            actions = [
                cl.Action(name="etf_sel_reset", value="cls_2_upper", label=".."),
                cl.Action(name="etf_sel", value="cls_2_local_bond", label="국내"),
                cl.Action(name="etf_sel", value="cls_2_global_bond", label="해외"),
            ]
        else:
            funds = []
            params = {}
            content = "어떤 ETF에 대해 궁금하신가요? ETF명을 알려주세요."
            if tag.value == "cls_1_hybrid":
                params = {'isAceEtfPlus': False, 'themeType': '혼합형', 'page': 1, 'size': 99}
            elif tag.value == "cls_1_reits":
                params = {'isAceEtfPlus': False, 'fundType': '리츠', 'page': 1, 'size': 99}
            elif tag.value == "cls_1_commodity":
                params = {'isAceEtfPlus': False, 'fundType': '원자재', 'page': 1, 'size': 99}
            elif tag.value == "cls_2_local_stock":
                params = {'isAceEtfPlus': False, 'fundType': '주식', 'fundAreaCode': '01', 'page': 1, 'size': 99}
            elif tag.value == "cls_2_global_stock":
                params = {'isAceEtfPlus': False, 'fundType': '주식', 'fundAreaCode': ['02', '03', '04', '05', '06', '07', '08', '09', '10',
                                                                                    '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
                                                                                    '21', '22', '23', '24', '25', '26', '27', '28'], 'page': 1, 'size': 99}  # from 02 ~ 28
            elif tag.value == "cls_2_local_bond":
                params = {'isAceEtfPlus': False, 'fundType': '채권', 'fundAreaCode': '01', 'page': 1, 'size': 99}
            elif tag.value == "cls_2_global_bond":
                # params={'isAceEtfPlus':False, 'fundType':'채권', 'fundAreaCode': ['10', '22'], 'page':1, 'size':99}  # from 02 ~ 28
                params = {'isAceEtfPlus': False, 'fundType': '채권', 'fundAreaCode': ['02', '03', '04', '05', '06', '07', '08', '09', '10',
                                                                                    '11', '12', '13', '14', '15', '16', '17', '18', '19', '20',
                                                                                    '21', '22', '23', '24', '25', '26', '27', '28'], 'page': 1, 'size': 99}  # from 02 ~ 28

            funds = requests.get("https://papi.aceetf.co.kr/api/funds", params=params, verify=False).json()
            funds = [{'label': f['fundNm'], 'value': f['badge']['stockCode']} for f in funds['data']]
            # ETF_SIMILAR_PRODUCT is has one more step
            if history[0] == "ETF_SIMILAR_PRODUCT":
                # Delete if it is not comparable
                funds = [f for f in funds if len(COMPARE_TABLE.get_comparison(f['value'])) > 0]

            if len(funds) == 0:
                content = "해당하는 ETF가 없습니다."
                actions = [cl.Action(name="etf_sel_reset", value="cls_2_upper", label="..")]

            else:
                actions = [
                    cl.Action(name="etf_sel_reset", value=f"{tag.value}.cls_3_upper", label=".."),
                    *[cl.Action(name="etf_sel", **kwargs) for kwargs in funds]
                ]

        etf_sel = cl.Message(content=content, actions=actions)
        cl.user_session.set("etf_sel", etf_sel)
        await etf_sel.send()
    else:
        await cl.Message(content=content).send()

    return None


async def step_3(tag: cl.Action, target: str) -> None:
    last_history: list[str] = cl.user_session.get("macro_history")[0]
    match last_history:
        case "ETF_SIMILAR_PRODUCT" | "ETF_SIMILAR_PRODUCT_COMPONETS_PDF":
            content = "다음은 해당 ETF와 비슷한 성격의 ETF들 입니다 :"
            comp_list = COMPARE_TABLE.get_comparison(target)

            if len(comp_list) == 0:
                content = "비교할 ETF가 없습니다."
                await cl.Message(content=content).send()
                history: list[str] = cl.user_session.get("macro_history")
                status = "ETF_SIMILAR_PRODUCT_END"
                history.append(status)
                cl.user_session.set("macro_history", history)
                return await next_recommendation()
            else:
                history = cl.user_session.get("macro_history")
                cl.user_session.set("macro_history", history)
                funds = [{'label': d['comp_name'], 'value': f"{tag.value}|{d['comp_ticker']}"} for d in comp_list]
                actions = [
                    *[cl.Action(name="etf_sel", **kwargs) for kwargs in funds]
                ]
        case "ETF_COMPONENTS_TRENDS_PDF":
            history = cl.user_session.get("macro_history")
            cl.user_session.set("macro_history", history)
            cl.user_session.set("macro_history_ticker", [target])
            content = "기간을 선택해주세요."
            current = datetime.now()
            actions = [
                cl.Action(name="etf_sel", value=(current - relativedelta(days=2)).strftime("%Y-%m-%d"), label="최근"),
                cl.Action(name="etf_sel", value=(current - relativedelta(months=1)).strftime("%Y-%m-%d"), label="1개월"),
                cl.Action(name="etf_sel", value=(current - relativedelta(months=3)).strftime("%Y-%m-%d"), label="3개월"),
                cl.Action(name="etf_sel", value=(current - relativedelta(months=6)).strftime("%Y-%m-%d"), label="6개월"),
                cl.Action(name="etf_sel", value=(current - relativedelta(years=1)).strftime("%Y-%m-%d"), label="1년"),
                cl.Action(name="etf_sel", value=datetime(datetime.now().year, 1, 1).strftime("%Y-%m-%d"), label="연초대비"),
            ]
        case _:
            raise Exception("Unreachable in step_3")

    etf_sel = cl.Message(content=content, actions=actions)
    cl.user_session.set("etf_sel", etf_sel)

    await etf_sel.send()

    return None


# Which do not use action button and just display the answer as plain text
async def zero_step(q: str, tag: str) -> None:
    # Set Runnable which is not a macro
    runnable = cl.user_session.get("runnable")
    topic_classifier = cl.user_session.get("topic_classifier")
    topic = topic_classifier.invoke({"input": q})

    # Call the runnable
    response = await runnable.ainvoke({"input": q, "topic": topic}, config={"run_name": "MacroAgent"})
    # Display the answer of the question
    end_msg = cl.Message(content=response, tags=[tag])
    await end_msg.send()
    # Show next recommendation
    await next_recommendation()

    return None


# ============================================== MACRO QUESTIONS ================================================ #
async def etf_basic_info(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    if history is not None and not isinstance(history, list):
        history = []
    history.append("ETF_BASIC")
    cl.user_session.set("macro_history", history)

    return await step_1(q, llm)


async def etf_selected_basic_info(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_BASIC"
    history.append(action_type)
    cl.user_session.set("macro_history", history)

    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    cl.user_session.set("extracted_etf_ticker", macro_history_ticker)
    # 후속 질문에 포함될 경우 실행
    await get_etf_preset()
    history.append(f"{action_type}_END")
    cl.user_session.set("macro_history", history)
    return await next_recommendation()


def etf_selected_basic_info_keyword(q: str) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_BASIC"
    history.append(action_type)
    cl.user_session.set("macro_history", history)

    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    #history_ticker = cl.user_session.set("extracted_etf_ticker", macro_history_ticker)
    # 후속 질문에 포함될 경우 실행
    loop = get_event_loop()
    loop.run_until_complete(get_etf_preset())
    history.append(f"{action_type}_END")
    cl.user_session.set("macro_history", history)
    return loop.run_until_complete(next_recommendation())


async def etf_components_pdf(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_COMPONENTS_PDF"
    history.append(action_type)
    cl.user_session.set("macro_history", history)

    # 후속 질문에 포함될 경우 실행
    await get_etf_portfolio_preset()
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    if macro_history_ticker is not None and len(macro_history_ticker) > 0:
        history.append(f"{action_type}_END")
        cl.user_session.set("macro_history", history)
        await next_recommendation()
        return
    return await step_1(q, llm)


async def etf_components_trends_pdf(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_COMPONENTS_TRENDS_PDF"
    history.append(action_type)
    cl.user_session.set("macro_history", history)

    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    if macro_history_ticker is not None and len(macro_history_ticker) > 0:
        target_ticker: str = macro_history_ticker[0]
        action: cl.Action = cl.Action(name="etf_sel", value=target_ticker, label="", description="", forId="", id="", collapsed=False)
        await step_3(action, target_ticker)
        return
    return await step_1(q, llm)


async def etf_components_recent_changes_pdf(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_COMPONENTS_CHANGES_PDF"
    history.append(action_type)
    cl.user_session.set("macro_history", history)

    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    if macro_history_ticker is not None and len(macro_history_ticker) > 0:
        history.append(f"{action_type}_END")
        cl.user_session.set("macro_history", history)
        await next_recommendation()
        return None
    return await step_1(q, llm)
        

async def etf_return_rate(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_RETURN_RATE"
    history.append(action_type)
    cl.user_session.set("macro_history", history)

    # 후속 질문에 포함될 경우 실행
    await get_etf_close_price_with_nav_total_preset()
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    if macro_history_ticker is not None and len(macro_history_ticker) > 0:
        history.append(f"{action_type}_END")
        cl.user_session.set("macro_history", history)
        await next_recommendation()
        return

    return await step_1(q, llm)


async def etf_distribution_detail(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_DISTRIBUTION_DETAIL"
    history.append(action_type)
    cl.user_session.set("macro_history", history)

    # 후속 질문에 포함될 경우 실행
    await get_etf_dividend_series_preset()
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    if macro_history_ticker is not None and len(macro_history_ticker) > 0:
        history.append(f"{action_type}_END")
        cl.user_session.set("macro_history", history)
        await next_recommendation()
        return

    return await step_1(q, llm)


async def etf_similar_product(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_SIMILAR_PRODUCT"
    history.append(action_type)
    cl.user_session.set("macro_history", history)

    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    _: list = cl.user_session.get("extracted_etf_ticker")
    # 후속 질문에 포함될 경우 실행
    if macro_history_ticker is not None and len(macro_history_ticker) > 0:
        target_ticker = macro_history_ticker[0]
        cl.user_session.set("extracted_etf_ticker", [target_ticker])
        action = cl.Action(name="etf_sel", value=target_ticker, label="", description="", forId="", id="", collapsed=False)
        await step_3(action, target_ticker)
        return
    return await step_1(q, llm)


async def etf_similar_product_components_pdf(q: str, llm) -> None:
    history: list[str] = cl.user_session.get("macro_history")
    action_type = "ETF_SIMILAR_PRODUCT_COMPONETS_PDF"
    history.append(action_type)
    cl.user_session.set("macro_history", history)
    
    macro_history_ticker: list = cl.user_session.get("macro_history_ticker")
    _: list = cl.user_session.get("extracted_etf_ticker")
    if macro_history_ticker is not None and len(macro_history_ticker) > 0:
        target_ticker: str = macro_history_ticker[0]
        action: cl.Action = cl.Action(name="etf_sel", value=target_ticker, label="", description="", forId="", id="", collapsed=False)
        await step_3(action, target_ticker)
        return
    return await step_1(q, llm)


async def etf_definition(q: str, llm) -> None:
    # Because of recursive call, this is needed
    q = q.replace("???", "?")
    history: list[str] = cl.user_session.get("macro_history")
    history.append("ETF_DEFINITION")
    return await zero_step(q)


async def etf_top5_asset(q: str, llm) -> None:
    # Because of recursive call, this is needed
    q = q.replace("???", "?")
    history: list[str] = cl.user_session.get("macro_history")
    history.append("ETF_TOP5_ASSET")
    cl.user_session.set("macro_history", history)
    return await zero_step(q)


async def etf_reason_disparate_ratio(q: str, llm) -> None:
    # Because of recursive call, this is needed
    q = q.replace("???", "?")
    history: list[str] = cl.user_session.get("macro_history")
    history.append("ETF_REASON_DISPARATE_RATIO")
    cl.user_session.set("macro_history", history)
    return await zero_step(q)


# ================================================= MACRO AGENT ================================================= #
# Current macro question list
_macro_q_map = {
    "ETF 기본정보 알려줘": etf_basic_info,
    "ETF 기본 정보 알려줘": etf_selected_basic_info,
    "ETF 구성종목 보여줘": etf_components_pdf,
    "ETF 구성종목 변동사항 알려줘": etf_components_trends_pdf,
    "ETF 구성종목 최신 변동사항 비교해줘": etf_components_recent_changes_pdf,
    "KEYWORD SEARCH WITH TICKER": etf_selected_basic_info_keyword,
    "ETF의 수익률 정보 알려줘": etf_return_rate,
    "ETF 분배금 지급내역 보여줘": etf_distribution_detail,
    "ETF가 뭐야???": etf_definition,
    "ETF와 유사한 상품 찾아줘": etf_similar_product,
    "ETF와 유사한 상품의 구성종목 비교해줘": etf_similar_product_components_pdf,
    "순자산가치가 높은 ETF 5개 알려줘": etf_top5_asset,
    "ETF의 괴리율은 왜 생기는거야?": etf_reason_disparate_ratio,
}


async def create_top_level_agent(mgr: LLMManager, **kwargs) -> RunnableSerializable:
    def _is_macro_question(input: dict):
        q = input.get("input", None)
        t = []
        assert q is not None
        if re.search(r"\[추천 상품 검색\]|(종목코드:\d{6})", str(q)):
            q = "KEYWORD SEARCH WITH TICKER"
            etf_ticker = str(q).split(":")[-1]
            cl.user_session.set("extracted_etf_ticker", [etf_ticker])
        try:
            t.extend(cl.user_session.get("etf_sel").tags)
        except:
            pass
        in_question_list = any([(q == mq) for mq in _macro_q_map.keys()]) | any([(mq in t) for mq in _macro_q_map.keys()])
        return in_question_list
    return RunnableBranch(
        (_is_macro_question, await create_macro_agent(mgr, **kwargs)),
        await create_intention_agent(mgr, **kwargs),
    )


async def create_macro_agent(mgr: LLMManager, **kwargs):
    @chain
    def runnable(input: dict):
        q = input.get("input")
        r = None
        if re.search(r"\[추천 상품 검색\]|(종목코드:\d{6})", str(q)):
            #q = "ETF 기본 정보 알려줘"
            etf_ticker = str(q).split(":")[-1]
            cl.user_session.set("question", q)
            cl.user_session.set("etf_sel", None)
            cl.user_session.set("extracted_etf_ticker", [etf_ticker])
            return RunnableLambda(lambda _: q).with_config(
                {"run_name": "unwrap_input"}) | RunnableLambda(lambda _: etf_selected_basic_info_keyword(q))
        # If this is first question
        try:
            r = _macro_q_map[q]
            print(**kwargs)
            cl.user_session.set("question", q)
            cl.user_session.set("etf_sel", None)

        except KeyError or AttributeError:
            # If this is not first question, mostly second question
            try:
                r = _macro_q_map[cl.user_session.get("etf_sel").tags[1]]
                q = f"{q} {cl.user_session.get('etf_sel').tags[1]}"
            except:
                raise Exception("Unreachable")
            print(**kwargs)

        async def mapfunc(_):
            return await _macro_q_map[q](q, mgr.llm)

        return RunnableLambda(lambda _: q).with_config(
            {"run_name": "unwrap_input"}
        ) | RunnableLambda(  # RunnableLambda(lambda _: _macro_q_map[q](q, mgr.llm))
            lambda _: run(r(q, mgr.llm))
        )

    return runnable.with_config({"run_name": "MacroAgent"})
