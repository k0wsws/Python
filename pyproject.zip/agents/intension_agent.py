from langchain_core.runnables import RunnableSerializable

from tools.retrieve_etf_values_tool import RetrieveETFValuesTool
from tools.calculator_tool import CalculatorTool
from tools.tax_values_tool import RetrieveTaxValuesTool
from utils.llm_setting.llm_factory import LLMManager
from agents.react_agent import create_react_agent
from tools.retrieve_faq_tool import RetrieveFaqTool
from tools.recommend_etf_tool import ThemeSearchTool
from tools.fallback_tool import FallBackTool
from tools.web_search_tool import WebSearchTool
from langchain.chains import LLMMathChain
from datetime import date
from tools.similar_etf_search_tool import SimilarETFSearchTool

# Prompt
name: str = "intention_agent"

today = date.today()
formatted_date = today.strftime("%Y년 %m월 %d일")

# """You are a knowledgeable chatbot who provides kind and concise answers to users' questions. If there is no mention in the question to respond in another language, You will respond in Korean."""
system_prompt: str =f"""You are "ACE AI Contact Center," an intelligent assistant specializing in financial data, particularly domestic Exchange Traded Funds (ETFs). Your role is to understand user inputs, utilize conversation history to provide relevant information, and perform the necessary steps to fulfill user requests.

Your goals are to:
- Identify any financial or ETF-related queries from user input.
- Use the [<previous_conversation_history>] to determine the context and adjust your actions accordingly.
- Determine if the user's request requires one or multiple steps to fulfill.
- If there is relevant history, base the next action on that context.
- Perform each step in sequence, automatically moving to the next step only if necessary.
- If the answer is found at any step, provide the final answer immediately without using further tools.
- Always respond in Korean unless the user specifies a different language.

Always provide accurate, relevant, and contextually appropriate information to the user.
Remember, your name is "ACE AI Contact Center", and you respond primarily in Korean.

Current date: {formatted_date}
"""

instruction_prompt: str = """
### Important Guidelines ###
- First, think carefully and [<PLAN>] which tools you will use step-by-step to answer the user's question. 
- Use the tools according to your [<PLAN>] to gather the necessary information before providing an answer.
- If you cannot find information using a particular tool, try another tool.
- If you're at the 'Action Input' step, the output should be a json object.  
- If it is not specified whether the question is about a specific ETF, you should consider the [<previous_conversation_history>] and answer based on the most recent context, or use a fallback tool to get the necessary information from the user.
- You can only use one 'Final Answer' format, so please gather all the information together using different tools before your final answer.
    - However, if 'Observation' is too long at 'Final Answer', answer by sort out values and summarize necessary information.
- If both 'Action' and 'Action Input' are **None**, use all the information gathered from various tools to create and provide the 'Final Answer'.
- If action input contains hyperlink or web link, final answer keep the link.
"""

async def create_intention_agent(mgr: LLMManager, **kwargs) -> RunnableSerializable:
    llm = mgr.llm
    faq_tool = RetrieveFaqTool(llm=llm)
    retrieve_tax_values_tool = RetrieveTaxValuesTool(llm=llm)
    retrieve_etf_values_tool = RetrieveETFValuesTool(llm=llm)
    theme_search_tool = ThemeSearchTool(llm=llm)
    fallback_tool = FallBackTool(llm=llm)
    web_search_tool = WebSearchTool(llm=llm)
    calculator_tool = CalculatorTool(llm=llm)
    similar_etf_search_tool = SimilarETFSearchTool(llm=llm)

    tools = [
        faq_tool,
        fallback_tool,
        retrieve_tax_values_tool, #세금에 대한 질문을 하면, 별도의 툴이 없어도 plan 설정 시 답변가능
        retrieve_etf_values_tool,
        web_search_tool,
        theme_search_tool,
        calculator_tool,
        similar_etf_search_tool,
    ]

    agent = (await create_react_agent(
        llm,
        tools,
        agent_name=name,
        system_prompt=system_prompt,
        instruction_prompt=instruction_prompt,
        enable_history=True
    ) | (lambda x: x["output"]))
    agent.name = name
    return agent
