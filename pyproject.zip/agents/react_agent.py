import os
import re
from datetime import date

from langchain_core.language_models import BaseLanguageModel
from typing import Any, Dict, Optional, Union
from langchain_core.prompts import BasePromptTemplate
from langchain.agents.agent import AgentExecutor, RunnableAgent
from langchain_core.messages import AIMessage

from langchain.agents.format_scratchpad import format_log_to_str
from langchain.agents.output_parsers import ReActSingleInputOutputParser
from langchain_core.runnables import RunnablePassthrough, chain
import chainlit as cl

from utils.langfuse.langfuse_prompt_save import create_prompt
from langfuse import Langfuse
from langchain_core.prompts.chat import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)

# Prompt
name = "react_agent"

PREFIX = """Answer the following questions as best you can. You have access to the following tools:"""

FORMAT_INSTRUCTIONS = """Use the following format:

Question: the input question you must answer.
Thought: you should always think about what to do. 
Action: the action to take, should be one of [{tool_names}]. please specify the reason you choose the tool.
Action Input: the input to the action.
Observation: the result of the action.
... (the sequence of Thought/Action/Action Input/Observation can be repeated zero or more times)
Thought: I now know the final answer.
Final Answer: the final answer to the original input question."""

# 주원님 작업은 일단 보존해 둔후 테스트 예정
FORMAT_INSTRUCTIONS2 = """Thought: Do I need to use a tool? Yes
- Analyze the user's input to determine if the request requires multiple steps or a single step.
- Review the Previous conversation history to check if any relevant data has already been retrieved.
- If the new request builds on a previous one (e.g., using data already retrieved like a list of ETFs), use that existing data to form the next query.
- If the request involves finding new data, use the appropriate tool to retrieve this data first.

Action 1: [Choose the first action based on user input and conversation history: {tool_names}]
Action Input 1: [Input for the first action, based on the user's request and relevant history]
Observation 1: [Result from the first tool]

Thought: Is the user's request fully answered with this information? No
- If No, determine the next step based on the user's original request and the retrieved data.
- If the user's request involves further processing (e.g., sorting or filtering the previous data by a new criterion like volatility), perform this next step using the appropriate tool.

Action 2: [Choose the next action if needed, based on the previous observation and user's request]
Action Input 2: [Input for the next action, using data from the previous step, such as filtering or sorting by volatility]
Observation 2: [Result from the second tool]

Repeat the process if more steps are needed.

If no further action is needed or if the answer is found:

Thought: Do I need to use a tool? No
Final Answer: [Your response here in Korean, based on all observations and the user's request]"""

SUFFIX = """
Begin!
Current date: {formatted_date}
[<previous_conversation_history>]: {history}
Question: {input}
{tip}
Thought: {scratchpad}{agent_scratchpad}"""

# Thought: {plan_scratchpad} {agent_scratchpad}"""

TOOL_DESC = """{name}: Call this tool to interact with the {name_for_human} API. What is the {name_for_human} API useful for? {description} Parameters: {parameters} Format the arguments as a JavaScript Object Notation object."""
FB_TOOL_DESC = """{name}: Call this tool in case of {name_for_human}. This tool {description} Parameters: {parameters} Format the arguments as a JavaScript Object Notation object."""

USE_LANGFUSE_PROMPT_MANAGER_YN = os.environ.get("USE_LANGFUSE_PROMPT_MANAGER_YN", "N")


async def create_react_agent(
        llm: BaseLanguageModel,
        tools=None,
        *,
        max_iterations: Optional[int] = 7,
        max_execution_time: Optional[float] = None,
        early_stopping_method: str = "force",
        agent_executor_kwargs: Optional[Dict[str, Any]] = None,
        instruction_prompt: Optional[Union[BasePromptTemplate, str]] = None,
        agent_name=name,
        system_prompt="You are a very knowledgeable chatbot who can answer almost any user's question.",
        enable_history=False
) -> AgentExecutor:
    if tools is None:
        tools = []

    langfuse = Langfuse()
    if USE_LANGFUSE_PROMPT_MANAGER_YN == "Y":
        try:
            template = langfuse.get_prompt(name).prompt
        except Exception as e:
            template = "\n\n".join(
                [
                    PREFIX,
                    "{tool_descs}",
                    FORMAT_INSTRUCTIONS,
                    instruction_prompt,
                    SUFFIX,
                ]
            )
            create_prompt(name, template,
                          config={
                              "react_prompt.PREFIX": PREFIX,
                              "react_prompt.FORMAT_INSTRUCTIONS": FORMAT_INSTRUCTIONS,
                              "instruction_prompt": instruction_prompt,
                              "react_prompt.SUFFIX": SUFFIX
                          })
    else:
        template = "\n\n".join(
            [
                PREFIX,
                "{tool_descs}",
                FORMAT_INSTRUCTIONS,
                instruction_prompt,
                SUFFIX,
            ]
        )

    system_message_prompt = SystemMessagePromptTemplate.from_template(system_prompt)
    human_message_prompt = HumanMessagePromptTemplate.from_template(template)

    prompt = ChatPromptTemplate.from_messages(
        [system_message_prompt, human_message_prompt]
    )

    missing_vars = {"tool_descs", "tool_names", "agent_scratchpad"}.difference(
        prompt.input_variables
    )

    if missing_vars:
        raise ValueError(f"Prompt missing required variables: {missing_vars}")

    prompt_repeat = prompt.partial(
        tool_descs=await qwen_render_text_description(tools, rewrite = False),
        tool_names=", ".join([t.name for t in tools]),
    )
    prompt_rewrite = prompt.partial(
        tool_descs=await qwen_render_text_description(tools, rewrite = True),
        tool_names=", ".join([t.name for t in tools]),
    )

    async def _load_chat_history(s):
        if not enable_history:
            return ""
        else:
            chat_hist = cl.user_session.get('memory').load_memory_variables(inputs='')['history']
            chat_hist = ",".join(
                [f"""{{{"'assistant': " if isinstance(ch, AIMessage) else "'user': "}'{ch.content}'}}"""
                 for ch in chat_hist[-4:]])
            return f"[{chat_hist}]"

    def route(topic, question):
        topic = topic.replace("\'", "").replace("\"", "").replace("output:", "").strip()
        
        tip_dict = { #"괴리율": "[<tips>]: 사용자가 괴리율에 대해 문의하는 질문입니다. 'retrieve_etf_values_tool'을 사용하면 주어진 상품의 'disparate_ratio'를 구할 수 있습니다.",
            "괴리율": "[<tips>]: 사용자가 괴리율에 대해 문의하는 질문입니다. 'retrieve_faq_tool'을 사용해 답변하고, 적절한 답을 찾지 못하면 'retrieve_etf_values_tool'을 사용해 주어진 상품의 'disparate_ratio'를 구해 답변하세요.",
            "세금": "[<tips>]: 특정 ETF를 제시하고 관련된 세금정보를 묻거나, 세금과 관련된 일반적인 질문입니다. 특정 ETF에 대한 세금 정보는 'tax_values_tool'를 통해 찾을 수 있습니다. **단, 'tax_values_tool'로 해당하는 정보를 찾지 못한 경우 'retrieve_faq_tool'를 사용해야 합니다.**",
            "금리": "[<tips>]: **금리형 ETF의 금리에 따른 이자 지급과 관련된 질문**입니다. 금리 관련 데이터는 DB에 존재하지 않기 때문에, 관련 정보는 'retrieve_faq_tool'를 사용해야 합니다. 특정 ETF의 금리 관련 질문일 경우, 'retrieve_etf_values_tool'을 사용해 'market_class'를 파악한 후 'retrieve_faq_tool'를 사용하세요.",
            "유사ETF검색": "[<tips>]: 특정 ETF와 유사하거나, 경쟁하는 ETF를 찾고자 하는 질문입니다. similar_etf_search_tool을 사용하면 주어진 상품과 유사한 상품을 찾을 수 있습니다. **단, 'similar_etf_search_tool'로 해당하는 ETF를 찾지 못한 경우 'theme_search_tool'을 사용해야 합니다.**",
            "ETF테마선택": "[<tips>]: 특정 테마 ETF를 찾거나, 비교하는 질문입니다. 'theme_search_tool'을 사용하면 주어진 조건의 ETF를 찾을 수 있습니다. 찾은 ETF에 대한 특정 조건(AUM, 수익율 등)을 찾을 경우 'retrieve_etf_values_tool'를 추가로 사용할 수 있습니다. 별도의 검색수량 조건(모두, 전부, 10개 등)이 없는 경우 **최대 5개**의 결과만 선택해서 보여주세요. **단, 'theme_search_tool'로 해당하는 ETF를 찾지 못한 경우 'retrieve_etf_values_tool'를 사용해야 합니다.**",
            "ETF정보조회": "[<tips>]: 특정 조건을 기반으로 ETF를 찾거나, 비교하는 질문입니다. 'retrieve_etf_values_tool'을 사용할 수 있습니다.",
            "ETF명칭": "[<tips>]: 하나 이상의 특정 ETF 상품명만 주어진 경우 'retrieve_etf_values_tool'를 사용해 정보를 조회합니다.",
            "특정ETF비교": "[<tips>]: 특정 ETF를 제시하거나, 특정 조건(AUM, 수익율 등)을 제시하여 해당 ETF를 찾고, 이를 비교하는 질문입니다. **비교를 할때는 무조건 'retrieve_etf_values_tool'를 한번만 사용해야 합니다.**",
            "커버드콜": "[<tips>]: 커버드콜 관련 ETF는 etf_name에 커버드콜이 포함되는 조건을 사용해 커버드콜 ETF를 조회하고 답변하세요.",
            "그외": ""
        }
        rule_based_tip_dict = {
            "SCHD": "'retrieve_faq_tool'",
            "SPY": "'retrieve_faq_tool'",
        }
        def tip_scratchpad_function(s):
            tip: str = ""
            #rule_keyword_list = [keyword for keyword in rule_based_tip_dict.keys() if (keyword in question)]
            pattern = re.compile('|'.join(rule_based_tip_dict.keys()), re.IGNORECASE)
            rule_keyword_list = pattern.findall(question)
            if rule_keyword_list:
                rule_route_list = [rule_based_tip_dict[k.upper()] for k in list(dict.fromkeys(rule_keyword_list))]
                tip = f"[<tips>]: {', '.join(rule_route_list)}을 사용해서 답변하세요."
            elif topic and topic in tip_dict.keys():
                tip = tip_dict[topic]
            return tip

        return tip_scratchpad_function

    def scratchpad_function(s):
        plan_prompt = "First, let's plan the steps to answer the user's question based on information showen in [<previous_conversation_history>] and [<tips>]. We'll use the available tools to gather information step-by-step. Here is the [<PLAN>]: "
        return plan_prompt

    @chain
    async def agent(text):
        text['input'] = await question_replace_filtering(text['input'])
        tip_scratchpad_function = route(topic=text['topic'], question=text['input'])
        a1 = await RunnablePassthrough.assign(history=_load_chat_history, tip=tip_scratchpad_function,
                                              scratchpad=scratchpad_function,
                                              formatted_date=lambda _: date.today().strftime("%Y년 %m월 %d일"),
                                              agent_scratchpad=lambda x: format_log_to_str(
                                                  x["intermediate_steps"])).ainvoke(text)
        if a1['history'] == '[]':
            a2 = await prompt_repeat.ainvoke(a1)
        else:
            a2 = await prompt_rewrite.ainvoke(a1)
        #a2 = await prompt.ainvoke(a1)
        a3 = await llm.ainvoke(a2)
        a3.content = await answer_markdown_filtering(a3.content)
        return ReActSingleInputOutputParser().parse(a3.content)

    agent = RunnableAgent(runnable=agent, input_keys_arg=["input"], return_keys_arg=["output"])
    return AgentExecutor(
        name=agent_name,
        agent=agent,
        tools=tools,
        max_iterations=max_iterations,
        max_execution_time=max_execution_time,
        early_stopping_method=early_stopping_method,
        handle_parsing_errors=True,
        **(agent_executor_kwargs or {}),
    )


async def qwen_render_text_description(item_list, rewrite):
    res_list: list = []
    for item in item_list:
        if rewrite:
            item.parameters[0]["description"] = "please write specific question or query to answer the user\'s Question based on the [<PLAN>] and the [<previous_conversation_history>]."
        if item.name != 'fallback_tool' or item.name != 'personal_information_check_tool':
            langfuse_prompt = TOOL_DESC.format(
                name=item.name,
                name_for_human=item.name_for_human,
                description=item.description,
                parameters=item.parameters
            )
        else:
            langfuse_prompt = FB_TOOL_DESC.format(
                name=item.name,
                name_for_human=item.name_for_human,
                description=item.description,
                parameters=item.parameters
            )

        res_list.append(langfuse_prompt)

    return "\n\n".join(res_list)

async def question_replace_filtering(text):
    filter_dict: dict = { # key는 대문자로 표기, value는 대소문자 구분 없음.
        "ARIRANG": "PLUS",
        "KBSTAR": "RISE",
        "KSTAR": "RISE",
        #"KTOP": "1Q", # 반례로 인해 사용 x -> 'TIGER KTOP30' 이 'TIGER 1Q30'으로 변경되면 안됨.
        "KINDEX": "ACE",
        "라이즈": "RISE",
        "코덱스": "KODEX",
        "타이거": "TIGER",
        "WOORI": "WON",
    }
    pattern = re.compile("|".join(map(re.escape, filter_dict.keys())), flags=re.IGNORECASE)
    text = pattern.sub(lambda match: filter_dict[match.group(0).upper()], text)
    return text

async def answer_markdown_filtering(text):
    filter_dict: dict = {"~": "\\~"}
    if any(filter_word in text for filter_word in filter_dict):
        for bef, aft in filter_dict.items():
            text = text.replace(bef, aft)
    return text