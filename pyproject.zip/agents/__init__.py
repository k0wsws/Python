from pandas import DataFrame
from chainlit.custom.database.postgres_connector import db_connector


### To. MAINTAINERS
### PLEASE READE THE NOTE BELOW

"""
    Note: Currently, the key to compare the ETFs is the tracking index.
        But it is not inappropriate to use. Somtimes even the tracking index is same,
        the ETFs can have different strategies or different weights for the same index.

        For example,
            ACE 골드선물 레버리지(합성 H) (225130) and KODEX 골드선물인버스(H) (280940) is in same tracking index.

        So, needs to change the query strategy to make it more accurate.

"""


# Query to get the comparison table for ETFs
QUERY: str = r"""
        select erm.etf_ticker as etf_ticker,erm.etf_name as etf_name, 
            erm2.etf_ticker as comp_ticker, erm2.etf_name as comp_name
        from
            (select etf_ticker, etf_name, 
                array_remove(string_to_array(erm.ace_peer, ',', 'ACE PEER'), null) as ace_peer
            from etf_recent_master erm 
            where ace_peer like '%ACE PEER%' and brand = 'ACE') as erm
        join
            (select erm2.etf_ticker, erm2.etf_name, 
                array_remove(string_to_array(erm2.ace_peer, ',', 'ACE PEER'), null) as ace_peer  
            from etf_recent_master erm2 
            where ace_peer like '%ACE PEER%' and brand != 'ACE') as erm2
        on erm.ace_peer && erm2.ace_peer
        order by erm.etf_name, erm2.etf_name;
    """


# Class to get and set compare table for ETFs
class ETFComparisonTable():
    def __init__(self):
        query = QUERY

        try:
            query_result = db_connector.execute(command=query)
            df: DataFrame =  DataFrame(query_result)
            # DataFrame details
            # dtype = {"etf_ticker": str, "etf_name": str, "comp_ticker": str, "comp_name": str}
            self.data = df.astype(str)
        except:
            raise Exception("Unable to get data from DB or unable to parse data to DataFrame")
    

    # Get ETF name with ticker
    def get_ticker_with_name(self, name: str) -> str:
        return self.data[self.data["etf_name"] == name]["etf_ticker"].values[0]
    

    # Get ETF ticker with name
    def get_name_with_ticker(self, ticker: str) -> str:
        return self.data[self.data["etf_ticker"] == ticker]["etf_name"].values[0]
    

    # Get comaparison ticker with ETF ticker
    def get_comp_ticker(self, target_ticker: str) -> str:
        if target_ticker.isdigit():
            return self.data[self.data["etf_ticker"] == target_ticker]["comp_ticker"].values[0]
        else:
            return self.data[self.data["etf_name"] == target_ticker]["comp_ticker"].values[0]
    

    # Get comparison name with ETF ticker
    def get_comp_name(self, target_ticker: str) -> str:
        if target_ticker.isdigit():
            return self.data[self.data["etf_ticker"] == target_ticker]["comp_name"].values[0]
        else:
            return self.data[self.data["etf_ticker"] == target_ticker]["comp_name"].values[0]
    

    # Get comparison table with target
    def get_comparison(self, target_ticker: str) -> list:
        if target_ticker.isdigit():
            if target_ticker == "316300":
                df = self.data.loc[self.data["comp_ticker"].apply(lambda x: x in ['352560', '352540', '375270', '182480']), ["comp_ticker", "comp_name"]]
            else:
                df = self.data.loc[self.data["etf_ticker"] == target_ticker, ["comp_ticker", "comp_name"]]
        else:
            if target_ticker == "ACE 싱가포르리츠":
                df = self.data.loc[self.data["comp_ticker"].apply(lambda x: x in ['352560', '352540', '375270', '182480']), ["comp_ticker", "comp_name"]]                
            else:
                df = self.data.loc[self.data["etf_name"] == target_ticker, ["comp_ticker", "comp_name"]]
        df.drop_duplicates(subset=["comp_ticker"], inplace=True)
        print(df)
        print(df.to_dict(orient='records'))
        return df.to_dict(orient='records')

