import os
from langchain_core.language_models import BaseLanguageModel
from langchain_core.runnables import RunnableSerializable
from langfuse import Langfuse

from langchain.schema import StrOutputParser
from langchain_core.prompts.chat import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)
from utils.langfuse.langfuse_prompt_save import create_prompt

USE_LANGFUSE_PROMPT_MANAGER_YN = os.environ.get("USE_LANGFUSE_PROMPT_MANAGER_YN", "N")

# Prompt
name = "extract_etf_name_agent"

system_prompt = """You are an AI model designed to extract ETF names from user questions. 
ETF names often include brand names, financial terms, percentages, and complex or compound words. 
Your goal is to accurately identify and extract all ETF names mentioned in the user's query. 
If no specific ETF names are found, or if the query refers to ETFs in a general manner without specifying exact product names, return an empty list.
"""

instruction_prompt = """
<instructions> Extract specific ETF names mentioned in the user's question.
ETF names typically consist of financial terms, brand names, percentages, or complex words. 
If no exact ETF names are provided, or the query only refers to ETFs in a general manner (e.g., "among ETFs from a certain brand"), return an empty list. </instructions>

<output format> 
Return only a list of string with complete and precise ETF names (e.g., ["ACE 200 TR"]). 
Do not include any additional text, comments, or explanations in the output.
If no ETF names are found or the question refers to ETFs in a general way without specific product names, return an empty list (e.g., []).
</output format>

<examples>
1. Question: “ACE 반도체 15%프리미엄 분배와 ACE 빅테크 15%프리미엄 분배를 비교해줘.” -> Output:["ACE 반도체 15%프리미엄 분배", "ACE 빅테크 15%프리미엄 분배"]
2. Question: “ACE 200 TR 분배금 주는 ETF야?” -> Output:["ACE 200 TR"]
3. Question: “465580 티커를 가진 ETF에 대해 알려줘.” -> Output:["465580"]
4. Question: “일본반도체 3종 비교해줘” -> Output:[]
5. Question: “ACE ETF 중 종가 수익률이 높은 것을 나열해줘.” -> Output:[]
6. Question: “이건 ETF 이름이 아니야.” -> Output:[]
</examples>

Question: {question}
Output:
""" # 일본반도체 3종 체크 필요.


async def extract_etf_name_agent(llm: BaseLanguageModel) -> RunnableSerializable[dict, str]:
    langfuse = Langfuse()

    if USE_LANGFUSE_PROMPT_MANAGER_YN == "Y":
        try:
            template = langfuse.get_prompt(name).prompt
        except Exception as e:
            template = instruction_prompt

            create_prompt(
                name,
                template,
                config={
                    "name": name,
                    "instruction_prompt": instruction_prompt,
                    "system_prompt": system_prompt,
                }
            )
    else:
        template = instruction_prompt

    prompt = ChatPromptTemplate.from_messages(
        [SystemMessagePromptTemplate.from_template(system_prompt), HumanMessagePromptTemplate.from_template(template)]
    )
    agent = prompt | llm | StrOutputParser()
    agent.name = name

    return agent
