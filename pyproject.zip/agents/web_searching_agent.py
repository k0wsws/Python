import os
from datetime import date
from langchain.agents.agent import AgentExecutor
from langchain_core.language_models import BaseLanguageModel
from langchain_core.runnables import RunnableSerializable
from langfuse import Langfuse

from langchain.schema import StrOutputParser
from langchain_core.prompts.chat import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    SystemMessagePromptTemplate,
)
from utils.langfuse.langfuse_prompt_save import create_prompt

USE_LANGFUSE_PROMPT_MANAGER_YN = os.environ.get("USE_LANGFUSE_PROMPT_MANAGER_YN", "N")

# Prompt
name = "web_searching_agent"

system_prompt = """
# Role Description
You are a financial advisor chatbot responsible for answering customer questions related to ETFs (Exchange-Traded Funds).
Your answers should be based on the web-searched content provided in the context. The information from the web will follow the given result scheme:

The searched content result scheme: {{"search_query": {{"title": "asked query for web searching", "type": "string"}}, "similarity": {{"title": "similarity score between search query and searched_result", "type": "float"}}, "searched_result": {{"title": "web searched content result", "type": "string"}}, "url": {{"title": "url link of searched_result in web", "type": "web link"}}  }}

Your goal is to make a clear, detailed, and informative response that addresses the user's question effectively, based on the given searched results.
For uncertain or sensitive information to answer, please refer to the hyperlink.

If the context includes hyperlinks, ensure they are maintained in your response and the format should look like:
Text1. ([출처: reference_name](url)) Text2. ([출처: reference_name](url))"

""" + f"Current date: {date.today()}"

instruction_prompt = """
# Generation Rules and Format

1. **Language**: You MUST generate your response in Korean Language (한국어).
2. **Content**: Your response must be clear, rigorous, and conversational, based on the user's question.
3. **No Search Results**: If there are no relevant search results in the Context, simply say, "관련된 검색 결과가 없습니다.". If the Context has only hyperlink, just induce to refer that hyperlink.
4. **Hyperlinks**: If the Context contains URLs, ensure to maintain the hyperlink format in your response and follow this structure: searched_result paragraph1. ([출처: '문장의 출처 웹이름'](url1)) searched_result paragraph2. ([출처: '문장2의 출처 웹이름'](url2))
5. **Length**: Your response should be approximately three to five paragraphs in length.
6. **Similarity**: The "similarity" score indicates how closely the searched result matches the user's query. Use this to ensure that your response is relevant to the user's question.
7. **Generation Manner**: {generation_rule}

# Input Fields
- **Context**: {context}
- **User's Question**: {question} (This is the user's question that requires an answer.)

# Output Fields
- **Answer**: (Only combining above context and user's question, make accurate answer.)
Answer:
"""


async def create_web_searching_agent(llm: BaseLanguageModel) -> RunnableSerializable:
    langfuse = Langfuse()

    if USE_LANGFUSE_PROMPT_MANAGER_YN == "Y":
        try:
            template = langfuse.get_prompt(name).prompt
        except Exception as e:
            template = instruction_prompt

            create_prompt(
                name,
                template,
                config={
                    "name": name,
                    "instruction_prompt": instruction_prompt,
                    "system_prompt": system_prompt,
                }
            )
    else:
        template = instruction_prompt

    prompt = ChatPromptTemplate.from_messages(
        [SystemMessagePromptTemplate.from_template(system_prompt), HumanMessagePromptTemplate.from_template(template)]
    )

    agent = prompt | llm | StrOutputParser()
    agent.name = name

    return agent
