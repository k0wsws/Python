import logging
import time
import warnings

import chainlit as cl

from chainlit.playground.config import add_llm_provider

from langchain.memory import ConversationBufferMemory

from agents.macro_agent import create_top_level_agent, prompt_etf_sel, next_recommendation
from agents.topic_classification_agent import create_topic_classification_agent

from utils.llm_setting.open_llm_provider import make_open_llm_provider
from utils.llm_setting.setup_utils import input_widget, setup_agent_wrapper
from utils.llm_setting.llm_factory import LLMManager

from utils.langchain.call_llm_invoke import setting_runnable_config
from chainlit.custom.database.postgres_connector import db_connector

warnings.filterwarnings("ignore", message="WARNING! extra_body is not default parameter.")


@cl.password_auth_callback
def auth_callback(username: str, password: str):
    # if (username, password) == ("admin", "admin"):
    if (username, password) == ("ai_product", "Qraft321#@!"):
        return cl.User(identifier="admin", metadata={"role": "admin", "provider": "credentials"})
    elif (username, password) == ("ace_tester", "ace123!@#"):
        return cl.User(identifier=username, metadata={"role": "user", "provider": "credentials"})
    elif (username, password) == ("ai_product_qa", "qa"):
        return cl.User(identifier=username, metadata={"role": "user", "provider": "credentials"})
    elif (username, password) == ("ace", "chatetf"):
        return cl.User(identifier="ace", metadata={"role": "user", "provider": "credentials"})
    else:
        return None


@cl.on_settings_update
@setup_agent_wrapper
async def setup_agent(settings):
    # print("Setup agent with following settings: ", settings)
    cl.user_session.set("chat_settings", settings)
    mgr = LLMManager(settings)
    runnable = await create_top_level_agent(mgr)
    cl.user_session.set("runnable", runnable)
    topic_classifier = create_topic_classification_agent(mgr.llm)
    cl.user_session.set("topic_classifier", topic_classifier)
    db_name_ticker = db_connector.execute(command="SELECT etf_name, etf_ticker FROM etf_recent_master ORDER BY etf_name;", fetch="all")
    etf_name_list, etf_name_ticker_dict = [], {}
    for cur in db_name_ticker:
        etf_name_list.append(cur['etf_name'])
        etf_name_ticker_dict[cur['etf_name']] = cur['etf_ticker']
    cl.user_session.set("etf_name_list", etf_name_list)
    cl.user_session.set("etf_name_ticker_dict", etf_name_ticker_dict)

@cl.on_chat_start
async def on_chat_start():
    memory = ConversationBufferMemory(return_messages=True)
    memory.clear()
    cl.user_session.set("memory", memory)
    cl.user_session.set("macro_history", [])
    settings = await cl.ChatSettings(input_widget).send()
    await setup_agent(settings)


@cl.on_message
async def on_message(message: cl.Message):
    ######################## GET USER SESSION DATA ############################
    # session_id = cl.user_session.get("id")
    # user = cl.user_session.get("user")
    # chat_profile = cl.user_session.get("chat_profile")
    # chat_settings = cl.user_session.get("chat_settings")
    # print(
    #     "################################ USER SESSION INFO ########################################"
    # )
    # print(
    #     f"Session_ID:{session_id}, \nUser: {user}, \nChat_profile:{chat_profile}, \nChat_settings:{chat_settings}"
    # )
    # print(
    #     "###########################################################################################"
    # )

    ########################### CALL CHAT MODEL #################################
    runnable = cl.user_session.get("runnable")  ## type: Runnable
    topic_classifier = cl.user_session.get("topic_classifier") ## type: Runnable
    
    start_time: float = time.time()
    start_msg_info: str = ":start_info:" + str(start_time) + ":start_info:" + message.content
    config = setting_runnable_config(start_msg_info=start_msg_info)

    if topic_classifier is None or runnable is None:
        await cl.Message(content="구동 준비중입니다. 다시 시도하세요.").send()
    else:
        ## 채팅 수 제한
        if message.check_limit is not None and message.check_limit:
            await cl.Message(content="-", type="wait_message").send()
            return

        etf_sel = cl.user_session.get("etf_sel")
        try:
            if etf_sel is not None:
                await etf_sel.remove()
        except:
            pass
        topic = topic_classifier.invoke({"input": message.content})
        await runnable.ainvoke({"input": message.content, "topic": topic}, config=config)


# Add the LLM provider
add_llm_provider(make_open_llm_provider())


@cl.action_callback("macro")
async def on_action(action: cl.Action):
    """
    후속질문 눌렀을때..
    """
    try:
        etf_sel = cl.user_session.get("etf_sel")
        await etf_sel.remove()
    except:
        pass

    runnable = cl.user_session.get("runnable")  ## type: Runnable
    await cl.Message(type="user_message", content=action.label).send()
    await runnable.ainvoke({'input': action.label, 'topic': None})


@cl.action_callback("etf_sel_reset")
async def on_action(action: cl.Action):
    etf_sel = cl.user_session.get("etf_sel")
    await etf_sel.remove()
    await prompt_etf_sel(action)


@cl.action_callback("etf_sel")
async def on_action(current_action: cl.Action):
    etf_sel = cl.user_session.get("etf_sel")
    try:
        for action in etf_sel.actions:
            if action.id != current_action.id:
                await action.remove()
    #     await etf_sel.remove()
    except:
        pass

    await prompt_etf_sel(current_action)

    """
    Preset Card rendered HERE..
    """
    cl.user_session.set("extracted_etf_ticker", [v.strip() for v in current_action.value.split("|")])

    # Show next recommendation
    await next_recommendation()


@cl.on_chat_end
async def on_chat_end():
    memory = cl.user_session.get("memory")
    if memory is not None:
        memory.clear()
