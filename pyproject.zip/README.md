# ChatETF

## How to run chainlit app? 

1. Set up conda environment
```
cd ChatETF
conda create -n chatetf
conda activate chatetf
conda env update --file requirements.yaml --prune

```

2. Run
```
chainlit run -w app.py
```


## API configure
```
VECTOR_DB_SERVER="http://10.0.0.219:8101/api/search" 

AI_ETF_DB_USER_NAME="postgres" 
AI_ETF_DB_USER_PASSWORD="1234" 
AI_ETF_DB_HOST="10.0.0.219" 
AI_ETF_DB_PORT="5432" 
AI_ETF_DATABASE="postgres"

LANGFUSE_SECRET_KEY="sk-lf-d3a1c016-dade-450a-b88a-189e3fbb421b" 
LANGFUSE_PUBLIC_KEY="pk-lf-909e3d5a-b0dc-4f16-8bb0-4d21635d6cbd" 
LANGFUSE_HOST="http://10.0.0.219:3001"

QWEN_OPENAI_API_URL="http://10.0.0.178:8000/v1" 
INF_SERVER_BASE_URL="http://10.0.0.178:7000/v1"

X_NAVER_CLIENT_ID=u2b5l0UWhp4AJ_Ww7WEZ
X_NAVER_CLIENT_SECRET=BORsODGnpC
```

## use LITERAL_API_KEY to use Human feedback
```
LITERAL_API_KEY="your literal cloud key"
```

## Langfuse prompt use flag
```
USE_LANGFUSE_PROMPT_MANAGER_YN="Y"
```

## Run Infra

### Model Serving

| Model                                   | Host URL                  |
|-----------------------------------------|---------------------------|
| Qwen/Qwen1.5-72B-Chat                   | http://10.8.12.8:7000/v1  |
| CohereForAI/c4ai-command-r-plus         | http://10.0.0.159:7000/v1 |
| OrionStarAI/Orion-14B-Chat-RAG          | http://10.0.1.60:7000/v1  |
| OrionStarAI/Orion-14B-Chat-RAG          | http://10.0.1.60:7001/v1  |
| yanolja/EEVE-Korean-Instruct-10.8B-v1.0 | http://10.0.1.60:7002/v1  |

#### Download Model


```bash
cd ChatETF && python -m infra.inference.download_llm [모델명]
```

Optional Argument:
  -p : 캐시(다운로드) 경로 ( `/data/hub` as default )



### Vector DB
```
cd infra/qdrant_server

# Qdrant DB 가동
docker run -d -v ./qdrant_data:/qdrant/storage -v ./qdrant-vector-db/qdrant_config.yaml:/qdrant/config/production.yaml -p 6333:6333 qdrant/qdrant:latest
## or..
docker-compose up


### RUN Vector Search Server
conda env create --file requirements.yaml
conda activate vector_server

# 샘플데이터 적재.
PYTHONPATH=. QDRANT_DB_URL=localhost QDRANT_DB_PORT=6333 python initializer/create_faq_collection.py
PYTHONPATH=. QDRANT_DB_URL=localhost QDRANT_DB_PORT=6333 python initializer/create_ticker_name_collection.py


# REST API 가동
QDRANT_DB_URL=10.0.0.219 QDRANT_DB_PORT=6333 python server.py

```

# GPT의 기준 스키마는 아래의 쿼리를 dbms에서 직접 수행하여, 기본 schema 변경
ALTER ROLE postgres IN DATABASE postgres SET search_path TO etf;



### Web Search Server
```
cd infra/qdrant_server/web_search_server

### RUN Vector Search Server
conda env create --file requirements.yaml
conda activate web_search_server

pip install -U pip setuptools wheel
pip install -U 'spacy[cuda11x]'
python -m spacy download ko_core_news_lg

# REST API 가동
python server.py

```

### Custum Chainlit 과 연동하는 방법

#### pnpm install
https://pnpm.io/installation
curl -fsSL https://get.pnpm.io/install.sh | sh -

#### nodejs install
wget -qO- https://raw.githubusercontent.com/nvm-sh/nvm/v0.35.2/install.sh | bash
source ~/.bashrc
nvm ls-remote

#### Custom Chainlit Package Build
**download custom chainlit from QRAFT github**
cd chainlit-1.1.202
pnpm install &&pnpm build  
cd backend/dist
pip install chainlit-1.1.202.tar.gz 

#### chainlit secret key generation
chainlit create-secret
